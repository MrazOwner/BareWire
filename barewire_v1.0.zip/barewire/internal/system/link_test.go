package system

import (
	"context"
	"testing"
)

func TestRouteDevice(t *testing.T) {
	cases := map[string]string{
		"default via 192.168.1.1 dev wlan0 proto dhcp metric 600\n": "wlan0",
		"default dev tun0 scope link\n":                             "tun0",
		"":                                                          "",
		"10.0.0.0/8 via 192.168.1.1 dev eth0\n":                     "",
		"default via 10.8.0.1 dev wg0 metric 50\ndefault dev eth0\n": "wg0",
	}
	for input, want := range cases {
		if got := routeDevice(input, ""); got != want {
			t.Fatalf("routeDevice(%q) = %q, want %q", input, got, want)
		}
	}
}

// The tunnel owns the default route while auto_route is on, so a watcher that
// looked at the first line would see the tunnel instead of the network under it.
// Every flap of the tunnel then looked like a new network and restarted the core
// that had just been started.
func TestRouteDeviceSkipsTheTunnel(t *testing.T) {
	text := "default dev barewire0 scope link\ndefault via 192.168.1.1 dev wlan0 metric 600\n"
	if got := routeDevice(text, "barewire0"); got != "wlan0" {
		t.Fatalf("the physical uplink is what carries the tunnel, got %q", got)
	}
	only := "default dev barewire0 scope link\n"
	if got := routeDevice(only, "barewire0"); got != "" {
		t.Fatalf("a tunnel with no uplink behind it is no network at all, got %q", got)
	}
}

// RemoveLink must be a no-op when the interface is already gone: a crashed host
// leaves the same end state.
func TestRemoveLinkMissingIsFine(t *testing.T) {
	if err := RemoveLink(context.Background(), ""); err == nil {
		t.Fatal("an empty name is a programming error, not a missing link")
	}
}
