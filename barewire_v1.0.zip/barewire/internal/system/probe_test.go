package system

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

// A transport whose server speaks no TCP cannot be measured by a handshake, so
// the route reading is the only number there is. It has to work on a machine with
// nothing but a loopback interface.
func TestRouteMTUReadsTheLocalRoute(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	mtu, err := RouteMTU(ctx, "127.0.0.1:9")
	if err != nil {
		t.Fatalf("route mtu: %v", err)
	}
	if mtu < 576 || mtu > 9000 {
		t.Fatalf("route mtu = %d, want it inside 576..9000", mtu)
	}
}

// speedBody serves exactly n bytes, which is what a download measurement needs.
func speedBody(n int64) *httptest.Server {
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/octet-stream")
		w.WriteHeader(http.StatusOK)
		chunk := make([]byte, 32<<10)
		for written := int64(0); written < n; written += 32 << 10 {
			rest := n - written
			if rest < int64(len(chunk)) {
				chunk = chunk[:rest]
			}
			if _, err := w.Write(chunk); err != nil {
				return
			}
		}
	}))
}

// The first quarter of the body is warm-up: a figure that includes the TLS
// handshake and TCP slow start is what made the Brutal rate too low to matter.
func TestDownloadRateSkipsTheWarmup(t *testing.T) {
	srv := speedBody(4 << 20)
	defer srv.Close()
	probe := &ThroughputProbe{
		Client:  &http.Client{Timeout: 30 * time.Second},
		DownURL: srv.URL,
		DownB:   4 << 20,
	}
	rate, err := probe.DownloadRate(context.Background())
	if err != nil {
		t.Fatalf("download: %v", err)
	}
	if rate <= 0 {
		t.Fatalf("rate = %v, want a positive figure", rate)
	}
}

// A body smaller than the warm-up leaves nothing to time, so the whole transfer
// becomes the sample instead of a division by nothing.
func TestDownloadRateHandlesAShortBody(t *testing.T) {
	srv := speedBody(512 << 10)
	defer srv.Close()
	probe := &ThroughputProbe{
		Client:  &http.Client{Timeout: 30 * time.Second},
		DownURL: srv.URL,
		DownB:   4 << 20,
	}
	rate, err := probe.DownloadRate(context.Background())
	if err != nil {
		t.Fatalf("download: %v", err)
	}
	if rate <= 0 {
		t.Fatalf("rate = %v, want the short body to be measured", rate)
	}
}

func TestDownloadRateReportsAnHTTPError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		http.Error(w, "nope", http.StatusBadGateway)
	}))
	defer srv.Close()
	probe := &ThroughputProbe{Client: srv.Client(), DownURL: srv.URL, DownB: 1 << 20}
	if _, err := probe.DownloadRate(context.Background()); err == nil {
		t.Fatal("a 502 has to be an error, not a zero rate")
	}
}

// The size the probe asks for has to be one the endpoint actually serves, and the
// count it expects has to match the URL: an endpoint that answers 403 makes every
// measurement fail, which is how TCP Brutal came to look like a feature that does
// nothing.
func TestThroughputProbeAsksForASizeTheEndpointServes(t *testing.T) {
	p := NewThroughputProbe(nil)
	if p.DownB <= 0 || p.DownB > maxDownBytes {
		t.Fatalf("download size %d, want 1..%d bytes", p.DownB, maxDownBytes)
	}
	want := fmt.Sprintf("bytes=%d", p.DownB)
	if !strings.HasSuffix(p.DownURL, want) {
		t.Fatalf("url %q does not ask for %s", p.DownURL, want)
	}
	if p.UpB <= 0 || p.Client == nil || p.Client.Timeout < time.Minute {
		t.Fatalf("probe: up %d bytes, timeout %v", p.UpB, p.Client.Timeout)
	}
	// The warm-up has to leave enough of the body to time, otherwise every
	// measurement falls back to the whole transfer.
	if warm := p.DownB / 4; p.DownB-warm < minMeasuredBytes {
		t.Fatalf("a %d-byte body leaves %d bytes after warm-up, want at least %d", p.DownB, p.DownB-warm, minMeasuredBytes)
	}
}

func TestMbpsRateKeepsTheDecimal(t *testing.T) {
	if got := mbpsRate(375_000, time.Second); got < 2.9 || got > 3.1 {
		t.Fatalf("375 KB/s = %v Mbit/s, want about 3", got)
	}
	if got := mbps(375_000, time.Second); got != 3 {
		t.Fatalf("rounded rate = %d, want 3", got)
	}
	if got := mbpsRate(0, time.Second); got != 0 {
		t.Fatalf("no bytes = %v, want 0", got)
	}
	if got := mbpsRate(1000, 0); got != 0 {
		t.Fatalf("no time = %v, want 0", got)
	}
}
