package system

import (
	"context"
	"errors"
	"os/exec"
	"strings"
)

// RemoveLink deletes a network interface, which also removes the routes that
// point at it. A missing interface is not an error: the end state is the same.
func RemoveLink(ctx context.Context, name string) error {
	if name == "" {
		return errors.New("ip: empty interface name")
	}
	err := execRunner{}.Run(ctx, "", "ip", "link", "delete", name)
	if err == nil {
		return nil
	}
	msg := strings.ToLower(err.Error())
	if strings.Contains(msg, "cannot find device") || strings.Contains(msg, "no such") {
		return nil
	}
	return err
}

// DefaultRouteDevice names the interface that currently carries the default
// route. It is what "the network changed" means here: a different device, or
// none at all when the machine went offline. Only the device is compared, so a
// changed metric or gateway does not count as a new network.
//
// ignore names the tunnel, which is skipped. With auto_route the TUN owns the
// default route while the link is up, so a watcher that looked at the first
// default route would see the tunnel instead of the network it runs over: every
// route flap of the tunnel looked like a new network, and each one restarted the
// core that had just been started.
func DefaultRouteDevice(ctx context.Context, ignore string) (string, error) {
	out, err := exec.CommandContext(ctx, "ip", "route", "show", "default").Output()
	if err != nil {
		return "", err
	}
	return routeDevice(string(out), ignore), nil
}

// routeDevice pulls the first "dev <name>" out of the default route lines. A
// non-default route is not what carries the machine, so it is ignored.
func routeDevice(text, ignore string) string {
	for _, line := range strings.Split(text, "\n") {
		fields := strings.Fields(line)
		if len(fields) == 0 || fields[0] != "default" {
			continue
		}
		for i, f := range fields {
			if f != "dev" || i+1 >= len(fields) {
				continue
			}
			if name := fields[i+1]; name != ignore {
				return name
			}
		}
	}
	return ""
}
