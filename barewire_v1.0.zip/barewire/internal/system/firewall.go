// Package system owns everything that touches the machine outside the tunnel:
// the nftables kill switch, kernel congestion control and the network probes.
// Every function here is explicit: nothing runs unless the user asked for it.
package system

import (
	"context"
	"errors"
	"fmt"
	"net/netip"
	"os/exec"
	"strings"
	"sync"
)

// Runner runs one external command. Commands are used instead of netlink for the
// firewall because the ruleset has to be inspectable with the same tools the
// user already has.
type Runner interface {
	Run(ctx context.Context, stdin string, name string, args ...string) error
}

// ErrToolNotFound reports that an external command is not installed.
var ErrToolNotFound = errors.New("command not found")

type execRunner struct{}

func (execRunner) Run(ctx context.Context, stdin, name string, args ...string) error {
	cmd := exec.CommandContext(ctx, name, args...)
	if stdin != "" {
		cmd.Stdin = strings.NewReader(stdin)
	}
	var stderr strings.Builder
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		if errors.Is(err, exec.ErrNotFound) {
			return fmt.Errorf("%w: %s", ErrToolNotFound, name)
		}
		msg := strings.TrimSpace(stderr.String())
		if msg != "" {
			return fmt.Errorf("%s: %s", name, msg)
		}
		return fmt.Errorf("%s: %w", name, err)
	}
	return nil
}

// Firewall is the kill switch: an nftables table that drops everything which is
// not the tunnel, the loopback or the connection to the server itself.
type Firewall struct {
	run     Runner
	mu      sync.Mutex
	active  bool
	version int
}

// NewFirewall creates the kill switch controller.
func NewFirewall() *Firewall {
	return &Firewall{run: execRunner{}}
}

// Active reports whether a ruleset is installed, and its version.
func (f *Firewall) Active() (bool, int) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.active, f.version
}

// Apply installs the ruleset (enabled) or removes it. allow lists the addresses
// the tunnel itself needs: the proxy server and any of its resolved addresses.
func (f *Firewall) Apply(ctx context.Context, enabled bool, allow []string, tunName string) error {
	if !enabled {
		return f.Flush(ctx)
	}
	text := RuleText(allow, tunName)
	if err := f.run.Run(ctx, text, "nft", "-f", "-"); err != nil {
		return fmt.Errorf("kill switch: %w", err)
	}
	f.mu.Lock()
	f.active = true
	f.version++
	f.mu.Unlock()
	return nil
}

// Flush removes both rulesets. A missing table is not an error: the end state is
// the same, and the interface shows facts, not complaints. A machine without nft
// cannot have our tables either, so that case is also a no-op.
func (f *Firewall) Flush(ctx context.Context) error {
	var firstErr error
	for _, table := range []string{"barewire", "barewire_guard"} {
		err := f.run.Run(ctx, "", "nft", "delete", "table", "inet", table)
		if err == nil || isMissingTable(err) || errors.Is(err, ErrToolNotFound) {
			continue
		}
		if firstErr == nil {
			firstErr = fmt.Errorf("kill switch: %w", err)
		}
	}
	f.mu.Lock()
	f.active = false
	f.mu.Unlock()
	return firstErr
}

func isMissingTable(err error) bool {
	msg := strings.ToLower(err.Error())
	return strings.Contains(msg, "no such file") || strings.Contains(msg, "does not exist")
}

// RuleText renders the ruleset. It is a pure function so the shape of the
// firewall can be tested without root.
func RuleText(allow []string, tunName string) string {
	if tunName == "" {
		tunName = "barewire0"
	}
	v4, v6 := splitAddrs(allow)
	var b strings.Builder
	b.WriteString("# barewire kill switch\n")
	b.WriteString("table inet barewire\n")
	b.WriteString("delete table inet barewire\n")
	b.WriteString("table inet barewire {\n")
	b.WriteString("\tchain output {\n")
	b.WriteString("\t\ttype filter hook output priority 0; policy drop;\n")
	b.WriteString("\t\toifname \"lo\" accept\n")
	fmt.Fprintf(&b, "\t\toifname %q accept\n", tunName)
	b.WriteString("\t\tct state established,related accept\n")
	// DHCP and neighbour discovery are how the machine keeps the address it
	// already has. A ruleset that drops them holds until the lease runs out and
	// then takes the whole network with it — an hour into a session, with the
	// tunnel looking healthy.
	b.WriteString("\t\tudp dport 67 accept\n")
	b.WriteString("\t\ticmpv6 accept\n")
	if len(v4) > 0 {
		fmt.Fprintf(&b, "\t\tip daddr { %s } accept\n", strings.Join(v4, ", "))
	}
	// The chain is `inet`, so its policy drops IPv6 as well. Without this line a
	// server addressed by a v6 literal would be blocked by our own ruleset: the
	// link would never come up and nothing would say why.
	if len(v6) > 0 {
		fmt.Fprintf(&b, "\t\tip6 daddr { %s } accept\n", strings.Join(v6, ", "))
	}
	b.WriteString("\t}\n")
	b.WriteString("}\n")
	return b.String()
}

// GuardText renders the DNS guard: a separate table that exists while the link is
// up and is not a kill switch. Its only job is to close the one DNS path the
// tunnel cannot carry — IPv6 resolvers when the link has no IPv6 — because a
// query to a v6 resolver leaves the machine directly and is visible to the ISP
// even though everything else is tunnelled. Only DNS is dropped, so local IPv6
// keeps working.
func GuardText(blockIPv6DNS bool, tunName string) string {
	if tunName == "" {
		tunName = "barewire0"
	}
	var b strings.Builder
	b.WriteString("# barewire dns guard\n")
	b.WriteString("table inet barewire_guard\n")
	b.WriteString("delete table inet barewire_guard\n")
	if !blockIPv6DNS {
		return b.String()
	}
	b.WriteString("table inet barewire_guard {\n")
	b.WriteString("\tchain output {\n")
	b.WriteString("\t\ttype filter hook output priority 10; policy accept;\n")
	b.WriteString("\t\toifname \"lo\" accept\n")
	fmt.Fprintf(&b, "\t\toifname %q accept\n", tunName)
	// Link-local and multicast stay: neighbour discovery, mDNS and router
	// advertisements are part of a working local network.
	b.WriteString("\t\tip6 daddr { fe80::/10, ff00::/8 } accept\n")
	b.WriteString("\t\tip6 udp dport { 53, 853 } drop\n")
	b.WriteString("\t\tip6 tcp dport { 53, 853 } drop\n")
	b.WriteString("\t}\n")
	b.WriteString("}\n")
	return b.String()
}

// ApplyGuard installs or removes the DNS guard. It is independent of the kill
// switch on purpose: leaking a resolver query is not the same decision as
// blocking all traffic.
func (f *Firewall) ApplyGuard(ctx context.Context, blockIPv6DNS bool, tunName string) error {
	text := GuardText(blockIPv6DNS, tunName)
	if err := f.run.Run(ctx, text, "nft", "-f", "-"); err != nil {
		return fmt.Errorf("dns guard: %w", err)
	}
	return nil
}

// splitAddrs keeps plausible literals per family: a hostname in a firewall rule
// would be resolved by nft itself, at a moment nobody controls.
func splitAddrs(in []string) (v4, v6 []string) {
	seen := make(map[string]struct{}, len(in))
	for _, a := range in {
		a = strings.TrimSpace(a)
		if a == "" || strings.Contains(a, "/") {
			continue
		}
		addr, err := netip.ParseAddr(a)
		if err != nil {
			continue
		}
		// An IPv4-mapped v6 literal is an IPv4 address: it belongs in the `ip`
		// rule, where nft understands it.
		addr = addr.Unmap()
		key := addr.String()
		if _, dup := seen[key]; dup {
			continue
		}
		seen[key] = struct{}{}
		if addr.Is4() {
			v4 = append(v4, key)
			continue
		}
		v6 = append(v6, key)
	}
	return v4, v6
}

// ErrNoNFT reports that the nft binary is not available. It is kept for callers
// that want to name the missing tool; the runner itself reports ErrToolNotFound.
var ErrNoNFT = fmt.Errorf("%w: nft", ErrToolNotFound)
