package system

import (
	"net/netip"
	"os"
	"strings"
)

// resolvConfPath is a variable so a test can point the reader at a fixture.
var resolvConfPath = "/etc/resolv.conf"

// SystemResolverNameservers reads the nameservers of /etc/resolv.conf, in order.
// A missing or unreadable file is not an error: the machine may be using a
// resolver configuration this file does not describe.
func SystemResolverNameservers() []string {
	raw, err := os.ReadFile(resolvConfPath)
	if err != nil {
		return nil
	}
	return parseNameservers(string(raw))
}

// parseNameservers pulls the `nameserver` lines out of a resolv.conf document.
func parseNameservers(text string) []string {
	out := make([]string, 0, 4)
	for _, line := range strings.Split(text, "\n") {
		fields := strings.Fields(line)
		if len(fields) < 2 || strings.HasPrefix(fields[0], "#") || strings.HasPrefix(fields[0], ";") {
			continue
		}
		if fields[0] != "nameserver" {
			continue
		}
		out = append(out, strings.TrimSpace(fields[1]))
	}
	return out
}

// LoopbackStub names the local resolver daemon the machine is pointed at, or ""
// when the resolver is a real one.
//
// This is the leak that survives every other fix: when /etc/resolv.conf says
// 127.0.0.53, applications ask systemd-resolved on the loopback interface. Those
// packets never enter the TUN — the TUN only sees what is routed to it — so the
// daemon forwards them out of the physical interface and the ISP answers. The
// only way to catch them is to make nftables steer them into the tunnel, which is
// what the TUN's auto_redirect does.
func LoopbackStub(nameservers []string) string {
	for _, ns := range nameservers {
		addr, err := netip.ParseAddr(strings.TrimSpace(ns))
		if err != nil {
			continue
		}
		if addr.IsLoopback() {
			return addr.String()
		}
	}
	return ""
}
