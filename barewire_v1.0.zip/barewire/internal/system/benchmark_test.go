package system

import (
	"context"
	"errors"
	"reflect"
	"testing"
	"time"
)

// Benchmark applies each algorithm, measures, and restores the original: the
// order of the calls is the proof.
func TestBenchmarkWalksAndRestores(t *testing.T) {
	kp := newKernelProc(t)
	kp.write(t, "available", "reno cubic bbr dctcp")
	var applied []string
	kp.k.run = hookRunner(func(name string, args []string) {
		kp.applyDropIn(t)
		if name == "sysctl" {
			cur, _ := readTrimmed(kp.k.procCC)
			applied = append(applied, cur)
		}
	})
	trials, err := kp.k.Benchmark(context.Background(), KernelValues{},
		[]string{"bbr", "dctcp"},
		func(context.Context) (int, []time.Duration, error) {
			return 100, []time.Duration{10 * time.Millisecond, 20 * time.Millisecond}, nil
		})
	if err != nil {
		t.Fatalf("benchmark: %v", err)
	}
	if len(trials) != 2 || trials[0].Algorithm != "bbr" || trials[1].Algorithm != "dctcp" {
		t.Fatalf("trials: %+v", trials)
	}
	if trials[0].DownMbps != 100 || trials[0].RTTMinMs != 10 || trials[0].RTTP95Ms != 20 {
		t.Fatalf("measurement: %+v", trials[0])
	}
	if got := kp.read(t, "cc"); got != "cubic" {
		t.Fatalf("the machine was left on %q, want the original cubic", got)
	}
	// bbr, dctcp, then the restore.
	if !reflect.DeepEqual(applied, []string{"bbr", "dctcp", "cubic"}) {
		t.Fatalf("applied order: %v", applied)
	}
}

// One algorithm failing to apply must not stop the walk.
func TestBenchmarkRecordsUnavailableAlgorithm(t *testing.T) {
	kp := newKernelProc(t)
	kp.write(t, "available", "reno cubic bbr")
	kp.k.run = &fakeRunner{err: errors.New("boom")}
	trials, err := kp.k.Benchmark(context.Background(), KernelValues{},
		[]string{"bbr", "cubic"},
		func(context.Context) (int, []time.Duration, error) { return 1, nil, nil })
	if err != nil {
		t.Fatalf("benchmark: %v", err)
	}
	if len(trials) != 2 {
		t.Fatalf("trials: %+v", trials)
	}
	if trials[0].Err == "" {
		t.Fatalf("a failed apply must be recorded: %+v", trials[0])
	}
	if Best(trials) != "" {
		t.Fatalf("nothing measurable, so no best: %q", Best(trials))
	}
}

func TestScorePunishesJitter(t *testing.T) {
	fastAndSteady := ScoreTrial(100, 20, 22)
	fastButStalling := ScoreTrial(100, 20, 80)
	slowAndSteady := ScoreTrial(60, 20, 22)
	if fastAndSteady <= fastButStalling {
		t.Fatalf("jitter must cost: %v vs %v", fastAndSteady, fastButStalling)
	}
	if fastAndSteady <= slowAndSteady {
		t.Fatalf("throughput must count: %v vs %v", fastAndSteady, slowAndSteady)
	}
	if ScoreTrial(0, 10, 10) != 0 || ScoreTrial(10, 0, 10) != 0 {
		t.Fatal("an empty measurement must score zero")
	}
}

func TestRTTStats(t *testing.T) {
	rtts := make([]time.Duration, 0, 100)
	for i := 1; i <= 100; i++ {
		rtts = append(rtts, time.Duration(i)*time.Millisecond)
	}
	minMs, p95Ms := rttStats(rtts)
	if minMs != 1 {
		t.Fatalf("min = %d", minMs)
	}
	if p95Ms < 95 || p95Ms > 96 {
		t.Fatalf("p95 = %d", p95Ms)
	}
	if m, p := rttStats(nil); m != 0 || p != 0 {
		t.Fatalf("empty stats: %d %d", m, p)
	}
	// A sub-millisecond path is still a number, not zero.
	if m, _ := rttStats([]time.Duration{300 * time.Microsecond}); m != 1 {
		t.Fatalf("sub-millisecond min = %d", m)
	}
}

func TestBestPicksHighestScore(t *testing.T) {
	trials := []Trial{
		{Algorithm: "bbr", DownMbps: 100, RTTMinMs: 20, RTTP95Ms: 22, Score: 90},
		{Algorithm: "vegas", DownMbps: 30, RTTMinMs: 20, RTTP95Ms: 21, Score: 28},
		{Algorithm: "reno", Err: "no"},
	}
	if got := Best(trials); got != "bbr" {
		t.Fatalf("best = %q", got)
	}
	if got := Best(nil); got != "" {
		t.Fatalf("empty best = %q", got)
	}
}

// hookRunner adapts a plain function to the Runner seam.
type hookRunner func(name string, args []string)

func (h hookRunner) Run(_ context.Context, _ string, name string, args ...string) error {
	h(name, args)
	return nil
}
