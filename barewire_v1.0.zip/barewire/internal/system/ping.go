package system

import (
	"context"
	"net"
	"sort"
	"sync"
	"time"
)

// PingResult is one TCP handshake measurement.
type PingResult struct {
	Index   int
	Latency time.Duration
	Err     error
}

// PingTCP measures the TCP handshake to addr. It is a TCP connect rather than
// ICMP because raw sockets need privileges, and the question the user asks is
// "can this endpoint be reached at all", not "does it answer echo".
func PingTCP(ctx context.Context, addr string, timeout time.Duration) (time.Duration, error) {
	dialer := net.Dialer{Timeout: timeout}
	start := time.Now()
	conn, err := dialer.DialContext(ctx, "tcp", addr)
	if err != nil {
		return 0, err
	}
	_ = conn.Close()
	return time.Since(start), nil
}

// PingAll measures every target with a bounded number of concurrent dials and
// returns results in the order the targets were given.
func PingAll(ctx context.Context, targets []string, workers int, timeout time.Duration) []PingResult {
	if workers < 1 {
		workers = 1
	}
	results := make([]PingResult, len(targets))
	guard := make(chan struct{}, workers)
	var wg sync.WaitGroup
	for i, target := range targets {
		wg.Add(1)
		go func(i int, target string) {
			defer wg.Done()
			guard <- struct{}{}
			defer func() { <-guard }()
			latency, err := PingTCP(ctx, target, timeout)
			results[i] = PingResult{Index: i, Latency: latency, Err: err}
		}(i, target)
	}
	wg.Wait()
	return results
}

// Reachable counts the successful measurements.
func Reachable(results []PingResult) int {
	count := 0
	for _, r := range results {
		if r.Err == nil {
			count++
		}
	}
	return count
}

// MedianLatency is the middle successful measurement, or zero when nothing
// answered.
func MedianLatency(results []PingResult) time.Duration {
	ok := make([]time.Duration, 0, len(results))
	for _, r := range results {
		if r.Err == nil {
			ok = append(ok, r.Latency)
		}
	}
	if len(ok) == 0 {
		return 0
	}
	sort.Slice(ok, func(i, j int) bool { return ok[i] < ok[j] })
	return ok[len(ok)/2]
}
