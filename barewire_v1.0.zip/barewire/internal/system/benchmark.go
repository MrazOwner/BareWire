package system

import (
	"context"
	"errors"
	"sort"
	"time"
)

// Trial is one congestion control measured on the live path.
type Trial struct {
	Algorithm string  `json:"algorithm"`
	DownMbps  int     `json:"down_mbps"`
	RTTMinMs  int     `json:"rtt_min_ms"`
	RTTP95Ms  int     `json:"rtt_p95_ms"`
	Score     float64 `json:"score"`
	Err       string  `json:"err,omitempty"`
}

// Measurer measures the path once, with whatever congestion control is live.
// It returns a download figure and the round trips it saw; both are supplied by
// the caller so that this package stays free of HTTP and of the tunnel.
type Measurer func(ctx context.Context) (downMbps int, rtts []time.Duration, err error)

// Benchmark walks the algorithms one by one, applying each and measuring the
// same path, and then puts back the algorithm that was in force before the run.
// The run is reversible on purpose: the test must not leave the machine on the
// algorithm that happened to be last.
func (k *Kernel) Benchmark(ctx context.Context, base KernelValues, algorithms []string, measure Measurer) ([]Trial, error) {
	if len(algorithms) == 0 {
		return nil, errors.New("kernel: nothing to test")
	}
	if measure == nil {
		return nil, errors.New("kernel: no measurement")
	}
	original, err := k.CongestionControl()
	if err != nil {
		return nil, err
	}
	withCC := func(value string) KernelValues {
		v := base
		v.Congestion = value
		return v
	}
	trials := make([]Trial, 0, len(algorithms))
	for _, alg := range algorithms {
		if ctx.Err() != nil {
			break
		}
		trial := Trial{Algorithm: alg}
		if err := k.Apply(ctx, withCC(alg)); err != nil {
			trial.Err = err.Error()
			trials = append(trials, trial)
			continue
		}
		down, rtts, err := measure(ctx)
		if err != nil {
			trial.Err = err.Error()
			trials = append(trials, trial)
			continue
		}
		trial.DownMbps = down
		trial.RTTMinMs, trial.RTTP95Ms = rttStats(rtts)
		trial.Score = ScoreTrial(trial.DownMbps, trial.RTTMinMs, trial.RTTP95Ms)
		trials = append(trials, trial)
	}
	if original != "" {
		// Best effort: a failing restore must not hide the trials.
		_ = k.Apply(ctx, withCC(original))
	}
	return trials, nil
}

// ScoreTrial rewards throughput and punishes jitter. A path that is fast but
// stalls is what "every few minutes it hangs" feels like, so the p95 round trip
// is part of the score and not just a footnote.
func ScoreTrial(down, minMs, p95Ms int) float64 {
	if down <= 0 || minMs <= 0 || p95Ms <= 0 {
		return 0
	}
	return float64(down) * float64(minMs) / float64(p95Ms)
}

// rttStats returns the smallest and the 95th percentile round trip in
// milliseconds, rounded up so that a sub-millisecond path is still visible.
func rttStats(rtts []time.Duration) (minMs, p95Ms int) {
	if len(rtts) == 0 {
		return 0, 0
	}
	sorted := append([]time.Duration(nil), rtts...)
	sort.Slice(sorted, func(i, j int) bool { return sorted[i] < sorted[j] })
	minMs = ceilMs(sorted[0])
	// Nearest-rank percentile: with few samples the worst one is the p95, which
	// is the honest answer when the run is short.
	idx := (len(sorted)*95+99)/100 - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(sorted) {
		idx = len(sorted) - 1
	}
	p95Ms = ceilMs(sorted[idx])
	return minMs, p95Ms
}

func ceilMs(d time.Duration) int {
	ms := int(d / time.Millisecond)
	if d%time.Millisecond != 0 {
		ms++
	}
	if ms < 1 {
		ms = 1
	}
	return ms
}

// Best names the algorithm with the highest score, skipping trials that failed.
// An empty string means nothing was measurable.
func Best(trials []Trial) string {
	best := ""
	bestScore := 0.0
	for _, t := range trials {
		if t.Err != "" || t.Score <= 0 {
			continue
		}
		if t.Score > bestScore {
			best, bestScore = t.Algorithm, t.Score
		}
	}
	return best
}
