package system

import (
	"context"
	"errors"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// fakeRunner records the commands instead of running them.
type fakeRunner struct {
	calls []string
	err   error
	// hook runs before the call is recorded, so a test can simulate what the
	// command did to the machine.
	hook func(name string, args []string)
}

func (f *fakeRunner) Run(_ context.Context, stdin, name string, args ...string) error {
	f.calls = append(f.calls, strings.TrimSpace(name+" "+strings.Join(args, " ")+"\n"+stdin))
	if f.hook != nil {
		f.hook(name, args)
	}
	return f.err
}

func TestRuleTextDropsEverythingElse(t *testing.T) {
	text := RuleText([]string{"203.0.113.10", "203.0.113.10", "not-an-ip", "10.0.0.0/8"}, "bw0")
	for _, want := range []string{
		"table inet barewire",
		"delete table inet barewire",
		"policy drop",
		`oifname "lo" accept`,
		`oifname "bw0" accept`,
		"ct state established,related accept",
		"ip daddr { 203.0.113.10 } accept",
	} {
		if !strings.Contains(text, want) {
			t.Fatalf("ruleset is missing %q:\n%s", want, text)
		}
	}
	if strings.Contains(text, "not-an-ip") || strings.Contains(text, "10.0.0.0/8") {
		t.Fatalf("hostile or non-literal address leaked into the ruleset:\n%s", text)
	}
	if strings.Count(text, "203.0.113.10") != 1 {
		t.Fatalf("duplicate address not collapsed:\n%s", text)
	}
}

func TestFirewallApplyAndFlush(t *testing.T) {
	run := &fakeRunner{}
	fw := &Firewall{run: run}

	if err := fw.Apply(context.Background(), true, []string{"203.0.113.10"}, "barewire0"); err != nil {
		t.Fatalf("apply: %v", err)
	}
	if len(run.calls) != 1 || !strings.Contains(run.calls[0], "nft -f -") {
		t.Fatalf("unexpected command: %v", run.calls)
	}
	if active, version := fw.Active(); !active || version != 1 {
		t.Fatalf("state = %v, %d", active, version)
	}

	if err := fw.Apply(context.Background(), true, nil, ""); err != nil {
		t.Fatalf("apply 2: %v", err)
	}
	if _, version := fw.Active(); version != 2 {
		t.Fatalf("ruleset version = %d, want 2", version)
	}

	if err := fw.Flush(context.Background()); err != nil {
		t.Fatalf("flush: %v", err)
	}
	if active, _ := fw.Active(); active {
		t.Fatal("flush must clear the active flag")
	}
}

func TestFirewallFlushToleratesMissingTable(t *testing.T) {
	run := &fakeRunner{err: errors.New("nft: No such file or directory")}
	fw := &Firewall{run: run}
	if err := fw.Flush(context.Background()); err != nil {
		t.Fatalf("missing table must not be an error: %v", err)
	}
}

func TestFirewallFlushToleratesMissingNFT(t *testing.T) {
	run := &fakeRunner{err: fmt.Errorf("%w: nft", ErrNoNFT)}
	fw := &Firewall{run: run}
	if err := fw.Flush(context.Background()); err != nil {
		t.Fatalf("a machine without nft has no ruleset to remove: %v", err)
	}
}

func TestFirewallApplyFailsWithoutNFT(t *testing.T) {
	run := &fakeRunner{err: fmt.Errorf("%w: nft", ErrNoNFT)}
	fw := &Firewall{run: run}
	err := fw.Apply(context.Background(), true, nil, "bw0")
	if !errors.Is(err, ErrNoNFT) {
		t.Fatalf("err = %v, want ErrNoNFT", err)
	}
	if active, _ := fw.Active(); active {
		t.Fatal("a failed apply must not mark the ruleset active")
	}
}

// kernelProc wires a controller to a temporary /proc and a temporary drop-in.
type kernelProc struct {
	k     *Kernel
	dir   string
	paths map[string]string // sysctl key -> fake /proc file
}

func newKernelProc(t *testing.T) *kernelProc {
	t.Helper()
	dir := t.TempDir()
	k := NewKernel(filepath.Join(dir, "state"))
	k.procCC = filepath.Join(dir, "cc")
	k.procQdisc = filepath.Join(dir, "qdisc")
	k.procAvailable = filepath.Join(dir, "available")
	k.procProbing = filepath.Join(dir, "probing")
	k.procSlowStart = filepath.Join(dir, "slowstart")
	k.dropInPath = filepath.Join(dir, "sysctl", "99-barewire-kernel.conf")
	k.legacyDropIn = filepath.Join(dir, "sysctl", "99-barewire-bbr.conf")
	k.backupPath = filepath.Join(dir, "state", "kernel-backup.json")
	k.legacyBackup = filepath.Join(dir, "state", "bbr-backup.json")
	kp := &kernelProc{k: k, dir: dir, paths: map[string]string{
		"net.ipv4.tcp_congestion_control":    k.procCC,
		"net.core.default_qdisc":             k.procQdisc,
		"net.ipv4.tcp_mtu_probing":           k.procProbing,
		"net.ipv4.tcp_slow_start_after_idle": k.procSlowStart,
	}}
	kp.write(t, "cc", "cubic")
	kp.write(t, "qdisc", "fq_codel")
	kp.write(t, "probing", "0")
	kp.write(t, "slowstart", "1")
	kp.write(t, "available", "reno cubic")
	return kp
}

func (kp *kernelProc) write(t *testing.T, name, content string) {
	t.Helper()
	if err := os.WriteFile(filepath.Join(kp.dir, name), []byte(content+"\n"), 0o644); err != nil {
		t.Fatal(err)
	}
}

func (kp *kernelProc) read(t *testing.T, name string) string {
	t.Helper()
	raw, err := os.ReadFile(filepath.Join(kp.dir, name))
	if err != nil {
		t.Fatal(err)
	}
	return strings.TrimSpace(string(raw))
}

// applyDropIn makes the fake machine behave like sysctl --system: it applies
// every key in the drop-in file to the matching fake /proc file.
func (kp *kernelProc) applyDropIn(t *testing.T) {
	t.Helper()
	raw, err := os.ReadFile(kp.k.dropInPath)
	if err != nil {
		return
	}
	for _, line := range strings.Split(string(raw), "\n") {
		key, value, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		path, known := kp.paths[strings.TrimSpace(key)]
		if !known {
			continue
		}
		if err := os.WriteFile(path, []byte(strings.TrimSpace(value)+"\n"), 0o644); err != nil {
			t.Fatal(err)
		}
	}
}

// A module the kernel has but has not loaded is the case that made the old lever
// do nothing: it must be loaded, and the load must be verified.
func TestKernelApplyLoadsModuleAndVerifies(t *testing.T) {
	kp := newKernelProc(t)
	run := &fakeRunner{}
	run.hook = func(name string, args []string) {
		switch name {
		case "modprobe":
			kp.write(t, "available", "reno cubic bbr")
		case "sysctl":
			kp.applyDropIn(t)
		}
	}
	kp.k.run = run
	got := KernelValues{Congestion: "bbr", Qdisc: "fq", MTUProbing: "on", SlowStartAfterIdle: "off"}
	if err := kp.k.Apply(context.Background(), got); err != nil {
		t.Fatalf("apply: %v", err)
	}

	joined := strings.Join(run.calls, "\n")
	if !strings.Contains(joined, "modprobe tcp_bbr") {
		t.Fatalf("the module was not loaded: %v", run.calls)
	}
	if !strings.Contains(joined, "sysctl --system") {
		t.Fatalf("sysctl was not reloaded: %v", run.calls)
	}
	dropIn, err := os.ReadFile(kp.k.dropInPath)
	if err != nil {
		t.Fatalf("drop-in: %v", err)
	}
	for _, want := range []string{
		"net.core.default_qdisc = fq",
		"net.ipv4.tcp_congestion_control = bbr",
		"net.ipv4.tcp_mtu_probing = 1",
		"net.ipv4.tcp_slow_start_after_idle = 0",
	} {
		if !strings.Contains(string(dropIn), want) {
			t.Fatalf("drop-in lacks %q:\n%s", want, dropIn)
		}
	}
	if got := kp.read(t, "cc"); got != "bbr" {
		t.Fatalf("congestion control = %q", got)
	}
	backup, ok := kp.k.readBackup()
	if !ok || backup.CongestionControl != "cubic" || backup.DefaultQdisc != "fq_codel" ||
		backup.MTUProbing != "0" || backup.SlowStartAfterIdle != "1" {
		t.Fatalf("backup: %+v", backup)
	}
}

// sysctl can report success and change nothing; the lever must notice.
func TestKernelApplyReportsValueThatDidNotStick(t *testing.T) {
	kp := newKernelProc(t)
	kp.write(t, "available", "reno cubic bbr")
	kp.k.run = &fakeRunner{} // no hook: the machine keeps cubic
	err := kp.k.Apply(context.Background(), KernelValues{Congestion: "bbr"})
	if err == nil {
		t.Fatal("apply must fail when the value did not change")
	}
	if !strings.Contains(err.Error(), "asked for") {
		t.Fatalf("error must name the mismatch: %v", err)
	}
}

// The drop-in the old bool lever wrote must not outlive the new one: sysctl
// reads the directory in name order and "bbr" sorts before "kernel", so a stale
// file would quietly win.
func TestKernelApplyRemovesTheLegacyDropIn(t *testing.T) {
	kp := newKernelProc(t)
	if err := os.MkdirAll(filepath.Dir(kp.k.legacyDropIn), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(kp.k.legacyDropIn, []byte("net.ipv4.tcp_congestion_control = bbr\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	kp.k.run = hookRunner(func(name string, _ []string) {
		if name == "sysctl" {
			kp.applyDropIn(t)
		}
	})
	if err := kp.k.Apply(context.Background(), KernelValues{Congestion: "cubic"}); err != nil {
		t.Fatalf("apply: %v", err)
	}
	if _, err := os.Stat(kp.k.legacyDropIn); !os.IsNotExist(err) {
		t.Fatal("the legacy drop-in must be removed")
	}
}

// A second apply must not overwrite the machine's original values with what we
// wrote ourselves, or disabling restores our values instead of the machine's.
func TestKernelApplyKeepsTheFirstBackup(t *testing.T) {
	kp := newKernelProc(t)
	run := &fakeRunner{}
	run.hook = func(name string, args []string) {
		switch name {
		case "modprobe":
			kp.write(t, "available", "reno cubic bbr")
		case "sysctl":
			kp.applyDropIn(t)
		}
	}
	kp.k.run = run
	if err := kp.k.Apply(context.Background(), KernelValues{Congestion: "bbr"}); err != nil {
		t.Fatalf("first apply: %v", err)
	}
	kp.write(t, "available", "reno cubic bbr")
	if err := kp.k.Apply(context.Background(), KernelValues{Congestion: "cubic"}); err != nil {
		t.Fatalf("second apply: %v", err)
	}
	backup, ok := kp.k.readBackup()
	if !ok || backup.CongestionControl != "cubic" {
		t.Fatalf("backup after the second apply: %+v", backup)
	}
}

func TestKernelRestorePutsValuesBack(t *testing.T) {
	kp := newKernelProc(t)
	run := &fakeRunner{}
	run.hook = func(name string, args []string) {
		if name != "sysctl" {
			return
		}
		for _, arg := range args {
			key, value, ok := strings.Cut(arg, "=")
			if !ok {
				continue
			}
			if path, known := kp.paths[key]; known {
				_ = os.WriteFile(path, []byte(value+"\n"), 0o644)
			}
		}
	}
	kp.k.run = run
	if err := os.MkdirAll(filepath.Dir(kp.k.dropInPath), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(kp.k.dropInPath, []byte("net.ipv4.tcp_congestion_control = bbr\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	kp.write(t, "cc", "bbr")
	if err := kp.k.writeBackup(kernelBackup{
		CongestionControl:  "cubic",
		DefaultQdisc:       "fq_codel",
		MTUProbing:         "0",
		SlowStartAfterIdle: "1",
	}); err != nil {
		t.Fatal(err)
	}

	if err := kp.k.Restore(context.Background()); err != nil {
		t.Fatalf("restore: %v", err)
	}
	if _, err := os.Stat(kp.k.dropInPath); !os.IsNotExist(err) {
		t.Fatal("drop-in must be removed")
	}
	if got := kp.read(t, "cc"); got != "cubic" {
		t.Fatalf("congestion control after restore = %q", got)
	}
	joined := strings.Join(run.calls, "\n")
	for _, want := range []string{
		"net.ipv4.tcp_congestion_control=cubic",
		"net.core.default_qdisc=fq_codel",
		"net.ipv4.tcp_mtu_probing=0",
		"net.ipv4.tcp_slow_start_after_idle=1",
	} {
		if !strings.Contains(joined, want) {
			t.Fatalf("restore command lacks %q: %v", want, run.calls)
		}
	}
	if _, ok := kp.k.readBackup(); ok {
		t.Fatal("backup must be cleared after restore")
	}
}

// The list is the kernel's, not ours: known values keep the catalogue order and
// anything unrecognised is still offered, at the end.
func TestKernelAvailableOrdersTheCatalogue(t *testing.T) {
	kp := newKernelProc(t)
	kp.write(t, "available", "reno bbr cubic zzz")
	if got := strings.Join(kp.k.Available(), ","); got != "bbr,cubic,reno,zzz" {
		t.Fatalf("available = %s", got)
	}
	if !kp.k.Offers("zzz") {
		t.Fatal("an unknown value the kernel offers must count as available")
	}
}

// A value no kernel ships is rejected with a reason instead of a silent no-op.
func TestKernelEnsureRejectsUnknownValue(t *testing.T) {
	kp := newKernelProc(t)
	kp.k.run = &fakeRunner{}
	err := kp.k.Ensure(context.Background(), "copa")
	if err == nil || !strings.Contains(err.Error(), "not a congestion control") {
		t.Fatalf("error: %v", err)
	}
}

func TestPingTCPReachesListener(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	defer func() { _ = ln.Close() }()
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				return
			}
			_ = conn.Close()
		}
	}()

	latency, err := PingTCP(context.Background(), ln.Addr().String(), time.Second)
	if err != nil {
		t.Fatalf("ping: %v", err)
	}
	if latency <= 0 {
		t.Fatalf("latency = %v", latency)
	}
}

func TestPingTCPReportsRefusal(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	addr := ln.Addr().String()
	_ = ln.Close()

	if _, err := PingTCP(context.Background(), addr, time.Second); err == nil {
		t.Fatal("expected an error for a closed port")
	}
}

func TestPingAllKeepsOrderAndCounts(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	defer func() { _ = ln.Close() }()
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				return
			}
			_ = conn.Close()
		}
	}()
	closed, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	closedAddr := closed.Addr().String()
	_ = closed.Close()

	open := ln.Addr().String()
	results := PingAll(context.Background(), []string{open, closedAddr, open}, 4, time.Second)
	if len(results) != 3 {
		t.Fatalf("got %d results", len(results))
	}
	for i, r := range results {
		if r.Index != i {
			t.Fatalf("result %d has index %d", i, r.Index)
		}
	}
	if results[0].Err != nil || results[2].Err != nil {
		t.Fatalf("reachable targets failed: %+v", results)
	}
	if results[1].Err == nil {
		t.Fatalf("closed port must fail: %+v", results[1])
	}
	if Reachable(results) != 2 {
		t.Fatalf("reachable = %d", Reachable(results))
	}
	if MedianLatency(results) <= 0 {
		t.Fatalf("median = %v", MedianLatency(results))
	}
}

func TestMedianLatencyIgnoresFailures(t *testing.T) {
	results := []PingResult{
		{Index: 0, Latency: 10 * time.Millisecond},
		{Index: 1, Err: errors.New("nope")},
		{Index: 2, Latency: 30 * time.Millisecond},
		{Index: 3, Latency: 20 * time.Millisecond},
	}
	if got := MedianLatency(results); got != 20*time.Millisecond {
		t.Fatalf("median = %v", got)
	}
	if got := MedianLatency(nil); got != 0 {
		t.Fatalf("empty median = %v", got)
	}
}

func TestMBPS(t *testing.T) {
	if got := mbps(1_000_000, 8*time.Second); got != 1 {
		t.Fatalf("mbps = %d, want 1", got)
	}
	if got := mbps(0, time.Second); got != 0 {
		t.Fatalf("zero bytes must yield 0, got %d", got)
	}
}

func TestProbeMTUOverLoopback(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	defer func() { _ = ln.Close() }()
	go func() {
		conn, err := ln.Accept()
		if err != nil {
			return
		}
		time.Sleep(200 * time.Millisecond)
		_ = conn.Close()
	}()

	mtu, err := ProbeMTU(context.Background(), ln.Addr().String(), 576, 9000)
	if err != nil {
		t.Fatalf("probe: %v", err)
	}
	if mtu < 576 || mtu > 9000 {
		t.Fatalf("mtu = %d, want 576..9000", mtu)
	}
}

func TestProbeMTUFailsOnClosedPort(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	addr := ln.Addr().String()
	_ = ln.Close()
	if _, err := ProbeMTU(context.Background(), addr, 576, 9000); err == nil {
		t.Fatal("expected an error for a closed port")
	}
}
