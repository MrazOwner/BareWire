package system

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

// KernelOption is one congestion control the kernel may offer. Value is what
// goes into net.ipv4.tcp_congestion_control; Module is what provides it, empty
// when the algorithm is built in.
type KernelOption struct {
	Value  string
	Module string
	Note   string
}

// KernelOptions is every congestion control worth offering, ordered so that the
// ones that help a tunnel come first. A value only appears in the interface when
// this machine registers it, so this table is a catalogue, not a promise. Some
// algorithms in circulation (Copa, PCC, Remy, FAST, BBR.Swift, HPCC) are
// research code that Linux never shipped as a congestion control: there is no
// value to write for them, so they cannot appear here.
func KernelOptions() []KernelOption {
	return []KernelOption{
		{Value: "bbr", Module: "tcp_bbr", Note: "long fat or lossy paths · needs fq"},
		{Value: "cubic", Note: "the kernel default · safe everywhere"},
		{Value: "dctcp", Module: "tcp_dctcp", Note: "lowest queue · needs ECN on the path"},
		{Value: "cdg", Module: "tcp_cdg", Note: "lossy mobile links · delay and loss"},
		{Value: "westwood", Module: "tcp_westwood", Note: "wireless · keeps the measured rate"},
		{Value: "vegas", Module: "tcp_vegas", Note: "low latency on small buffers · weak on long paths"},
		{Value: "illinois", Module: "tcp_illinois", Note: "high speed with loss · step from RTT"},
		{Value: "yeah", Module: "tcp_yeah", Note: "hybrid loss and delay"},
		{Value: "htcp", Module: "tcp_htcp", Note: "aggressive after a long idle"},
		{Value: "scalable", Module: "tcp_scalable", Note: "many flows, datacenter"},
		{Value: "hybla", Module: "tcp_hybla", Note: "very high RTT · satellite"},
		{Value: "veno", Module: "tcp_veno", Note: "wireless · gentle on loss"},
		{Value: "nv", Module: "tcp_nv", Note: "delay and loss together · experimental"},
		{Value: "lp", Module: "tcp_lp", Note: "yields to competing traffic"},
		{Value: "brutal", Module: "tcp_brutal", Note: "third-party module · what TCP Brutal sets on its sockets"},
		{Value: "bic", Module: "tcp_bic", Note: "predecessor of cubic · not recommended"},
		{Value: "highspeed", Module: "tcp_highspeed", Note: "legacy high bandwidth · not recommended"},
		{Value: "reno", Note: "baseline for comparison · slow on long paths"},
	}
}

// ModuleFor names the module that provides a congestion control, or "" when the
// value is unknown or built in.
func ModuleFor(value string) string {
	for _, o := range KernelOptions() {
		if o.Value == value {
			return o.Module
		}
	}
	return ""
}

// Kernel is the machine-side lever: congestion control, queue discipline and the
// two TCP switches that decide how the kernel reacts to a shrinking path and to
// an idle connection. Everything it writes lives in one drop-in file and is
// backed up before it is written, so restoring puts the machine back exactly as
// it was.
type Kernel struct {
	run Runner

	procCC        string
	procQdisc     string
	procAvailable string
	procProbing   string
	procSlowStart string
	dropInPath    string
	backupPath    string
	// legacyBackup is the file the old bool lever used; it is read so that an
	// existing install can still be restored.
	legacyBackup string
	// legacyDropIn is the drop-in the old bool lever wrote. It is removed on
	// every apply: sysctl reads the directory in name order and "99-barewire-bbr"
	// sorts before "99-barewire-kernel", so a stale file would win.
	legacyDropIn string
}

// KernelValues is what to write. An empty field is not written at all.
type KernelValues struct {
	Congestion         string
	Qdisc              string
	MTUProbing         string
	SlowStartAfterIdle string
}

// Empty reports whether nothing is asked for.
func (v KernelValues) Empty() bool {
	return v == KernelValues{}
}

// NewKernel creates the controller. Paths are fields so tests can point them at
// a temporary directory instead of the real machine.
func NewKernel(stateDir string) *Kernel {
	return &Kernel{
		run:           execRunner{},
		procCC:        "/proc/sys/net/ipv4/tcp_congestion_control",
		procQdisc:     "/proc/sys/net/core/default_qdisc",
		procAvailable: "/proc/sys/net/ipv4/tcp_available_congestion_control",
		procProbing:   "/proc/sys/net/ipv4/tcp_mtu_probing",
		procSlowStart: "/proc/sys/net/ipv4/tcp_slow_start_after_idle",
		dropInPath:    "/etc/sysctl.d/99-barewire-kernel.conf",
		backupPath:    filepath.Join(stateDir, "kernel-backup.json"),
		legacyBackup:  filepath.Join(stateDir, "bbr-backup.json"),
		legacyDropIn:  "/etc/sysctl.d/99-barewire-bbr.conf",
	}
}

// kernelBackup records what the machine used before Barewire touched it.
type kernelBackup struct {
	CongestionControl  string `json:"congestion_control"`
	DefaultQdisc       string `json:"default_qdisc"`
	MTUProbing         string `json:"tcp_mtu_probing,omitempty"`
	SlowStartAfterIdle string `json:"tcp_slow_start_after_idle,omitempty"`
}

func readTrimmed(path string) (string, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(string(raw)), nil
}

// CongestionControl reads the kernel's current congestion control.
func (k *Kernel) CongestionControl() (string, error) {
	v, err := readTrimmed(k.procCC)
	if err != nil {
		return "", fmt.Errorf("kernel: read congestion control: %w", err)
	}
	return v, nil
}

// Qdisc reads the kernel's current default queue discipline.
func (k *Kernel) Qdisc() string {
	v, err := readTrimmed(k.procQdisc)
	if err != nil {
		return ""
	}
	return v
}

// Available lists the congestion controls this kernel registers right now. An
// algorithm compiled as a module is absent until something loads it, which is
// why Available and Ensure are two functions and not one.
func (k *Kernel) Available() []string {
	raw, err := os.ReadFile(k.procAvailable)
	if err != nil {
		return nil
	}
	registered := make(map[string]struct{}, 8)
	for _, f := range strings.Fields(string(raw)) {
		registered[f] = struct{}{}
	}
	out := make([]string, 0, len(registered))
	seen := make(map[string]struct{}, len(registered))
	for _, o := range KernelOptions() {
		if _, ok := registered[o.Value]; ok {
			out = append(out, o.Value)
			seen[o.Value] = struct{}{}
		}
	}
	// Anything the kernel offers that this build has no note for still belongs
	// in the list: the user asked for what the machine can do, not for what we
	// happen to know.
	extra := make([]string, 0, len(registered))
	for v := range registered {
		if _, ok := seen[v]; !ok {
			extra = append(extra, v)
		}
	}
	sort.Strings(extra)
	return append(out, extra...)
}

// Offers reports whether the kernel registers the given value.
func (k *Kernel) Offers(value string) bool {
	for _, v := range k.Available() {
		if v == value {
			return true
		}
	}
	return false
}

// Ensure makes a congestion control usable: if the kernel has it as a module but
// has not loaded it, the module is loaded and the result is verified. The old
// lever failed exactly here: it read the registered list, never loaded anything,
// and reported "the kernel does not offer bbr" on a machine that had the module.
func (k *Kernel) Ensure(ctx context.Context, value string) error {
	if value == "" || k.Offers(value) {
		return nil
	}
	module := ModuleFor(value)
	if module == "" {
		return fmt.Errorf("kernel: %q is not a congestion control this kernel knows", value)
	}
	if err := k.run.Run(ctx, "", "modprobe", module); err != nil {
		return fmt.Errorf("kernel: load %s: %w", module, err)
	}
	if !k.Offers(value) {
		return fmt.Errorf("kernel: module %s loaded, but %q is still not registered", module, value)
	}
	return nil
}

// Apply writes the drop-in, reloads sysctl and verifies that the kernel actually
// took the values. A lever that silently does nothing is worse than one that
// fails, so a mismatch is an error carrying both the wanted and the actual
// value.
func (k *Kernel) Apply(ctx context.Context, v KernelValues) error {
	if v.Empty() {
		return nil
	}
	if err := k.Ensure(ctx, v.Congestion); err != nil {
		return err
	}
	if _, ok := k.readBackup(); !ok {
		// Only the first apply records the machine's own values: a second apply
		// must not overwrite the originals with what we wrote ourselves.
		if err := k.writeBackup(k.snapshot()); err != nil {
			return err
		}
	}
	content := k.dropIn(v)
	if err := os.MkdirAll(filepath.Dir(k.dropInPath), 0o755); err != nil {
		return fmt.Errorf("kernel: create %s: %w", filepath.Dir(k.dropInPath), err)
	}
	if k.legacyDropIn != "" {
		// The old file must not outlive the new one: it would win the name order
		// and quietly undo the choice.
		if err := os.Remove(k.legacyDropIn); err != nil && !errors.Is(err, os.ErrNotExist) {
			return fmt.Errorf("kernel: remove %s: %w", k.legacyDropIn, err)
		}
	}
	if err := os.WriteFile(k.dropInPath, []byte(content), 0o644); err != nil {
		return fmt.Errorf("kernel: write %s: %w", k.dropInPath, err)
	}
	if err := k.run.Run(ctx, "", "sysctl", "--system"); err != nil {
		return fmt.Errorf("kernel: reload: %w", err)
	}
	return k.verify(v)
}

// dropIn renders the file. Only the requested keys appear: a key that is not in
// the set is not written, so the machine keeps its own value.
func (k *Kernel) dropIn(v KernelValues) string {
	var b strings.Builder
	if v.Qdisc != "" {
		fmt.Fprintf(&b, "net.core.default_qdisc = %s\n", v.Qdisc)
	}
	if v.Congestion != "" {
		fmt.Fprintf(&b, "net.ipv4.tcp_congestion_control = %s\n", v.Congestion)
	}
	if v.MTUProbing != "" {
		fmt.Fprintf(&b, "net.ipv4.tcp_mtu_probing = %s\n", onOff(v.MTUProbing))
	}
	if v.SlowStartAfterIdle != "" {
		fmt.Fprintf(&b, "net.ipv4.tcp_slow_start_after_idle = %s\n", onOff(v.SlowStartAfterIdle))
	}
	return b.String()
}

func onOff(state string) string {
	if state == "on" {
		return "1"
	}
	return "0"
}

// verify reads the machine back. sysctl can succeed and change nothing when a
// file under /proc is read-only, so the only proof is the value itself.
func (k *Kernel) verify(v KernelValues) error {
	type check struct {
		name string
		want string
		path string
	}
	checks := make([]check, 0, 4)
	if v.Congestion != "" {
		checks = append(checks, check{"congestion control", v.Congestion, k.procCC})
	}
	if v.Qdisc != "" {
		checks = append(checks, check{"queue discipline", v.Qdisc, k.procQdisc})
	}
	if v.MTUProbing != "" {
		checks = append(checks, check{"tcp_mtu_probing", onOff(v.MTUProbing), k.procProbing})
	}
	if v.SlowStartAfterIdle != "" {
		checks = append(checks, check{"tcp_slow_start_after_idle", onOff(v.SlowStartAfterIdle), k.procSlowStart})
	}
	for _, c := range checks {
		got, err := readTrimmed(c.path)
		if err != nil {
			return fmt.Errorf("kernel: verify %s: %w", c.name, err)
		}
		if got != c.want {
			return fmt.Errorf("kernel: %s is %q, asked for %q", c.name, got, c.want)
		}
	}
	return nil
}

// Restore removes the drop-in and puts back the values the machine had.
func (k *Kernel) Restore(ctx context.Context) error {
	if err := os.Remove(k.dropInPath); err != nil && !errors.Is(err, os.ErrNotExist) {
		return fmt.Errorf("kernel: remove %s: %w", k.dropInPath, err)
	}
	if k.legacyDropIn != "" {
		if err := os.Remove(k.legacyDropIn); err != nil && !errors.Is(err, os.ErrNotExist) {
			return fmt.Errorf("kernel: remove %s: %w", k.legacyDropIn, err)
		}
	}
	backup, ok := k.readBackup()
	if !ok {
		return k.run.Run(ctx, "", "sysctl", "--system")
	}
	args := []string{"-w"}
	if backup.CongestionControl != "" {
		args = append(args, "net.ipv4.tcp_congestion_control="+backup.CongestionControl)
	}
	if backup.DefaultQdisc != "" {
		args = append(args, "net.core.default_qdisc="+backup.DefaultQdisc)
	}
	if backup.MTUProbing != "" {
		args = append(args, "net.ipv4.tcp_mtu_probing="+backup.MTUProbing)
	}
	if backup.SlowStartAfterIdle != "" {
		args = append(args, "net.ipv4.tcp_slow_start_after_idle="+backup.SlowStartAfterIdle)
	}
	if len(args) > 1 {
		if err := k.run.Run(ctx, "", "sysctl", args...); err != nil {
			return fmt.Errorf("kernel: restore: %w", err)
		}
	}
	_ = os.Remove(k.backupPath)
	_ = os.Remove(k.legacyBackup)
	return nil
}

// snapshot reads what the machine has now, for the backup.
func (k *Kernel) snapshot() kernelBackup {
	var b kernelBackup
	b.CongestionControl, _ = readTrimmed(k.procCC)
	b.DefaultQdisc, _ = readTrimmed(k.procQdisc)
	b.MTUProbing, _ = readTrimmed(k.procProbing)
	b.SlowStartAfterIdle, _ = readTrimmed(k.procSlowStart)
	return b
}

// KernelNote describes a congestion control in one line. The interface shows it
// under the lever so that the choice is not a wall of acronyms.
func KernelNote(value string) string {
	for _, o := range KernelOptions() {
		if o.Value == value {
			return o.Note
		}
	}
	if value == "" {
		return "leave the kernel alone"
	}
	return "reported by the kernel · no note for it"
}

func (k *Kernel) writeBackup(v kernelBackup) error {
	raw, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return fmt.Errorf("kernel: encode backup: %w", err)
	}
	if err := os.MkdirAll(filepath.Dir(k.backupPath), 0o700); err != nil {
		return fmt.Errorf("kernel: create backup dir: %w", err)
	}
	if err := os.WriteFile(k.backupPath, raw, 0o600); err != nil {
		return fmt.Errorf("kernel: write backup: %w", err)
	}
	return nil
}

func (k *Kernel) readBackup() (kernelBackup, bool) {
	for _, path := range []string{k.backupPath, k.legacyBackup} {
		raw, err := os.ReadFile(path)
		if err != nil {
			continue
		}
		var v kernelBackup
		if err := json.Unmarshal(raw, &v); err != nil {
			continue
		}
		return v, true
	}
	return kernelBackup{}, false
}
