package system

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"time"

	"golang.org/x/sys/unix"
)

// mtuHeaderLen is IPv4 (20 bytes) plus TCP (20 bytes): the difference between
// the path MTU and the MSS the peer negotiated.
const mtuHeaderLen = 40

// ProbeMTU measures the path MTU by connecting to the server over TCP and
// reading the MSS the kernel negotiated with the peer. It measures the path that
// actually carries the tunnel, not a guess made from the interface.
func ProbeMTU(ctx context.Context, target string, lo, hi int) (int, error) {
	if lo < 576 {
		lo = 576
	}
	if hi <= 0 || hi > 9000 {
		hi = 9000
	}

	dialer := net.Dialer{Timeout: 5 * time.Second}
	conn, err := dialer.DialContext(ctx, "tcp", target)
	if err != nil {
		return 0, fmt.Errorf("mtu probe: dial %s: %w", target, err)
	}
	defer func() { _ = conn.Close() }()

	tcp, ok := conn.(*net.TCPConn)
	if !ok {
		return 0, errors.New("mtu probe: not a tcp connection")
	}
	raw, err := tcp.SyscallConn()
	if err != nil {
		return 0, fmt.Errorf("mtu probe: %w", err)
	}

	mss := 0
	var sockErr error
	if err := raw.Control(func(fd uintptr) {
		mss, sockErr = unix.GetsockoptInt(int(fd), unix.IPPROTO_TCP, unix.TCP_MAXSEG)
	}); err != nil {
		return 0, fmt.Errorf("mtu probe: %w", err)
	}
	if sockErr != nil {
		return 0, fmt.Errorf("mtu probe: read mss: %w", sockErr)
	}
	if mss <= 0 {
		return 0, errors.New("mtu probe: kernel reported no mss")
	}

	mtu := mss + mtuHeaderLen
	if mtu < lo {
		mtu = lo
	}
	if mtu > hi {
		mtu = hi
	}
	return mtu, nil
}

// RouteMTU reads the MTU the kernel holds for the route to addr. It needs no
// answer from the far side, which is the point: a UDP transport's server listens
// on no TCP port, so the MSS probe cannot run there, and a dial that is never
// answered tells us nothing about the size of the packets we send. The local
// route MTU is the fact that decides whether a large inner packet leaves the
// machine at all.
func RouteMTU(ctx context.Context, addr string) (int, error) {
	dialer := net.Dialer{Timeout: 5 * time.Second}
	conn, err := dialer.DialContext(ctx, "udp", addr)
	if err != nil {
		return 0, fmt.Errorf("mtu probe: route to %s: %w", addr, err)
	}
	defer func() { _ = conn.Close() }()

	udp, ok := conn.(*net.UDPConn)
	if !ok {
		return 0, errors.New("mtu probe: not a udp connection")
	}
	level, option := unix.IPPROTO_IP, unix.IP_MTU
	if remote, ok := udp.RemoteAddr().(*net.UDPAddr); ok && remote.IP.To4() == nil {
		level, option = unix.IPPROTO_IPV6, unix.IPV6_MTU
	}
	raw, err := udp.SyscallConn()
	if err != nil {
		return 0, fmt.Errorf("mtu probe: %w", err)
	}
	mtu := 0
	var sockErr error
	if err := raw.Control(func(fd uintptr) {
		mtu, sockErr = unix.GetsockoptInt(int(fd), level, option)
	}); err != nil {
		return 0, fmt.Errorf("mtu probe: %w", err)
	}
	if sockErr != nil {
		return 0, fmt.Errorf("mtu probe: read route mtu: %w", sockErr)
	}
	if mtu <= 0 {
		return 0, errors.New("mtu probe: kernel reported no route mtu")
	}
	if mtu < 576 {
		mtu = 576
	}
	if mtu > 9000 {
		mtu = 9000
	}
	return mtu, nil
}

// ThroughputProbe measures the link with a download and an upload. It runs only
// when the user asks for it: no probe ever starts on its own.
type ThroughputProbe struct {
	Client  *http.Client
	DownURL string
	UpURL   string
	DownB   int64
	UpB     int64
}

// maxDownBytes is the largest body Cloudflare's speed endpoint serves. Anything
// above it is answered with 403 — asking for 16 MiB, which this probe used to do,
// means every measurement fails and TCP Brutal can never be configured at all.
// The number is the endpoint's own limit, not a preference.
const maxDownBytes = 10 << 20

// maxWarmupBytes is the most of a test body that is spent before timing starts. A
// quarter of the body is skipped by default; on a fast link that is still enough
// to leave slow start behind, and on a slow one it is not most of the measurement.
const maxWarmupBytes = 4 << 20

// minMeasuredBytes is how much of the body has to be left after the warm-up for
// the tail to be worth timing. Below it the whole transfer is used instead: a
// short sample of a slow link is noise, not a measurement.
const minMeasuredBytes = 1 << 20

// NewThroughputProbe returns a probe that uses Cloudflare's speed endpoints.
//
// The timeout is generous on purpose: 10 MiB takes half a minute on a 3 Mbit/s
// link, and a probe that gives up in the middle reports zero on exactly the links
// the user is asking about.
func NewThroughputProbe(client *http.Client) *ThroughputProbe {
	if client == nil {
		client = &http.Client{Timeout: 2 * time.Minute}
	}
	return &ThroughputProbe{
		Client:  client,
		DownURL: fmt.Sprintf("https://speed.cloudflare.com/__down?bytes=%d", int64(maxDownBytes)),
		UpURL:   "https://speed.cloudflare.com/__up",
		DownB:   maxDownBytes,
		UpB:     8 << 20,
	}
}

// Measure returns up and down in Mbps.
func (p *ThroughputProbe) Measure(ctx context.Context) (up, down int, err error) {
	down, err = p.Download(ctx)
	if err != nil {
		return 0, 0, err
	}
	up, err = p.Upload(ctx)
	if err != nil {
		return 0, 0, err
	}
	return up, down, nil
}

// Download measures the download side alone. The congestion control trials use
// it: a two-sided measurement per algorithm would take longer than the link does.
func (p *ThroughputProbe) Download(ctx context.Context) (int, error) {
	rate, err := p.DownloadRate(ctx)
	return int(rate), err
}

// Upload measures the upload side alone, for the same reason.
func (p *ThroughputProbe) Upload(ctx context.Context) (int, error) {
	return p.upload(ctx)
}

// DownloadRate is Download without the rounding, for the one case that needs the
// decimal: a link that moves a third of a megabit and a link that moves nothing
// are not the same answer, and rounding both to zero hides the difference.
func (p *ThroughputProbe) DownloadRate(ctx context.Context) (float64, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, p.DownURL, nil)
	if err != nil {
		return 0, err
	}
	started := time.Now()
	resp, err := p.Client.Do(req)
	if err != nil {
		return 0, fmt.Errorf("download: %w", err)
	}
	defer func() { _ = resp.Body.Close() }()
	if resp.StatusCode != http.StatusOK {
		return 0, fmt.Errorf("download: HTTP %d", resp.StatusCode)
	}
	// A cold connection spends its first moments in the TLS handshake and in TCP
	// slow start. Timing the whole body measures those, not the link — and a
	// Brutal rate derived from such a number promises the kernel less than the
	// line can carry, which makes the feature look like it does nothing. The
	// first quarter is read as warm-up; only the tail is timed.
	warm := p.DownB / 4
	if warm > maxWarmupBytes {
		warm = maxWarmupBytes
	}
	skipped := int64(0)
	if warm > 0 {
		// A body shorter than the warm-up leaves nothing to time; the count is
		// what matters, not the error.
		skipped, _ = io.CopyN(io.Discard, resp.Body, warm)
	}
	mark := time.Now()
	n, err := io.Copy(io.Discard, resp.Body)
	if err != nil {
		return 0, fmt.Errorf("download: %w", err)
	}
	if n >= minMeasuredBytes {
		return mbpsRate(n, time.Since(mark)), nil
	}
	// Too little was left after the warm-up to say anything about the link, so
	// the whole transfer is the sample.
	return mbpsRate(skipped+n, time.Since(started)), nil
}

func (p *ThroughputProbe) upload(ctx context.Context) (int, error) {
	body := &countingReader{remaining: p.UpB, chunk: make([]byte, 32<<10)}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, p.UpURL, body)
	if err != nil {
		return 0, err
	}
	req.ContentLength = p.UpB
	req.Header.Set("Content-Type", "application/octet-stream")
	start := time.Now()
	resp, err := p.Client.Do(req)
	if err != nil {
		return 0, fmt.Errorf("upload: %w", err)
	}
	defer func() { _ = resp.Body.Close() }()
	_, _ = io.Copy(io.Discard, resp.Body)
	if resp.StatusCode >= 400 {
		return 0, fmt.Errorf("upload: HTTP %d", resp.StatusCode)
	}
	return mbps(p.UpB, time.Since(start)), nil
}

// countingReader produces a fixed number of zero bytes without allocating a
// multi-megabyte buffer.
type countingReader struct {
	remaining int64
	chunk     []byte
}

func (r *countingReader) Read(p []byte) (int, error) {
	if r.remaining <= 0 {
		return 0, io.EOF
	}
	n := len(p)
	if int64(n) > r.remaining {
		n = int(r.remaining)
	}
	if n > len(r.chunk) {
		n = len(r.chunk)
	}
	for i := 0; i < n; i++ {
		p[i] = 0
	}
	r.remaining -= int64(n)
	return n, nil
}

// CheckEgress makes one small request and reports whether an answer came back. It
// exists because "the core is running" is not the same fact as "a request through
// the tunnel works": a multiplexed session against a server that does not speak
// sing-mux looks exactly like a healthy link until the first byte is expected.
func CheckEgress(ctx context.Context, url string) error {
	client := &http.Client{Timeout: 12 * time.Second}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return err
	}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer func() { _ = resp.Body.Close() }()
	_, _ = io.Copy(io.Discard, io.LimitReader(resp.Body, 64<<10))
	if resp.StatusCode >= 400 {
		return fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	return nil
}

// mbpsRate converts bytes over a duration into megabits per second without
// rounding. A link moving a third of a megabit has a number here.
func mbpsRate(bytes int64, d time.Duration) float64 {
	if bytes <= 0 || d <= 0 {
		return 0
	}
	return float64(bytes) * 8 / d.Seconds() / 1_000_000
}

// mbps is mbpsRate rounded down, for the figures that are kept as whole numbers.
func mbps(bytes int64, d time.Duration) int {
	return int(mbpsRate(bytes, d))
}
