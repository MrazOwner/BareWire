package system

import (
	"testing"

	"github.com/mrazowner/barewire/internal/config"
)

// The catalogue the interface offers and the list Normalize accepts have to be the
// same set. When they drifted, choosing an algorithm the UI offered was silently
// rewritten by Normalize back to the default — the lever looked like it did
// nothing.
func TestCatalogueMatchesTheSettingsList(t *testing.T) {
	allowed := make(map[string]struct{}, len(config.KernelCongestions))
	for _, v := range config.KernelCongestions {
		allowed[v] = struct{}{}
	}
	for _, opt := range KernelOptions() {
		if _, ok := allowed[opt.Value]; !ok {
			t.Errorf("%q is offered but would be normalised away", opt.Value)
		}
	}
	inCatalogue := make(map[string]struct{}, len(KernelOptions()))
	for _, opt := range KernelOptions() {
		inCatalogue[opt.Value] = struct{}{}
	}
	for _, v := range config.KernelCongestions {
		if _, ok := inCatalogue[v]; !ok {
			t.Errorf("%q is accepted by the settings but never offered", v)
		}
	}
}

func TestCatalogueHasBbrFirstAndBrutal(t *testing.T) {
	options := KernelOptions()
	if len(options) == 0 || options[0].Value != "bbr" {
		t.Fatalf("the list must lead with what helps a tunnel: %+v", options)
	}
	if ModuleFor("brutal") != "tcp_brutal" {
		t.Fatalf("brutal module = %q", ModuleFor("brutal"))
	}
	if ModuleFor("made-up") != "" {
		t.Fatal("an unknown value has no module")
	}
}
