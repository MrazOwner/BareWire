package system

import (
	"os/exec"
	"strings"
	"testing"
)

// The server's own address must be allowed in both families: the chain is
// `inet`, so its policy drops IPv6 too, and a v6-addressed server would be
// blocked by our own ruleset with nothing in the log to explain it.
func TestRuleTextAllowsIPv6Server(t *testing.T) {
	text := RuleText([]string{"203.0.113.10", "2001:db8::1", "2001:db8::1"}, "bw0")
	if !strings.Contains(text, "ip daddr { 203.0.113.10 } accept") {
		t.Fatalf("v4 allow missing:\n%s", text)
	}
	if !strings.Contains(text, "ip6 daddr { 2001:db8::1 } accept") {
		t.Fatalf("v6 allow missing:\n%s", text)
	}
	if strings.Count(text, "2001:db8::1") != 1 {
		t.Fatalf("v6 address must appear once:\n%s", text)
	}
}

// With IPv6 off the TUN carries no IPv6, so the only place a v6 resolver query
// can go is the physical link — straight to the ISP. The guard drops exactly
// that and leaves the rest of local IPv6 alone.
func TestGuardTextBlocksOnlyIPv6DNS(t *testing.T) {
	on := GuardText(true, "bw0")
	for _, want := range []string{
		"table inet barewire_guard {",
		"ip6 udp dport { 53, 853 } drop",
		"ip6 tcp dport { 53, 853 } drop",
		"ip6 daddr { fe80::/10, ff00::/8 } accept",
		`oifname "bw0" accept`,
	} {
		if !strings.Contains(on, want) {
			t.Fatalf("guard lacks %q:\n%s", want, on)
		}
	}
	if strings.Contains(on, "policy drop") {
		t.Fatalf("the guard is not a kill switch:\n%s", on)
	}

	off := GuardText(false, "bw0")
	if strings.Contains(off, "drop") {
		t.Fatalf("a disabled guard must not drop anything:\n%s", off)
	}
	if !strings.Contains(off, "delete table inet barewire_guard") {
		t.Fatalf("the table must still be removed:\n%s", off)
	}
}

// A ruleset that drops DHCP or neighbour discovery holds until the lease runs
// out and then takes the network with it, an hour into a session with the tunnel
// looking healthy.
func TestRuleTextKeepsTheLeaseAlive(t *testing.T) {
	text := RuleText([]string{"203.0.113.10"}, "bw0")
	for _, want := range []string{"udp dport 67 accept", "icmpv6 accept", "policy drop"} {
		if !strings.Contains(text, want) {
			t.Fatalf("kill switch lacks %q:\n%s", want, text)
		}
	}
}

func TestSplitAddrs(t *testing.T) {
	v4, v6 := splitAddrs([]string{
		"203.0.113.10", "203.0.113.10", "2001:db8::1", "not-an-ip",
		"10.0.0.0/8", "::ffff:198.51.100.7", " 2001:db8::2 ",
	})
	if strings.Join(v4, ",") != "203.0.113.10,198.51.100.7" {
		t.Fatalf("v4 = %v", v4)
	}
	if strings.Join(v6, ",") != "2001:db8::1,2001:db8::2" {
		t.Fatalf("v6 = %v", v6)
	}
}

// The rulesets are text, and text can be wrong in a way only nft notices. When
// the tool is installed, ask it to parse them without applying anything.
func TestRulesetsParseWithNFT(t *testing.T) {
	if _, err := exec.LookPath("nft"); err != nil {
		t.Skip("nft is not installed")
	}
	for name, text := range map[string]string{
		"kill switch": RuleText([]string{"203.0.113.10", "2001:db8::1"}, "bw0"),
		"dns guard":   GuardText(true, "bw0"),
	} {
		cmd := exec.Command("nft", "-c", "-f", "-")
		cmd.Stdin = strings.NewReader(text)
		if out, err := cmd.CombinedOutput(); err != nil {
			t.Fatalf("%s does not parse: %v\n%s", name, err, out)
		}
	}
}
