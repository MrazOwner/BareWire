package config

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestDefaultsSurviveNormalize(t *testing.T) {
	s := Defaults()
	s.Normalize()
	if s.Theme.Accent != Defaults().Theme.Accent || s.TUNStack != TUNStackSingTun {
		t.Fatalf("defaults changed under Normalize: %+v", s)
	}
}

func TestNormalizeReplacesBadValues(t *testing.T) {
	s := Settings{
		TUNStack: "quantum",
		MTU:      -5,
		DNS:      DNSSettings{Mode: "telepathy", OnNetworkChange: "explode", Servers: []string{"  ", ""}},
		Smux:     SmuxSettings{Protocol: "carrier-pigeon"},
		Brutal:   BrutalSettings{UpMbps: 0, DownMbps: -1},
		Theme:    Theme{Accent: "not-a-color", AccentAlt: "#ff0000"},
	}
	s.Normalize()
	if s.TUNStack != TUNStackSingTun || s.DNS.Mode != "fakeip" || s.DNS.OnNetworkChange != "restart" {
		t.Fatalf("choices not repaired: %+v", s)
	}
	if s.MTU != 0 {
		t.Fatalf("MTU = %d, want 0 (auto)", s.MTU)
	}
	if len(s.DNS.Servers) == 0 {
		t.Fatal("empty server list must fall back to defaults")
	}
	if s.Smux.Protocol != "smux" {
		t.Fatalf("smux protocol = %q", s.Smux.Protocol)
	}
	if s.Brutal.UpMbps < 1 || s.Brutal.DownMbps < 1 {
		t.Fatalf("brutal limits not clamped: %+v", s.Brutal)
	}
	if s.Theme.Accent != Defaults().Theme.Accent {
		t.Fatalf("accent = %q", s.Theme.Accent)
	}
	if s.Theme.AccentAlt != "#ff0000" {
		t.Fatalf("valid accent must survive, got %q", s.Theme.AccentAlt)
	}
}

func TestNormalizeClampsMTU(t *testing.T) {
	s := Defaults()
	s.MTU = 20000
	s.Normalize()
	if s.MTU != 9000 {
		t.Fatalf("MTU = %d, want 9000", s.MTU)
	}
}

func TestValidColor(t *testing.T) {
	good := []string{"#7aa2f7", "#abc", "red", "brightblue", "ansi:42", "default"}
	bad := []string{"", "#12", "#1234567", "nope", "ansi:x"}
	for _, c := range good {
		if !ValidColor(c) {
			t.Errorf("ValidColor(%q) = false", c)
		}
	}
	for _, c := range bad {
		if ValidColor(c) {
			t.Errorf("ValidColor(%q) = true", c)
		}
	}
}

func TestLoadSettingsMissingFileGivesDefaults(t *testing.T) {
	path := filepath.Join(t.TempDir(), "settings.json")
	s, err := LoadSettings(path)
	if err != nil {
		t.Fatalf("load: %v", err)
	}
	if s.TUNStack != Defaults().TUNStack {
		t.Fatalf("unexpected defaults: %+v", s)
	}
}

func TestSettingsRoundTrip(t *testing.T) {
	path := filepath.Join(t.TempDir(), "nested", "settings.json")
	want := Defaults()
	want.TUNStack = TUNStackSingTun
	want.MultiQueue = true
	want.MTU = 1380
	want.Brutal = BrutalSettings{Enabled: true, UpMbps: 80, DownMbps: 400}
	want.Theme = Theme{Accent: "#f38ba8", AccentAlt: "#94e2d5"}
	if err := SaveSettings(path, want); err != nil {
		t.Fatalf("save: %v", err)
	}
	info, err := os.Stat(path)
	if err != nil {
		t.Fatalf("stat: %v", err)
	}
	if info.Mode().Perm() != 0o600 {
		t.Fatalf("mode = %v, want 0600", info.Mode().Perm())
	}
	got, err := LoadSettings(path)
	if err != nil {
		t.Fatalf("load: %v", err)
	}
	if got.TUNStack != want.TUNStack || got.MTU != want.MTU || got.Theme != want.Theme || got.MultiQueue != want.MultiQueue {
		t.Fatalf("round trip mismatch:\n got %+v\nwant %+v", got, want)
	}
	if got.Brutal != want.Brutal {
		t.Fatalf("brutal mismatch: %+v", got.Brutal)
	}
}

func TestDNSPresets(t *testing.T) {
	v4 := DNSServersFor("quad9", false)
	if len(v4) != 2 || v4[0] != "9.9.9.9" {
		t.Fatalf("quad9 v4 = %v", v4)
	}
	both := DNSServersFor("quad9", true)
	if len(both) != 4 || both[2] != "2620:fe::fe" {
		t.Fatalf("quad9 v4+v6 = %v", both)
	}
	if got := DNSServersFor("nope", true); got != nil {
		t.Fatalf("unknown preset = %v", got)
	}
}

func TestMatchDNSPreset(t *testing.T) {
	if got := MatchDNSPreset(DNSServersFor("google", false)); got != "google" {
		t.Fatalf("v4 list matched %q", got)
	}
	if got := MatchDNSPreset(DNSServersFor("google", true)); got != "google" {
		t.Fatalf("v4+v6 list matched %q", got)
	}
	if got := MatchDNSPreset([]string{"9.9.9.9"}); got != "custom" {
		t.Fatalf("partial list matched %q", got)
	}
}

func TestDNSSettingsUnmarshalKeepsIPv6ForOldFiles(t *testing.T) {
	var d DNSSettings
	if err := json.Unmarshal([]byte(`{"mode":"fakeip","servers":["1.1.1.1"]}`), &d); err != nil {
		t.Fatal(err)
	}
	if !d.UseIPv6 {
		t.Fatal("an absent use_ipv6 key must keep IPv6 on")
	}
	if err := json.Unmarshal([]byte(`{"mode":"direct","servers":["9.9.9.9"],"use_ipv6":false}`), &d); err != nil {
		t.Fatal(err)
	}
	if d.UseIPv6 {
		t.Fatal("an explicit false must be honoured")
	}
}

// The direct lists are scrubbed like everything else: a hand-edited file with a
// name where a prefix belongs must not stop the core from starting.
func TestNormalizeBypass(t *testing.T) {
	s := Defaults()
	s.Bypass = BypassSettings{
		IPs:       []string{" 10.0.0.0/8 ", "10.0.0.0/8", "not-an-ip", "", "1.1.1.1", "fdfe::/16"},
		Domains:   []string{" example.com", "example.com", " "},
		Processes: []string{"steam", "steam ", ""},
	}
	s.Normalize()
	wantIPs := []string{"10.0.0.0/8", "1.1.1.1", "fdfe::/16"}
	if len(s.Bypass.IPs) != len(wantIPs) {
		t.Fatalf("ips = %v", s.Bypass.IPs)
	}
	for i := range wantIPs {
		if s.Bypass.IPs[i] != wantIPs[i] {
			t.Fatalf("ips = %v", s.Bypass.IPs)
		}
	}
	if len(s.Bypass.Domains) != 1 || s.Bypass.Domains[0] != "example.com" {
		t.Fatalf("domains = %v", s.Bypass.Domains)
	}
	if len(s.Bypass.Processes) != 1 || s.Bypass.Processes[0] != "steam" {
		t.Fatalf("processes = %v", s.Bypass.Processes)
	}
}

func TestValidPrefix(t *testing.T) {
	for _, good := range []string{"10.0.0.0/8", "1.1.1.1", "2606:4700:4700::1111", "fdfe::/16"} {
		if err := ValidPrefix(good); err != nil {
			t.Fatalf("%q rejected: %v", good, err)
		}
	}
	for _, bad := range []string{"", "example.com", "10.0.0.0/33", "1.1.1.1/", "10.0.0.0 /8"} {
		if err := ValidPrefix(bad); err == nil {
			t.Fatalf("%q accepted", bad)
		}
	}
}

// Clone is a deep copy of every list: a settings screen that edits a clone must
// not write through to the original.
func TestCloneCopiesBypass(t *testing.T) {
	s := Defaults()
	s.Bypass = BypassSettings{
		IPs:       []string{"10.0.0.0/8"},
		Domains:   []string{"example.com"},
		Processes: []string{"steam"},
	}
	c := s.Clone()
	c.Bypass.IPs[0] = "mutated"
	c.Bypass.Domains[0] = "mutated"
	c.Bypass.Processes[0] = "mutated"
	if s.Bypass.IPs[0] != "10.0.0.0/8" || s.Bypass.Domains[0] != "example.com" || s.Bypass.Processes[0] != "steam" {
		t.Fatalf("Clone shares a slice with the original: %+v", s.Bypass)
	}
}

func TestValidateServerAddress(t *testing.T) {
	good := []string{
		"1.1.1.1",
		"1.1.1.1:5353",
		"2606:4700:4700::1111",
		"[2606:4700:4700::1111]:53",
		"9.9.9.9:65535",
	}
	for _, addr := range good {
		if err := ValidateServerAddress(addr); err != nil {
			t.Fatalf("%q rejected: %v", addr, err)
		}
	}
	bad := []string{
		"",
		"cloudflare",
		"dns.google",
		"1.1.1.1:0",
		"1.1.1.1:99999",
		"1.1.1.1:port",
		"http://1.1.1.1",
	}
	for _, addr := range bad {
		if err := ValidateServerAddress(addr); err == nil {
			t.Fatalf("%q accepted", addr)
		}
	}
}

// A name where an address belongs used to reach the core and stop it with
// "missing domain resolver": the file is repaired instead.
func TestNormalizeDropsUnusableServers(t *testing.T) {
	s := Defaults()
	s.DNS.Servers = []string{"cloudflare", "1.1.1.1", "1.1.1.1", "dns.google"}
	s.Normalize()
	if len(s.DNS.Servers) != 1 || s.DNS.Servers[0] != "1.1.1.1" {
		t.Fatalf("servers = %v", s.DNS.Servers)
	}

	s = Defaults()
	s.DNS.Servers = []string{"cloudflare"}
	s.Normalize()
	if got := MatchDNSPreset(s.DNS.Servers); got != "cloudflare" {
		t.Fatalf("an unusable list must fall back to the defaults, got %v", s.DNS.Servers)
	}
}

func TestOnlyIPv4(t *testing.T) {
	in := []string{
		"1.1.1.1",
		"2606:4700:4700::1111",
		"[2a10:50c0::ad1:ff]:53",
		"9.9.9.9:5353",
		"dns.example.net",
	}
	got := OnlyIPv4(in)
	want := []string{"1.1.1.1", "9.9.9.9:5353", "dns.example.net"}
	if len(got) != len(want) {
		t.Fatalf("OnlyIPv4 = %v", got)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("OnlyIPv4 = %v, want %v", got, want)
		}
	}
}

func TestNormalizeDropsV6WhenDisabled(t *testing.T) {
	s := Defaults()
	s.DNS.UseIPv6 = false
	s.DNS.Servers = []string{"1.1.1.1", "2606:4700:4700::1111"}
	s.Normalize()
	if len(s.DNS.Servers) != 1 || s.DNS.Servers[0] != "1.1.1.1" {
		t.Fatalf("servers = %v", s.DNS.Servers)
	}
}

func TestDefaultsUseIPv6Preset(t *testing.T) {
	s := Defaults()
	if !s.DNS.UseIPv6 {
		t.Fatal("IPv6 is on by default")
	}
	if got := MatchDNSPreset(s.DNS.Servers); got != "cloudflare" {
		t.Fatalf("default preset = %q", got)
	}
}

func TestCloneDoesNotShareServers(t *testing.T) {
	s := Defaults()
	c := s.Clone()
	c.DNS.Servers[0] = "9.9.9.9"
	if s.DNS.Servers[0] == "9.9.9.9" {
		t.Fatal("Clone shares the server slice")
	}
}

func TestXDGPaths(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", "/tmp/cfg")
	t.Setenv("XDG_RUNTIME_DIR", "/tmp/run")
	if got := SettingsPath(); got != "/tmp/cfg/barewire/settings.json" {
		t.Fatalf("settings path = %q", got)
	}
	if got := HostSocketPath(); got != "/tmp/run/barewire/host.sock" {
		t.Fatalf("socket path = %q", got)
	}
}

func TestProfilesRoundTrip(t *testing.T) {
	path := filepath.Join(t.TempDir(), "profiles.json")
	st := ProfileStore{Active: "work"}
	p := Profile{Name: "work", Settings: Defaults(), BoundNetwork: "home-wifi"}
	st.Items = append(st.Items, p)
	if err := SaveProfiles(path, st); err != nil {
		t.Fatalf("save: %v", err)
	}
	got, err := LoadProfiles(path)
	if err != nil {
		t.Fatalf("load: %v", err)
	}
	if len(got.Items) != 1 || got.Items[0].Name != "work" || got.Items[0].BoundNetwork != "home-wifi" {
		t.Fatalf("unexpected store: %+v", got)
	}
	if idx, ok := got.Find("work"); !ok || idx != 0 {
		t.Fatalf("Find = %d, %v", idx, ok)
	}
}
