package config

import "testing"

// The TUN carries inner packets, the tunnel wraps them: the MTU written into the
// TUN has to be smaller than the path. Using the path size made every large inner
// packet too big for the link, which reads as a tunnel that connects and then
// stops.
func TestTunnelMTUCeiling(t *testing.T) {
	cases := []struct {
		name string
		path int
		kind string
		want int
	}{
		{"ethernet vless", 1500, "vless", 1500 - 40 - 70},
		{"ethernet trojan", 1500, "trojan", 1500 - 40 - 90},
		{"jumbo is capped", 9000, "vless", MaxTunnelMTU},
		{"a small path floors at 1280", 1200, "vless", MinTunnelMTU},
		{"no measurement", 0, "vless", 0},
		{"unknown transport", 1500, "made-up", 1500 - 40 - 80},
	}
	for _, c := range cases {
		if got := TunnelMTUCeiling(c.path, c.kind); got != c.want {
			t.Errorf("%s: TunnelMTUCeiling(%d, %q) = %d, want %d", c.name, c.path, c.kind, got, c.want)
		}
	}
}

func TestTunnelMTULowersAValueThatDoesNotFit(t *testing.T) {
	mtu, lowered := TunnelMTU(1488, 1500, "vless")
	if !lowered || mtu != 1390 {
		t.Fatalf("1488 bytes on a 1500-byte path = %d (lowered %v), want 1390", mtu, lowered)
	}
	if mtu, lowered := TunnelMTU(1380, 1500, "vless"); lowered || mtu != 1380 {
		t.Fatalf("a value that fits must be kept: %d (lowered %v)", mtu, lowered)
	}
	if mtu, _ := TunnelMTU(0, 0, "vless"); mtu != DefaultTunnelMTU {
		t.Fatalf("no measurement leaves the default, got %d", mtu)
	}
}

// A UDP transport has no TCP port to measure: the MSS probe would spend the whole
// timeout and report nothing, and the MTU lever silently did nothing there.
func TestIsUDPTransport(t *testing.T) {
	for _, kind := range []string{"hysteria2", "hysteria", "tuic", "wireguard"} {
		if !IsUDPTransport(kind) {
			t.Errorf("%s reaches its server over UDP and has to be measured by its route", kind)
		}
	}
	for _, kind := range []string{"vless", "vmess", "trojan", "shadowsocks", "anytls", "", "made-up"} {
		if IsUDPTransport(kind) {
			t.Errorf("%s completes a TCP handshake, so its MSS is readable", kind)
		}
	}
}

// A theme is not a reason to drop every connection of a working tunnel; a
// resolver list is.
func TestRequiresRestart(t *testing.T) {
	base := Defaults()
	cases := []struct {
		name string
		edit func(*Settings)
		want bool
	}{
		{"nothing", func(*Settings) {}, false},
		{"theme", func(s *Settings) { s.Theme.Accent = "#ffffff" }, false},
		{"kill switch", func(s *Settings) { s.KillSwitch.Enabled = true }, false},
		{"network change policy", func(s *Settings) { s.DNS.OnNetworkChange = "keep" }, false},
		{"congestion control", func(s *Settings) { s.Kernel.Congestion = "bbr" }, false},
		{"tun stack", func(s *Settings) { s.TUNStack = "mixed" }, true},
		{"mtu", func(s *Settings) { s.MTU = 1380 }, true},
		{"multi queue", func(s *Settings) { s.MultiQueue = !s.MultiQueue }, true},
		{"resolvers", func(s *Settings) { s.DNS.Servers = []string{"9.9.9.9"} }, true},
		{"dns mode", func(s *Settings) { s.DNS.Mode = "direct" }, true},
		{"bypass", func(s *Settings) { s.Bypass.Domains = []string{"example.com"} }, true},
		{"mux", func(s *Settings) { s.Smux.Enabled = true }, true},
		{"quic congestion", func(s *Settings) { s.Kernel.QuicCongestion = "bbr" }, true},
	}
	for _, c := range cases {
		edited := base.Clone()
		c.edit(&edited)
		if got := edited.RequiresRestart(base); got != c.want {
			t.Errorf("%s: RequiresRestart = %v, want %v", c.name, got, c.want)
		}
	}
}
