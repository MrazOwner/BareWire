package config

import "time"

// Preset is a lever set that ships with the program: one press instead of
// guessing at ten levers. A preset never touches multiplexing or TCP Brutal —
// both need a server that speaks them, and a preset that claimed otherwise would
// be a lie the user has to debug at the worst moment.
type Preset struct {
	Name     string
	Note     string
	Settings Settings
}

// Presets returns the built-in starting points, in the order they are offered.
// Each one exists because of a failure that is documented in this code: large
// inner packets that do not fit the path, an alpha TUN stack under a high-rate
// UDP transport, and a machine that leaks everything the tunnel does not carry.
//
// Every preset is normalised before it is returned, so the list shows exactly what
// activating it writes: a preset that Normalize rewrites is a setting the user
// cannot see until it has already been applied.
func Presets() []Preset {
	build := func(name, note string, edit func(*Settings)) Preset {
		s := Defaults()
		s.Profile = name
		if edit != nil {
			edit(&s)
		}
		s.Normalize()
		return Preset{Name: name, Note: note, Settings: s}
	}
	return []Preset{
		build("balanced", "sing-tun stack, measured MTU, fakeip DNS · the default", nil),
		build("compatible", "mixed stack and a smaller MTU · for links that stall or drop large packets", func(s *Settings) {
			s.TUNStack = "mixed"
			s.MTU = 1380
			s.MultiQueue = false
			s.Kernel.MTUProbing = "on"
		}),
		build("quic", "for hysteria2 and TUIC · kernel UDP stack, QUIC congestion control, MTU for QUIC", func(s *Settings) {
			s.TUNStack = "mixed"
			s.MTU = 1370
			s.MultiQueue = false
			s.DNS.UseIPv6 = false
			s.Kernel.QuicCongestion = "bbr"
			s.Kernel.MTUProbing = "on"
		}),
		build("fast", "no fakeip, plain resolvers · fewest moving parts, real DNS answers", func(s *Settings) {
			s.TUNStack = "mixed"
			s.MTU = 1420
			s.DNS.Mode = "direct"
			s.DNS.Servers = []string{"1.1.1.1"}
			s.Kernel.MTUProbing = "on"
		}),
		build("locked", "kill switch on · traffic stays blocked when the core dies", func(s *Settings) {
			s.KillSwitch.Enabled = true
			s.KillSwitch.OnCrash = "keep"
			s.KillSwitch.OnNetworkChange = "flush"
			s.DNS.UseIPv6 = false
			s.Kernel.MTUProbing = "on"
			// The one path the TUN cannot see on its own: a resolver stub on the
			// loopback. Turning redirect on is what makes this preset leak-free
			// instead of merely blocked.
			s.AutoRedirect = true
		}),
	}
}

// PresetByName finds a built-in preset.
func PresetByName(name string) (Preset, bool) {
	for _, p := range Presets() {
		if p.Name == name {
			return p, true
		}
	}
	return Preset{}, false
}

// SeedProfiles adds the built-in presets that the store does not have yet, once.
//
// It used to fill only a completely empty store, which meant an install that
// already had one profile of its own never saw a preset at all — the exact report
// that came back as "there are no profiles". The merge keeps every existing
// profile, never overwrites one whose name is taken (the user's version wins, even
// if it started as ours), and marks the store so that a preset the user deletes is
// not resurrected on the next load.
func SeedProfiles(st ProfileStore) (ProfileStore, bool) {
	if st.Seeded {
		return st, false
	}
	st.Seeded = true
	for _, p := range Presets() {
		if _, exists := st.Find(p.Name); exists {
			continue
		}
		settings := p.Settings.Clone()
		settings.Profile = p.Name
		st.Items = append(st.Items, Profile{
			Name:      p.Name,
			Note:      p.Note,
			Builtin:   true,
			Settings:  settings,
			UpdatedAt: time.Now(),
		})
	}
	// Always a change: the marker itself is part of what has to be written back.
	return st, true
}
