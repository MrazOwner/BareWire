package config

import (
	"encoding/json"
	"strings"
	"testing"
)

// The kernel lever used to be one bool. An existing file must keep working and
// must be rewritten in the new shape.
func TestKernelMigratesTheOldBBRBool(t *testing.T) {
	var s Settings
	if err := json.Unmarshal([]byte(`{"version":1,"bbr":true}`), &s); err != nil {
		t.Fatal(err)
	}
	s.Normalize()
	if s.Kernel.Congestion != "bbr" {
		t.Fatalf("congestion = %q, want bbr", s.Kernel.Congestion)
	}
	if s.BBR {
		t.Fatal("the legacy field must be cleared so it is not written again")
	}
	raw, err := json.Marshal(s)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(raw), `"bbr":true`) {
		t.Fatalf("the legacy field came back: %s", raw)
	}
}

// An explicit choice is newer than the bool: migration must not override it.
func TestKernelMigrationKeepsAnExplicitChoice(t *testing.T) {
	s := Defaults()
	s.BBR = true
	s.Kernel.Congestion = "cubic"
	s.Normalize()
	if s.Kernel.Congestion != "cubic" {
		t.Fatalf("congestion = %q, want cubic", s.Kernel.Congestion)
	}
}

// A hand edited file with a value this kernel never had is a "leave it alone",
// not a start failure.
func TestKernelDropsUnknownValues(t *testing.T) {
	s := Defaults()
	s.Kernel = KernelSettings{
		Congestion:         "copa",
		Qdisc:              "netem",
		MTUProbing:         "yes",
		SlowStartAfterIdle: "OFF",
	}
	s.Normalize()
	if !s.Kernel.Empty() {
		t.Fatalf("kernel = %+v, want nothing", s.Kernel)
	}
}

// Every value the interface offers must survive Normalize, or a lever would
// reset itself the moment it is used.
func TestKernelAcceptsEveryOfferedValue(t *testing.T) {
	for _, cc := range KernelCongestions {
		s := Defaults()
		s.Kernel.Congestion = cc
		s.Normalize()
		if s.Kernel.Congestion != cc {
			t.Fatalf("%q was dropped", cc)
		}
	}
	for _, q := range KernelQdiscs {
		s := Defaults()
		s.Kernel.Qdisc = q
		s.Normalize()
		if s.Kernel.Qdisc != q {
			t.Fatalf("%q was dropped", q)
		}
	}
	for _, st := range KernelStates {
		s := Defaults()
		s.Kernel.MTUProbing = st
		s.Normalize()
		if s.Kernel.MTUProbing != st {
			t.Fatalf("%q was dropped", st)
		}
	}
}

// A fresh install asks for nothing: the machine's TCP is not touched until the
// user says so.
func TestKernelDefaultsToKeepingTheMachine(t *testing.T) {
	if !Defaults().Kernel.Empty() {
		t.Fatalf("defaults must not touch the kernel: %+v", Defaults().Kernel)
	}
}
