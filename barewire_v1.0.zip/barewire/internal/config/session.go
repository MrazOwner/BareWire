package config

import (
	"fmt"
	"os"
	"os/user"
	"path/filepath"
	"strconv"
)

// Session is the desktop session whose files the host owns: the invoking user
// when the host was started with sudo, the current user otherwise. Without this,
// a host started as root would listen on a socket the interface cannot reach and
// read settings from root's home.
type Session struct {
	UID int
	GID int
	// Home is the session user's home directory.
	Home string
	// Elevated is true when this process runs as another user (sudo/pkexec).
	Elevated bool
}

// CurrentSession resolves the session the process should serve.
func CurrentSession() Session {
	uid, gid := os.Getuid(), os.Getgid()
	home, _ := os.UserHomeDir()
	s := Session{UID: uid, GID: gid, Home: home}
	if os.Geteuid() != 0 {
		return s
	}
	targetUID, targetGID, ok := elevatedTarget(os.Getenv)
	if !ok {
		return s
	}
	return Session{
		UID:      targetUID,
		GID:      targetGID,
		Home:     homeForUser(targetUID),
		Elevated: true,
	}
}

// elevatedTarget recognises the user behind an elevated start: sudo exports
// SUDO_UID/SUDO_GID, pkexec exports PKEXEC_UID only (gid -1 means "keep the
// group as it is").
func elevatedTarget(getenv func(string) string) (int, int, bool) {
	if raw := getenv("SUDO_UID"); raw != "" {
		uid, err := strconv.Atoi(raw)
		if err != nil {
			return 0, 0, false
		}
		gid := os.Getgid()
		if rawGID := getenv("SUDO_GID"); rawGID != "" {
			if v, err := strconv.Atoi(rawGID); err == nil {
				gid = v
			}
		}
		return uid, gid, true
	}
	if raw := getenv("PKEXEC_UID"); raw != "" {
		uid, err := strconv.Atoi(raw)
		if err != nil {
			return 0, 0, false
		}
		return uid, -1, true
	}
	return 0, 0, false
}

func homeForUser(uid int) string {
	if u, err := user.LookupId(strconv.Itoa(uid)); err == nil && u.HomeDir != "" {
		return u.HomeDir
	}
	return filepath.Join("/home", strconv.Itoa(uid))
}

// ConfigDirFor is the config directory of a session.
func ConfigDirFor(s Session) string {
	if s.UID == os.Getuid() {
		if dir := os.Getenv("XDG_CONFIG_HOME"); dir != "" {
			return filepath.Join(dir, appDir)
		}
	}
	if s.Home != "" {
		return filepath.Join(s.Home, ".config", appDir)
	}
	return filepath.Join(os.TempDir(), fmt.Sprintf("%s-config-%d", appDir, s.UID))
}

// RuntimeDirFor is the runtime directory of a session: the user's own
// XDG_RUNTIME_DIR when we are that user, then /run/user/<uid>, then /tmp.
func RuntimeDirFor(s Session) string {
	runUser := filepath.Join("/run/user", strconv.Itoa(s.UID))
	exists := false
	if st, err := os.Stat(runUser); err == nil && st.IsDir() {
		exists = true
	}
	xdg := ""
	if s.UID == os.Getuid() {
		xdg = os.Getenv("XDG_RUNTIME_DIR")
	}
	return runtimeDirFor(s, xdg, exists)
}

func runtimeDirFor(s Session, xdg string, runUserExists bool) string {
	if xdg != "" {
		return filepath.Join(xdg, appDir)
	}
	if runUserExists {
		return filepath.Join("/run/user", strconv.Itoa(s.UID), appDir)
	}
	return filepath.Join(os.TempDir(), fmt.Sprintf("%s-runtime-%d", appDir, s.UID))
}

// SettingsPathFor is the settings file of a session.
func SettingsPathFor(s Session) string {
	return filepath.Join(ConfigDirFor(s), "settings.json")
}

// HostSocketPathFor is the socket path of a session.
func HostSocketPathFor(s Session) string {
	return filepath.Join(RuntimeDirFor(s), "host.sock")
}
