package config

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"net"
	"net/netip"
	"os"
	"regexp"
	"strconv"
	"strings"
)

// SettingsVersion is bumped when the on-disk shape changes.
const SettingsVersion = 1

// Choice sets. They live here so that the TUI, the host and the validator all
// agree on the same levers.
var (
	// TUN stacks. All four come from sing-tun, the library sing-box uses: the
	// lever picks who moves the packets, not a second implementation.
	//   sing-tun  sing-tun's own stack (sing-box 1.15+); written as an absent
	//             stack field, and the fastest of the four
	//   mixed     kernel TCP, gvisor UDP
	//   gvisor    gvisor for both
	//   system    the kernel for both
	// The last three are deprecated since sing-box 1.15 and removed in 1.17.
	TUNStacks             = []string{TUNStackSingTun, "mixed", "gvisor", "system"}
	DNSModes              = []string{"fakeip", "direct", "disabled"}
	NetworkChangePolicies = []string{"restart", "keep", "disconnect"}
	KillSwitchPolicies    = []string{"keep", "flush"}
	SmuxProtocols         = []string{"smux", "yamux", "h2mux"}
)

// ColorPresets are the accent colors offered by the theme picker. Any value
// accepted by ValidColor can be typed by hand as well.
var ColorPresets = []string{
	"#7aa2f7", "#89b4fa", "#74c7ec", "#94e2d5", "#a6e3a1", "#9ece6a",
	"#e5c07b", "#f9e2af", "#eba0ac", "#f38ba8", "#cba6f7", "#b4befe",
	"#cdd6f4", "#a6adc8", "#ffffff", "#aaaaaa",
}

var colorPattern = regexp.MustCompile(`^(#[0-9a-fA-F]{3}|#[0-9a-fA-F]{6}|ansi:[0-9]{1,3}|default|` +
	`black|red|green|yellow|blue|magenta|cyan|white|` +
	`brightblack|brightred|brightgreen|brightyellow|brightblue|brightmagenta|brightcyan|brightwhite)$`)

// ValidColor reports whether s is a color the renderer understands.
func ValidColor(s string) bool {
	return colorPattern.MatchString(strings.TrimSpace(s))
}

// DNSPreset is a named resolver set.
type DNSPreset struct {
	Name string
	V4   []string
	V6   []string
}

// DNSPresets are the well-known resolver pairs. Both families are kept so that
// enabling IPv6 is a single toggle instead of hand typing addresses.
var DNSPresets = []DNSPreset{
	{
		Name: "cloudflare",
		V4:   []string{"1.1.1.1", "1.0.0.1"},
		V6:   []string{"2606:4700:4700::1111", "2606:4700:4700::1001"},
	},
	{
		Name: "google",
		V4:   []string{"8.8.8.8", "8.8.4.4"},
		V6:   []string{"2001:4860:4860::8888", "2001:4860:4860::8844"},
	},
	{
		Name: "quad9",
		V4:   []string{"9.9.9.9", "149.112.112.112"},
		V6:   []string{"2620:fe::fe", "2620:fe::9"},
	},
	{
		Name: "adguard",
		V4:   []string{"94.140.14.14", "94.140.15.15"},
		V6:   []string{"2a10:50c0::ad1:ff", "2a10:50c0::ad2:ff"},
	},
	{
		Name: "mullvad",
		V4:   []string{"194.242.2.2"},
		V6:   []string{"2a07:e340::2"},
	},
	{
		Name: "opendns",
		V4:   []string{"208.67.222.222", "208.67.220.220"},
		V6:   []string{"2620:119:35::35", "2620:119:53::53"},
	},
}

// DNSServersFor returns the addresses of a preset for the chosen families.
func DNSServersFor(preset string, useIPv6 bool) []string {
	for _, p := range DNSPresets {
		if p.Name != preset {
			continue
		}
		out := append([]string(nil), p.V4...)
		if useIPv6 {
			out = append(out, p.V6...)
		}
		return out
	}
	return nil
}

// MatchDNSPreset names the preset a server list belongs to, or "custom".
func MatchDNSPreset(servers []string) string {
	for _, p := range DNSPresets {
		if sameSet(servers, p.V4) || (len(p.V6) > 0 && sameSet(servers, append(append([]string(nil), p.V4...), p.V6...))) {
			return p.Name
		}
	}
	return "custom"
}

func sameSet(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	seen := make(map[string]struct{}, len(a))
	for _, v := range a {
		seen[v] = struct{}{}
	}
	for _, v := range b {
		if _, ok := seen[v]; !ok {
			return false
		}
	}
	return true
}

// DNSSettings describes the resolver the core runs. systemd-resolved is never
// touched: everything lives inside the core.
type DNSSettings struct {
	Mode            string   `json:"mode"`
	Servers         []string `json:"servers"`
	OnNetworkChange string   `json:"on_network_change"`
	// UseIPv6 keeps IPv6 resolvers, the IPv6 TUN address and IPv6 fakeip answers.
	UseIPv6 bool `json:"use_ipv6"`
}

// BypassSettings is the direct list: the only list there is. Anything that
// matches goes around the tunnel; nothing else does. There is no deny list
// because a deny list inside a tunnel that already routes everything is a
// second copy of the same decision.
type BypassSettings struct {
	// IPs are prefixes or single addresses ("10.0.0.0/8", "1.1.1.1").
	IPs []string `json:"ips"`
	// Domains are suffixes ("example.com", ".example.com") or keywords
	// ("*steam*"), matched on the sniffed or queried name.
	Domains []string `json:"domains"`
	// Processes are substrings of the executable path ("steam" matches
	// steamwebhelper and everything else with steam in its path).
	Processes []string `json:"processes"`
}

// KernelCongestions is every congestion control Linux can offer, best first.
// The list is the set of values the kernel accepts in
// net.ipv4.tcp_congestion_control. An entry here is a possibility, not a promise:
// an algorithm that lives in a module is registered the moment it is asked for,
// which is why the interface offers the whole catalogue and loads on apply.
//
// The order is deliberate: what helps a tunnel first, the legacy ones last.
var KernelCongestions = []string{
	"bbr",
	"cubic",
	"dctcp",
	"cdg",
	"westwood",
	"vegas",
	"illinois",
	"yeah",
	"htcp",
	"scalable",
	"hybla",
	"veno",
	"nv",
	"lp",
	"brutal",
	"bic",
	"highspeed",
	"reno",
}

// KernelQdiscs are the queue disciplines worth offering. fq is required by bbr,
// fq_codel is the usual default, cake is the AQM one.
var KernelQdiscs = []string{"fq", "fq_codel", "cake"}

// KernelStates is the tri-state used by the kernel switches: "" keeps whatever
// the machine already has, on and off write an explicit value.
var KernelStates = []string{"on", "off"}

// QuicCongestions are the values the core accepts in a TUIC node's
// congestion_control. They are implemented in the QUIC stack inside sing-box,
// not in the kernel, and the list is the enum sing-box validates against.
var QuicCongestions = []string{"cubic", "new_reno", "bbr"}

// KernelSettings is the machine-side lever set. It changes the kernel's TCP, not
// the tunnel, which is why it is separate from everything else and why an empty
// value means "leave the machine alone".
type KernelSettings struct {
	// Congestion is a value from KernelCongestions.
	Congestion string `json:"congestion,omitempty"`
	// Qdisc is a value from KernelQdiscs.
	Qdisc string `json:"qdisc,omitempty"`
	// MTUProbing is "on" or "off" for net.ipv4.tcp_mtu_probing.
	MTUProbing string `json:"mtu_probing,omitempty"`
	// SlowStartAfterIdle is "on" or "off" for tcp_slow_start_after_idle.
	SlowStartAfterIdle string `json:"slow_start_after_idle,omitempty"`
	// QuicCongestion is the congestion control inside the QUIC transport. It is
	// not a kernel value: QUIC has no kernel TCP, so this is the only way to
	// reach the transport of a TUIC node. Naive and Hysteria2 have their own
	// knobs and are left to the link.
	QuicCongestion string `json:"quic_congestion,omitempty"`
}

// Empty reports whether the set asks for nothing at all.
func (k KernelSettings) Empty() bool {
	return k == KernelSettings{}
}

// MuxProtocols are the outbound types that carry a multiplexing section at all.
// The list is not a preference: sing-box rejects an unknown field, so writing
// "multiplex" into a TUIC or Hysteria2 outbound makes the whole configuration
// undecodable and the core never starts. Everything else carries its own
// streams inside its own transport and cannot be multiplexed.
var MuxProtocols = []string{"vless", "vmess", "trojan", "shadowsocks"}

// SupportsMultiplex reports whether an outbound type accepts a multiplex section.
func SupportsMultiplex(kind string) bool {
	for _, k := range MuxProtocols {
		if k == kind {
			return true
		}
	}
	return false
}

// SmuxSettings is the multiplexing lever set.
type SmuxSettings struct {
	Enabled  bool   `json:"enabled"`
	Protocol string `json:"protocol"`
	Padding  bool   `json:"padding"`
}

// BrutalSettings is the TCP Brutal lever set.
type BrutalSettings struct {
	Enabled  bool `json:"enabled"`
	UpMbps   int  `json:"up_mbps"`
	DownMbps int  `json:"down_mbps"`
}

// KillSwitchSettings is the nftables lever set.
type KillSwitchSettings struct {
	Enabled         bool   `json:"enabled"`
	OnCrash         string `json:"on_crash"`
	OnNetworkChange string `json:"on_network_change"`
}

// Theme is the user's two accent colors. The rest of the interface is derived
// from them and the terminal defaults.
type Theme struct {
	Accent    string `json:"accent"`
	AccentAlt string `json:"accent_alt"`
}

// UnmarshalJSON keeps IPv6 on for settings files written before the toggle
// existed: an absent key means "do not touch what worked".
func (d *DNSSettings) UnmarshalJSON(raw []byte) error {
	type alias DNSSettings
	v := alias{UseIPv6: true}
	if err := json.Unmarshal(raw, &v); err != nil {
		return err
	}
	*d = DNSSettings(v)
	return nil
}

// TUNStackSingTun is sing-tun's own TCP/IP stack, which sing-box uses since
// 1.15. It is selected by leaving the stack field out of the configuration —
// the lever exists so the choice is visible, not so the config carries a name
// the core never had. On 1.14 the same empty field means mixed, so a config
// built this way still starts on the older core.
const TUNStackSingTun = "sing-tun"

// Settings is the complete lever set. There is one set, not a beginner and an
// expert one.
type Settings struct {
	Version    int    `json:"version"`
	TUNStack   string `json:"tun_stack"`
	MTU        int    `json:"mtu"`
	MultiQueue bool   `json:"multi_queue"`
	// AutoRedirect makes the TUN claim traffic that would otherwise leave through
	// the physical interface — including the queries of a loopback stub resolver
	// such as systemd-resolved on 127.0.0.53. Without it those queries never enter
	// the tunnel and are answered by the ISP.
	AutoRedirect bool               `json:"auto_redirect,omitempty"`
	DNS          DNSSettings        `json:"dns"`
	Bypass       BypassSettings     `json:"bypass"`
	Smux         SmuxSettings       `json:"smux"`
	Brutal       BrutalSettings     `json:"brutal"`
	KillSwitch   KillSwitchSettings `json:"kill_switch"`
	Kernel       KernelSettings     `json:"kernel"`
	// BBR is the previous shape of the kernel lever: one bool. It is read so
	// that an existing settings.json keeps working, and cleared by Normalize so
	// that it is never written back.
	BBR   bool  `json:"bbr,omitempty"`
	Theme Theme `json:"theme"`
	// Profile is the name of the profile these levers came from; it is shown as
	// a fact and is never used to switch anything on its own.
	Profile string `json:"profile,omitempty"`
}

// Defaults is what a fresh start uses: neutral, nothing enabled that changes
// the traffic, MTU on auto.
func Defaults() Settings {
	return Settings{
		Version:  SettingsVersion,
		TUNStack: TUNStackSingTun,
		MTU:      0,
		DNS: DNSSettings{
			Mode:            "fakeip",
			Servers:         append(append([]string(nil), DNSPresets[0].V4...), DNSPresets[0].V6...),
			OnNetworkChange: "restart",
			UseIPv6:         true,
		},
		Smux:       SmuxSettings{Enabled: false, Protocol: "smux", Padding: true},
		Brutal:     BrutalSettings{Enabled: false, UpMbps: 50, DownMbps: 200},
		KillSwitch: KillSwitchSettings{Enabled: false, OnCrash: "keep", OnNetworkChange: "flush"},
		Theme:      Theme{Accent: "#7aa2f7", AccentAlt: "#9ece6a"},
	}
}

// Normalize replaces out-of-range values with defaults instead of complaining.
// The interface shows facts; it does not argue with the file.
func (s *Settings) Normalize() {
	def := Defaults()
	if s.Version == 0 {
		s.Version = SettingsVersion
	}
	s.TUNStack = pick(s.TUNStack, TUNStacks, def.TUNStack)
	switch {
	case s.MTU < 0:
		s.MTU = 0
	case s.MTU > 0:
		s.MTU = clampInt(s.MTU, 576, 9000)
	}
	s.DNS.Mode = pick(s.DNS.Mode, DNSModes, def.DNS.Mode)
	s.DNS.OnNetworkChange = pick(s.DNS.OnNetworkChange, NetworkChangePolicies, def.DNS.OnNetworkChange)
	s.DNS.Servers = cleanServers(s.DNS.Servers, def.DNS.Servers)
	if !s.DNS.UseIPv6 {
		s.DNS.Servers = OnlyIPv4(s.DNS.Servers)
	}
	s.DNS.Servers = sanitizeServers(s.DNS.Servers)
	if len(s.DNS.Servers) == 0 {
		s.DNS.Servers = OnlyIPv4(def.DNS.Servers)
	}
	s.Bypass.IPs = cleanPrefixes(s.Bypass.IPs)
	s.Bypass.Domains = cleanList(s.Bypass.Domains)
	s.Bypass.Processes = cleanList(s.Bypass.Processes)
	s.Smux.Protocol = pick(s.Smux.Protocol, SmuxProtocols, def.Smux.Protocol)
	s.Brutal.UpMbps = clampInt(s.Brutal.UpMbps, 1, 100000)
	s.Brutal.DownMbps = clampInt(s.Brutal.DownMbps, 1, 100000)
	s.KillSwitch.OnCrash = pick(s.KillSwitch.OnCrash, KillSwitchPolicies, def.KillSwitch.OnCrash)
	s.KillSwitch.OnNetworkChange = pick(s.KillSwitch.OnNetworkChange, KillSwitchPolicies, def.KillSwitch.OnNetworkChange)
	// The kernel lever used to be a single bool; fold it into the new shape so
	// that a file written by an older build still turns bbr on.
	if s.BBR {
		if s.Kernel.Congestion == "" {
			s.Kernel.Congestion = "bbr"
		}
		s.BBR = false
	}
	s.Kernel.Congestion = keepChoice(s.Kernel.Congestion, KernelCongestions)
	s.Kernel.Qdisc = keepChoice(s.Kernel.Qdisc, KernelQdiscs)
	s.Kernel.MTUProbing = keepChoice(s.Kernel.MTUProbing, KernelStates)
	s.Kernel.SlowStartAfterIdle = keepChoice(s.Kernel.SlowStartAfterIdle, KernelStates)
	s.Kernel.QuicCongestion = keepChoice(s.Kernel.QuicCongestion, QuicCongestions)
	if !ValidColor(s.Theme.Accent) {
		s.Theme.Accent = def.Theme.Accent
	}
	if !ValidColor(s.Theme.AccentAlt) {
		s.Theme.AccentAlt = def.Theme.AccentAlt
	}
}

// Clone returns a deep copy: the DNS server list and the bypass lists are
// slices.
func (s Settings) Clone() Settings {
	c := s
	c.DNS.Servers = cloneStrings(s.DNS.Servers)
	c.Bypass.IPs = cloneStrings(s.Bypass.IPs)
	c.Bypass.Domains = cloneStrings(s.Bypass.Domains)
	c.Bypass.Processes = cloneStrings(s.Bypass.Processes)
	return c
}

// cloneStrings copies a list without losing the difference between "no list" and
// "an empty list". append([]string(nil), empty...) returns nil, so a clone of a
// normalised setting used to marshal as null where the original wrote — and two
// values that differ only that way are not equal to anyone comparing JSON, which
// is how the profile list ended up claiming every profile had been modified.
func cloneStrings(in []string) []string {
	if in == nil {
		return nil
	}
	out := make([]string, len(in))
	copy(out, in)
	return out
}

// RequiresRestart reports whether the difference between two lever sets matters
// to the running core. Anything that ends up in the configuration does; the kill
// switch, the theme and the profile name do not. Restarting for those dropped
// every connection of a working tunnel because someone picked another colour.
func (s Settings) RequiresRestart(other Settings) bool {
	if s.TUNStack != other.TUNStack || s.MTU != other.MTU || s.MultiQueue != other.MultiQueue {
		return true
	}
	if s.AutoRedirect != other.AutoRedirect {
		return true
	}
	if s.DNS.Mode != other.DNS.Mode || s.DNS.UseIPv6 != other.DNS.UseIPv6 {
		return true
	}
	if !sameStrings(s.DNS.Servers, other.DNS.Servers) {
		return true
	}
	if !sameStrings(s.Bypass.IPs, other.Bypass.IPs) ||
		!sameStrings(s.Bypass.Domains, other.Bypass.Domains) ||
		!sameStrings(s.Bypass.Processes, other.Bypass.Processes) {
		return true
	}
	if s.Smux != other.Smux || s.Brutal != other.Brutal {
		return true
	}
	// Only the QUIC congestion control is written into an outbound; the other
	// kernel values are the machine's, and the host applies them on their own.
	return s.Kernel.QuicCongestion != other.Kernel.QuicCongestion
}

// sameStrings compares two lists element by element. The order matters here: a
// resolver list is ordered, and so is the direct list.
func sameStrings(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

// LoadSettings reads the settings file. A missing file yields defaults, not an
// error: first start is a normal state.
func LoadSettings(path string) (Settings, error) {
	s := Defaults()
	raw, err := os.ReadFile(path)
	if err != nil {
		if errors.Is(err, fs.ErrNotExist) {
			s.Normalize()
			return s, nil
		}
		return s, fmt.Errorf("config: read %s: %w", path, err)
	}
	if err := json.Unmarshal(raw, &s); err != nil {
		return Defaults(), fmt.Errorf("config: parse %s: %w", path, err)
	}
	s.Normalize()
	return s, nil
}

// SaveSettings writes the settings file atomically with owner-only permissions.
func SaveSettings(path string, s Settings) error {
	s.Normalize()
	raw, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return fmt.Errorf("config: encode settings: %w", err)
	}
	return writeFileAtomic(path, append(raw, '\n'), 0o600)
}

func pick(v string, allowed []string, fallback string) string {
	for _, a := range allowed {
		if v == a {
			return v
		}
	}
	return fallback
}

// keepChoice is pick with an explicit "leave it alone" value: anything that is
// not a known choice, including "", becomes "".
func keepChoice(v string, allowed []string) string {
	for _, a := range allowed {
		if v == a {
			return v
		}
	}
	return ""
}

func clampInt(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

// ValidateServerAddress accepts an IP literal with an optional port and nothing
// else. The core has no way to look up a resolver by name: that needs another
// resolver, which is exactly the loop the error "missing domain resolver"
// reports. A preset name is not an address either, but the row that edits this
// list expands it before validating.
func ValidateServerAddress(addr string) error {
	addr = strings.TrimSpace(addr)
	if addr == "" {
		return errors.New("dns: empty server address")
	}
	host, port := addr, ""
	if h, p, err := net.SplitHostPort(addr); err == nil {
		host, port = h, p
	} else if strings.HasPrefix(addr, "[") && strings.HasSuffix(addr, "]") {
		host = strings.TrimSuffix(strings.TrimPrefix(addr, "["), "]")
	}
	if _, err := netip.ParseAddr(host); err != nil {
		return fmt.Errorf("dns: %q is not an IP address; a resolver cannot be looked up by name", addr)
	}
	if port != "" {
		n, err := strconv.Atoi(port)
		if err != nil || n < 1 || n > 65535 {
			return fmt.Errorf("dns: %q has no usable port", addr)
		}
	}
	return nil
}

// sanitizeServers keeps the unique, usable addresses. Anything the core cannot
// dial is dropped here rather than becoming a start failure later, and a list
// that goes empty falls back to the defaults.
func sanitizeServers(in []string) []string {
	seen := make(map[string]struct{}, len(in))
	out := make([]string, 0, len(in))
	for _, s := range in {
		if ValidateServerAddress(s) != nil {
			continue
		}
		if _, dup := seen[s]; dup {
			continue
		}
		seen[s] = struct{}{}
		out = append(out, s)
	}
	return out
}

// OnlyIPv4 drops IPv6 literals from a list of resolver addresses. A v6 literal is
// either bare ("2a07:…") or bracketed with a port ("[2a07:…]:53").
func OnlyIPv4(servers []string) []string {
	out := make([]string, 0, len(servers))
	for _, s := range servers {
		if isIPv6Address(s) {
			continue
		}
		out = append(out, s)
	}
	return out
}

func isIPv6Address(addr string) bool {
	if strings.HasPrefix(addr, "[") {
		// A bracketed literal is IPv6 by construction.
		return strings.HasPrefix(addr, "[") && strings.Contains(addr, "]")
	}
	// A bare IPv6 literal has more than one colon; host:port has exactly one.
	return strings.Count(addr, ":") > 1
}

// ValidPrefix accepts what the core accepts in ip_cidr: a CIDR prefix, or a
// single address, which becomes a /32 or /128.
func ValidPrefix(entry string) error {
	entry = strings.TrimSpace(entry)
	if entry == "" {
		return errors.New("empty address")
	}
	if strings.Contains(entry, "/") {
		if _, err := netip.ParsePrefix(entry); err != nil {
			return fmt.Errorf("%q is not a CIDR prefix", entry)
		}
		return nil
	}
	if _, err := netip.ParseAddr(entry); err != nil {
		return fmt.Errorf("%q is neither an address nor a CIDR prefix", entry)
	}
	return nil
}

// cleanList trims, drops empty entries and removes duplicates, keeping the order
// the user typed.
func cleanList(in []string) []string {
	seen := make(map[string]struct{}, len(in))
	out := make([]string, 0, len(in))
	for _, s := range in {
		s = strings.TrimSpace(s)
		if s == "" {
			continue
		}
		if _, dup := seen[s]; dup {
			continue
		}
		seen[s] = struct{}{}
		out = append(out, s)
	}
	return out
}

// cleanPrefixes keeps only the entries the core can use in ip_cidr: a hand
// edited file must not stop the core from starting.
func cleanPrefixes(in []string) []string {
	out := make([]string, 0, len(in))
	for _, s := range cleanList(in) {
		if ValidPrefix(s) == nil {
			out = append(out, s)
		}
	}
	return out
}

func cleanServers(in, fallback []string) []string {
	out := make([]string, 0, len(in))
	for _, s := range in {
		s = strings.TrimSpace(s)
		if s == "" {
			continue
		}
		out = append(out, s)
	}
	if len(out) == 0 {
		return append([]string(nil), fallback...)
	}
	return out
}
