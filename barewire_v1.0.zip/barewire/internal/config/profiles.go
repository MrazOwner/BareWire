package config

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"time"
)

// Profile is a named set of settings the user has already configured. It can be
// bound to a server or a network; binding is memory, not automation.
type Profile struct {
	Name string `json:"name"`
	// Note is the one-line reason a built-in preset exists.
	Note string `json:"note,omitempty"`
	// Builtin marks a profile that came with the program. It is editable like any
	// other: the mark only says where it started.
	Builtin      bool      `json:"builtin,omitempty"`
	Settings     Settings  `json:"settings"`
	BoundServer  string    `json:"bound_server,omitempty"`
	BoundNetwork string    `json:"bound_network,omitempty"`
	UpdatedAt    time.Time `json:"updated_at"`
}

// ProfileStore is the on-disk profile list.
type ProfileStore struct {
	Items []Profile `json:"items"`
	// Seeded records that the built-in presets have already been offered once.
	// Without it every load would re-add a preset the user deleted, and a list that
	// resurrects what you removed is not a list you can manage.
	Seeded bool   `json:"presets_seeded,omitempty"`
	Active string `json:"active,omitempty"`
}

// Find returns the index of the named profile.
func (s ProfileStore) Find(name string) (int, bool) {
	for i, p := range s.Items {
		if p.Name == name {
			return i, true
		}
	}
	return -1, false
}

// LoadProfiles reads the profile store. A missing file is an empty store.
func LoadProfiles(path string) (ProfileStore, error) {
	var st ProfileStore
	raw, err := os.ReadFile(path)
	if err != nil {
		if errors.Is(err, fs.ErrNotExist) {
			return st, nil
		}
		return st, fmt.Errorf("config: read %s: %w", path, err)
	}
	if err := json.Unmarshal(raw, &st); err != nil {
		return ProfileStore{}, fmt.Errorf("config: parse %s: %w", path, err)
	}
	for i := range st.Items {
		st.Items[i].Settings.Normalize()
	}
	return st, nil
}

// SaveProfiles writes the profile store atomically.
func SaveProfiles(path string, st ProfileStore) error {
	raw, err := json.MarshalIndent(st, "", "  ")
	if err != nil {
		return fmt.Errorf("config: encode profiles: %w", err)
	}
	return writeFileAtomic(path, append(raw, '\n'), 0o600)
}

// SaveProfileInto rewrites one named profile from a live lever set. It is what
// keeps the active profile in step with the interface: every change the user
// makes is saved into the profile they are editing, so switching away and back
// does not quietly undo it. A name that is not in the store is not created here —
// that is what ActivateProfile/SeedProfiles are for, and silently inventing
// profiles is how a store fills with ghosts.
func SaveProfileInto(path, name string, s Settings) error {
	if name == "" {
		return nil
	}
	st, err := LoadProfiles(path)
	if err != nil {
		return err
	}
	idx, ok := st.Find(name)
	if !ok {
		return nil
	}
	s.Profile = name
	st.Items[idx].Settings = s
	st.Items[idx].UpdatedAt = time.Now()
	return SaveProfiles(path, st)
}
