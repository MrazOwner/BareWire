package config

import "testing"

// An IPv6 endpoint needs brackets: without them "2001:db8::1:443" no longer
// parses, and every consumer that dials or resolves the endpoint — the MTU probe,
// the kill switch's allow list — got a broken address.
func TestEndpointBracketsIPv6(t *testing.T) {
	cases := []struct {
		addr string
		port int
		want string
	}{
		{"de1.example.net", 443, "de1.example.net:443"},
		{"203.0.113.7", 8443, "203.0.113.7:8443"},
		{"2001:db8::1", 443, "[2001:db8::1]:443"},
		{"[2001:db8::1]", 443, "[2001:db8::1]:443"},
	}
	for _, c := range cases {
		node := Node{Address: c.addr, Port: c.port}
		if got := node.Endpoint(); got != c.want {
			t.Errorf("Endpoint(%q) = %q, want %q", c.addr, got, c.want)
		}
	}
}

func TestLiteralAddress(t *testing.T) {
	cases := map[string]bool{
		"1.1.1.1":         true,
		"[2001:db8::1]":   true,
		"de1.example.net": false,
		"":                false,
	}
	for addr, want := range cases {
		if got := (Node{Address: addr}).LiteralAddress(); got != want {
			t.Errorf("LiteralAddress(%q) = %v, want %v", addr, got, want)
		}
	}
}
