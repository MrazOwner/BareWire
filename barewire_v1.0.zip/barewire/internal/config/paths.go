package config

import (
	"fmt"
	"os"
	"path/filepath"
)

const appDir = "barewire"

// ConfigDir is the config directory of the current session.
func ConfigDir() string {
	return ConfigDirFor(CurrentSession())
}

// RuntimeDir is the runtime directory of the current session.
func RuntimeDir() string {
	return RuntimeDirFor(CurrentSession())
}

// SettingsPath is the settings file.
func SettingsPath() string { return SettingsPathFor(CurrentSession()) }

// ProfilesPath is the profile store.
func ProfilesPath() string { return filepath.Join(ConfigDir(), "profiles.json") }

// SubscriptionsPath is the subscription store.
func SubscriptionsPath() string { return filepath.Join(ConfigDir(), "subscriptions.json") }

// HostSocketPath is where the privileged host listens.
func HostSocketPath() string { return HostSocketPathFor(CurrentSession()) }

// EnsureDir creates dir with owner-only permissions.
// EnsureDir creates a directory only this user can traverse.
func EnsureDir(dir string) error {
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return fmt.Errorf("config: create %s: %w", dir, err)
	}
	return nil
}

// HandOver gives a directory and the files in it to the session user. The host
// runs as root, and everything it writes into the user's config directory — the
// fakeip cache, the kernel trial results, the settings file it may rewrite — must
// belong to that user afterwards. A root-owned settings.json is a file the
// interface can no longer save, and nothing about it looks broken until the next
// setting change fails.
func HandOver(dir string, s Session) error {
	if os.Geteuid() != 0 || s.UID == 0 || dir == "" {
		return nil
	}
	if err := os.Chown(dir, s.UID, s.GID); err != nil {
		return fmt.Errorf("config: hand %s to uid %d: %w", dir, s.UID, err)
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil
	}
	for _, entry := range entries {
		// Chowning a file that already belongs to the user is a no-op, so the
		// whole directory is handed over without guessing which file the host
		// wrote.
		_ = os.Chown(filepath.Join(dir, entry.Name()), s.UID, s.GID)
	}
	return nil
}

// writeFileAtomic writes data to path through a temporary file and a rename, so
// a crash never leaves a half-written settings file behind.
func writeFileAtomic(path string, data []byte, mode os.FileMode) error {
	dir := filepath.Dir(path)
	if err := EnsureDir(dir); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(dir, ".barewire-*")
	if err != nil {
		return fmt.Errorf("config: temp file for %s: %w", path, err)
	}
	tmpName := tmp.Name()
	defer func() { _ = os.Remove(tmpName) }()

	if _, err := tmp.Write(data); err != nil {
		_ = tmp.Close()
		return fmt.Errorf("config: write %s: %w", path, err)
	}
	if err := tmp.Sync(); err != nil {
		_ = tmp.Close()
		return fmt.Errorf("config: sync %s: %w", path, err)
	}
	if err := tmp.Close(); err != nil {
		return fmt.Errorf("config: close %s: %w", path, err)
	}
	if err := os.Chmod(tmpName, mode); err != nil {
		return fmt.Errorf("config: chmod %s: %w", path, err)
	}
	if err := os.Rename(tmpName, path); err != nil {
		return fmt.Errorf("config: rename %s: %w", path, err)
	}
	return nil
}
