package config

import (
	"os"
	"strconv"
	"testing"
)

func TestSessionPathsForForeignUser(t *testing.T) {
	// A uid that is not this process: the process' own XDG variables must be
	// ignored. This is exactly the sudo case.
	s := Session{UID: os.Getuid() + 1, GID: os.Getgid() + 1, Home: "/home/op"}
	if got := ConfigDirFor(s); got != "/home/op/.config/barewire" {
		t.Fatalf("config dir = %q", got)
	}
	if got := SettingsPathFor(s); got != "/home/op/.config/barewire/settings.json" {
		t.Fatalf("settings path = %q", got)
	}
	uid := strconv.Itoa(s.UID)
	if got := runtimeDirFor(s, "", true); got != "/run/user/"+uid+"/barewire" {
		t.Fatalf("runtime dir = %q", got)
	}
	if got := runtimeDirFor(s, "", false); got != "/tmp/barewire-runtime-"+uid {
		t.Fatalf("runtime fallback = %q", got)
	}
}

func TestConfigDirHonoursOwnXDG(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", "/tmp/xdgcfg")
	s := Session{UID: os.Getuid(), GID: os.Getgid(), Home: "/home/op"}
	if got := ConfigDirFor(s); got != "/tmp/xdgcfg/barewire" {
		t.Fatalf("config dir = %q", got)
	}
}

func TestRuntimeDirOwnXDG(t *testing.T) {
	s := Session{UID: os.Getuid(), GID: os.Getgid(), Home: "/home/op"}
	if got := runtimeDirFor(s, "/run/user/x", true); got != "/run/user/x/barewire" {
		t.Fatalf("runtime dir = %q", got)
	}
}

func TestRuntimeDirIgnoresForeignXDG(t *testing.T) {
	// RuntimeDirFor only passes XDG_RUNTIME_DIR when the process is that user,
	// so a root host serving the user always lands in the user's run dir.
	foreign := Session{UID: 1000, GID: 1000, Home: "/home/op", Elevated: true}
	if got := runtimeDirFor(foreign, "", true); got != "/run/user/1000/barewire" {
		t.Fatalf("runtime dir = %q", got)
	}
	root := Session{UID: 0, GID: 0, Home: "/root", Elevated: true}
	if got := runtimeDirFor(root, "/run/user/0", false); got != "/run/user/0/barewire" {
		t.Fatalf("root runtime dir = %q", got)
	}
	if got := runtimeDirFor(root, "", false); got != "/tmp/barewire-runtime-0" {
		t.Fatalf("root runtime fallback = %q", got)
	}
}

func TestElevatedTargetPrefersSudo(t *testing.T) {
	env := map[string]string{"SUDO_UID": "1000", "SUDO_GID": "1001", "PKEXEC_UID": "2000"}
	get := func(k string) string { return env[k] }
	uid, gid, ok := elevatedTarget(get)
	if !ok || uid != 1000 || gid != 1001 {
		t.Fatalf("sudo target = %d, %d, %v", uid, gid, ok)
	}
}

func TestElevatedTargetAcceptsPkexec(t *testing.T) {
	env := map[string]string{"PKEXEC_UID": "1000"}
	get := func(k string) string { return env[k] }
	uid, gid, ok := elevatedTarget(get)
	if !ok || uid != 1000 || gid != -1 {
		t.Fatalf("pkexec target = %d, %d, %v (gid -1 means keep the group)", uid, gid, ok)
	}
}

func TestElevatedTargetIgnoresGarbage(t *testing.T) {
	get := func(k string) string {
		if k == "SUDO_UID" {
			return "not-a-number"
		}
		return ""
	}
	if _, _, ok := elevatedTarget(get); ok {
		t.Fatal("garbage credentials must not be accepted")
	}
	if _, _, ok := elevatedTarget(func(string) string { return "" }); ok {
		t.Fatal("no credentials means no elevation")
	}
}

func TestCurrentSessionMatchesProcess(t *testing.T) {
	s := CurrentSession()
	if s.UID < 0 {
		t.Fatalf("uid = %d", s.UID)
	}
	if s.Home == "" {
		t.Fatal("home must be resolved")
	}
	if s.UID == 0 && s.Elevated {
		t.Fatal("root without sudo credentials must not be marked elevated")
	}
}
