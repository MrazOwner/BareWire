package config

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"net"
	"os"
	"strconv"
	"strings"
	"time"
)

// Latency markers for Node.LatencyMS.
const (
	// LatencyUnknown means the node has not been measured yet.
	LatencyUnknown = -1
	// LatencyUnreachable means the last measurement got no answer.
	LatencyUnreachable = -2
)

// Node is one server parsed out of a subscription. LatencyMS is LatencyUnknown
// until the user presses ping, and LatencyUnreachable when a ping fails.
type Node struct {
	Name      string `json:"name"`
	Kind      string `json:"kind"`
	Address   string `json:"address"`
	Port      int    `json:"port"`
	LatencyMS int    `json:"latency_ms"`
	// Outbound is the complete sing-box outbound object for this node, without
	// a tag. A node without it is listed but cannot carry traffic.
	Outbound json.RawMessage `json:"outbound,omitempty"`
}

// Endpoint renders host:port for the fact lines, with brackets around an IPv6
// literal. Without them the address "2001:db8::1:443" no longer parses, so every
// consumer that dials or resolves it — the MTU probe, the kill switch's allow
// list — was quietly given a broken endpoint.
func (n Node) Endpoint() string {
	name := strings.Trim(n.Address, "[]")
	return net.JoinHostPort(name, strconv.Itoa(n.Port))
}

// LiteralAddress reports whether the server is addressed by an IP rather than a
// name. It decides whether the core may send its DNS queries through the tunnel:
// a name needs a resolver before the tunnel exists, and routing that resolver
// through the tunnel is a dependency cycle the core refuses to build.
func (n Node) LiteralAddress() bool {
	return IsIPLiteral(n.Address)
}

// Flow is the VLESS flow the link was issued with, empty when it has none.
//
// A non-empty flow rules multiplexing out: xtls-rprx-vision wraps the stream
// itself and a server refuses to multiplex it, so a config that asked for both
// produced a tunnel that came up and moved nothing.
func (n Node) Flow() string {
	if len(n.Outbound) == 0 {
		return ""
	}
	var out struct {
		Flow string `json:"flow"`
	}
	if err := json.Unmarshal(n.Outbound, &out); err != nil {
		return ""
	}
	return out.Flow
}

// IsIPLiteral reports whether host is an IP address, with or without brackets.
func IsIPLiteral(host string) bool {
	return net.ParseIP(strings.Trim(strings.TrimSpace(host), "[]")) != nil
}

// Connectable reports whether the node carries everything needed to dial.
func (n Node) Connectable() bool {
	return len(n.Outbound) > 0
}

// Subscription is one URL the user added. It is refreshed only on request.
type Subscription struct {
	Name   string `json:"name"`
	URL    string `json:"url"`
	Format string `json:"format"`
	// UserAgent is sent with the fetch. Many providers hand out different
	// answers per client and refuse an unknown one with "app not supported".
	UserAgent string    `json:"user_agent,omitempty"`
	UpdatedAt time.Time `json:"updated_at"`
	Nodes     []Node    `json:"nodes"`
}

// SubscriptionStore is the on-disk subscription list.
type SubscriptionStore struct {
	Items []Subscription `json:"items"`
}

// LoadSubscriptions reads the subscription store.
func LoadSubscriptions(path string) (SubscriptionStore, error) {
	var st SubscriptionStore
	raw, err := os.ReadFile(path)
	if err != nil {
		if errors.Is(err, fs.ErrNotExist) {
			return st, nil
		}
		return st, fmt.Errorf("config: read %s: %w", path, err)
	}
	if err := json.Unmarshal(raw, &st); err != nil {
		return SubscriptionStore{}, fmt.Errorf("config: parse %s: %w", path, err)
	}
	return st, nil
}

// SaveSubscriptions writes the subscription store atomically.
func SaveSubscriptions(path string, st SubscriptionStore) error {
	raw, err := json.MarshalIndent(st, "", "  ")
	if err != nil {
		return fmt.Errorf("config: encode subscriptions: %w", err)
	}
	return writeFileAtomic(path, append(raw, '\n'), 0o600)
}
