package config

// The TUN carries inner packets; the tunnel wraps them in its own transport.
// The two numbers are not the same, and using the path MTU as the TUN MTU makes
// every large inner packet too big for the path: a handshake works, a download
// stalls, and nothing says why. These constants are the bounds of the value the
// tunnel can actually carry.
const (
	// MinTunnelMTU is the IPv6 minimum and the floor below which inner TCP
	// stops working usefully.
	MinTunnelMTU = 1280
	// MaxTunnelMTU is 1500 minus one outer IP+TCP header and a small margin: no
	// encapsulation makes an inner packet this size too big for Ethernet even
	// with the lightest transport.
	MaxTunnelMTU = 1452
	// OuterHeaderLen is the outer IP and TCP header the kernel adds to every
	// segment that carries tunnel data.
	OuterHeaderLen = 40
)

// tunnelOverhead is the per-packet cost of each transport, TLS and AEAD
// included. The numbers are deliberately pessimistic: a packet that is a few
// bytes smaller than it could be costs nothing, one that is a few bytes larger
// is a black hole.
var tunnelOverheads = map[string]int{
	"vless":       70, // VLESS header plus a TLS record when the link uses TLS
	"vmess":       100,
	"trojan":      90, // trojan always sits inside TLS
	"shadowsocks": 60,
	"anytls":      90,
	"tuic":        100, // QUIC header, AEAD tag and the sender's own MTU rule
	"hysteria2":   100,
	"wireguard":   80,
	"shadowtls":   90,
}

// udpTransports reach their server over UDP only. Their port completes no TCP
// handshake, so a probe that reads the negotiated MSS cannot measure them at
// all: it spends the timeout and reports nothing.
var udpTransports = map[string]bool{
	"hysteria":  true,
	"hysteria2": true,
	"tuic":      true,
	"wireguard": true,
}

// IsUDPTransport reports whether the transport talks to its server over UDP
// alone, which decides how the path can be measured.
func IsUDPTransport(kind string) bool {
	return udpTransports[kind]
}

// TunnelOverhead is how many bytes a transport adds to one inner packet.
func TunnelOverhead(kind string) int {
	if bytes, ok := tunnelOverheads[kind]; ok {
		return bytes
	}
	return 80
}

// TunnelMTUCeiling is the largest inner MTU the path can carry through a tunnel
// of this kind. It returns 0 when the path MTU is unknown: a guess would be
// worse than the configured value, because only the probe knows the path.
func TunnelMTUCeiling(pathMTU int, kind string) int {
	if pathMTU <= 0 {
		return 0
	}
	ceiling := pathMTU - OuterHeaderLen - TunnelOverhead(kind)
	if ceiling > MaxTunnelMTU {
		ceiling = MaxTunnelMTU
	}
	if ceiling < MinTunnelMTU {
		ceiling = MinTunnelMTU
	}
	return ceiling
}

// TunnelMTU resolves the MTU to write into the TUN inbound, and reports whether
// it had to be lowered. The configured value wins while it fits: the ceiling is
// a fact about the path, not a preference.
func TunnelMTU(configured, pathMTU int, kind string) (int, bool) {
	if configured <= 0 {
		configured = DefaultTunnelMTU
	}
	ceiling := TunnelMTUCeiling(pathMTU, kind)
	if ceiling == 0 || configured <= ceiling {
		return configured, false
	}
	return ceiling, true
}

// DefaultTunnelMTU is what a TUN gets when nothing was measured and the user did
// not choose: the value every tunnel carries on Ethernet and Wi-Fi without
// fragmenting.
const DefaultTunnelMTU = 1420
