package config

import (
	"encoding/json"
	"path/filepath"
	"testing"
)

// A clone has to be indistinguishable from the original: the profile list compares
// two lever sets by JSON, so a clone that loses "an empty list" versus "no list"
// made every profile look edited.
func TestClonePreservesEmptyLists(t *testing.T) {
	s := Defaults()
	s.Normalize()
	c := s.Clone()

	before, err := json.Marshal(s)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	after, err := json.Marshal(c)
	if err != nil {
		t.Fatalf("marshal clone: %v", err)
	}
	if string(before) != string(after) {
		t.Fatalf("clone differs:\n%s\n%s", before, after)
	}
	// A clone must not share its slices with the original.
	c.Bypass.IPs = append(c.Bypass.IPs, "10.0.0.0/8")
	if len(s.Bypass.IPs) != 0 {
		t.Fatal("the clone shares its slice with the original")
	}
}

// A preset is a promise: press it and the levers land somewhere sane. Every one
// has to survive Normalize unchanged, stay inside the bounds the core accepts, and
// leave multiplexing and Brutal alone — those depend on what the server speaks.
func TestPresetsAreSane(t *testing.T) {
	presets := Presets()
	if len(presets) < 3 {
		t.Fatalf("%d presets, want a set worth choosing from", len(presets))
	}
	seen := map[string]bool{}
	for _, p := range presets {
		if p.Name == "" || p.Note == "" {
			t.Errorf("preset %q has no name or no note", p.Name)
		}
		if seen[p.Name] {
			t.Errorf("duplicate preset name %q", p.Name)
		}
		seen[p.Name] = true

		s := p.Settings.Clone()
		before, _ := json.Marshal(s)
		s.Normalize()
		after, _ := json.Marshal(s)
		if string(before) != string(after) {
			t.Errorf("preset %q changes under Normalize:\n%s\n%s", p.Name, before, after)
		}
		if s.MTU != 0 && (s.MTU < MinTunnelMTU || s.MTU > MaxTunnelMTU) {
			t.Errorf("preset %q: mtu %d outside %d..%d", p.Name, s.MTU, MinTunnelMTU, MaxTunnelMTU)
		}
		if s.Smux.Enabled || s.Brutal.Enabled {
			t.Errorf("preset %q must not decide on multiplexing or Brutal: those need the server", p.Name)
		}
		if s.Profile != p.Name {
			t.Errorf("preset %q carries profile name %q", p.Name, s.Profile)
		}
	}
	if _, ok := PresetByName("balanced"); !ok {
		t.Error("the default preset has to exist by name")
	}
}

// Seeding merges the presets into whatever the store already has, once. A store
// that only had the user's own profile is the case that failed: the presets were
// skipped entirely because the list was not empty.
func TestSeedProfilesAddsWhatIsMissing(t *testing.T) {
	seeded, changed := SeedProfiles(ProfileStore{})
	if !changed || len(seeded.Items) != len(Presets()) {
		t.Fatalf("seeded %d profiles (changed %v), want %d", len(seeded.Items), changed, len(Presets()))
	}
	for _, p := range seeded.Items {
		if !p.Builtin || p.Note == "" {
			t.Errorf("seeded profile %q is not marked as built-in or has no note", p.Name)
		}
		if p.Settings.Profile != p.Name {
			t.Errorf("seeded profile %q has settings labelled %q", p.Name, p.Settings.Profile)
		}
	}
	if !seeded.Seeded {
		t.Error("the store has to remember that it was seeded")
	}

	// An install with a profile of its own keeps it and gains the presets.
	own := ProfileStore{Items: []Profile{{Name: "mine", Settings: Defaults()}}}
	merged, changed := SeedProfiles(own)
	if !changed {
		t.Fatal("a store without the presets has to gain them")
	}
	if _, ok := merged.Find("mine"); !ok {
		t.Fatal("the user's own profile disappeared")
	}
	if len(merged.Items) != len(Presets())+1 {
		t.Fatalf("%d items, want the presets plus the user's own", len(merged.Items))
	}

	// A name that is taken is never overwritten: the user's version wins.
	taken := ProfileStore{Items: []Profile{{Name: "balanced", Settings: Defaults()}}}
	merged, _ = SeedProfiles(taken)
	idx, ok := merged.Find("balanced")
	if !ok || merged.Items[idx].Builtin {
		t.Fatal("an existing profile with a preset's name must be left as it is")
	}

	// Once seeded, nothing is added again — a preset the user deleted stays deleted.
	again, changed := SeedProfiles(seeded)
	if changed || len(again.Items) != len(seeded.Items) {
		t.Fatalf("a seeded store changed again: %d items", len(again.Items))
	}
	emptied := ProfileStore{Seeded: true}
	if after, changed := SeedProfiles(emptied); changed || len(after.Items) != 0 {
		t.Fatal("presets must not come back after the user removed them")
	}
}

// The settings screen writes the profile it is editing on every change; that is
// what stops "activate" from silently undoing the work.
func TestSaveProfileIntoUpdatesTheNamedProfile(t *testing.T) {
	path := filepath.Join(t.TempDir(), "profiles.json")
	st, _ := SeedProfiles(ProfileStore{})
	if err := SaveProfiles(path, st); err != nil {
		t.Fatalf("save: %v", err)
	}

	edited := st.Items[0].Settings.Clone()
	edited.MTU = 1300
	edited.DNS.Servers = []string{"9.9.9.9"}
	if err := SaveProfileInto(path, st.Items[0].Name, edited); err != nil {
		t.Fatalf("save profile: %v", err)
	}

	back, err := LoadProfiles(path)
	if err != nil {
		t.Fatalf("load: %v", err)
	}
	idx, ok := back.Find(st.Items[0].Name)
	if !ok {
		t.Fatalf("%q disappeared", st.Items[0].Name)
	}
	if back.Items[idx].Settings.MTU != 1300 || back.Items[idx].Settings.DNS.Servers[0] != "9.9.9.9" {
		t.Fatalf("profile not updated: %+v", back.Items[idx].Settings)
	}
	if back.Items[idx].Settings.Profile != st.Items[0].Name {
		t.Fatalf("profile name lost: %q", back.Items[idx].Settings.Profile)
	}

	// A name that is not in the store is not created: silently inventing profiles
	// is how a list fills with ghosts.
	if err := SaveProfileInto(path, "does-not-exist", edited); err != nil {
		t.Fatalf("unknown name: %v", err)
	}
	back, _ = LoadProfiles(path)
	if len(back.Items) != len(st.Items) {
		t.Fatalf("an unknown name created a profile: %d items", len(back.Items))
	}
	if err := SaveProfileInto(path, "", edited); err != nil {
		t.Fatalf("empty name: %v", err)
	}
}
