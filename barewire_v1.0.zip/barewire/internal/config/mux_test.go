package config

import "testing"

// The list is the source of truth for two decisions: whether a multiplex section
// is written at all, and whether a mux/Brutal lever can do anything.
func TestSupportsMultiplex(t *testing.T) {
	for _, kind := range MuxProtocols {
		if !SupportsMultiplex(kind) {
			t.Fatalf("%q must support multiplexing", kind)
		}
	}
	for _, kind := range []string{"tuic", "hysteria2", "hysteria", "wireguard", "anytls", "socks", "http", ""} {
		if SupportsMultiplex(kind) {
			t.Fatalf("%q has no multiplex section", kind)
		}
	}
}
