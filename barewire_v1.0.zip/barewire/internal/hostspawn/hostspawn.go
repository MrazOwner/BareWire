// Package hostspawn starts the privileged host from the interface, so the user
// needs one command and one terminal. The host is started on the first Connect
// and stopped when the interface exits: nothing runs in the background on its
// own.
package hostspawn

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/hostclient"
	"github.com/mrazowner/barewire/internal/hostsock"
)

// waitTimeout bounds how long the interface waits for the host to appear. It has
// to cover a polkit password prompt, so it is generous.
const waitTimeout = 60 * time.Second

// Starter launches barewire-host and connects to it.
type Starter struct {
	// Socket is the path the host will listen on.
	Socket string
	// Binary is the host executable; resolved when empty.
	Binary string
	// LogPath receives the host's stderr.
	LogPath string
	// Wait bounds how long the interface waits for the socket to appear.
	Wait time.Duration
	// Dial connects to an existing host; replaced in tests.
	Dial func(string) (hostclient.Client, error)
	// Command builds the elevated command; replaced in tests.
	Command func(binary string) *exec.Cmd
}

// New returns a starter for the current session.
func New() *Starter {
	session := config.CurrentSession()
	dir := config.RuntimeDirFor(session)
	return &Starter{
		Socket:  filepath.Join(dir, "host.sock"),
		LogPath: filepath.Join(dir, "host.log"),
		Wait:    waitTimeout,
		Dial:    func(path string) (hostclient.Client, error) { return hostsock.Dial(path) },
		Command: elevatedCommand,
	}
}

// Start returns a client for a running host, launching one when the socket is
// absent. Every failure is returned, never swallowed.
func (s *Starter) Start(ctx context.Context) (hostclient.Client, error) {
	dial := s.Dial
	if dial == nil {
		dial = func(path string) (hostclient.Client, error) { return hostsock.Dial(path) }
	}
	commandFor := s.Command
	if commandFor == nil {
		commandFor = elevatedCommand
	}
	wait := s.Wait
	if wait <= 0 {
		wait = waitTimeout
	}

	if client, err := dial(s.Socket); err == nil {
		return client, nil
	}

	binary, err := s.resolveBinary()
	if err != nil {
		return nil, err
	}
	if err := config.EnsureDir(filepath.Dir(s.Socket)); err != nil {
		return nil, err
	}
	logFile, err := os.OpenFile(s.LogPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o600)
	if err != nil {
		return nil, fmt.Errorf("host: open log %s: %w", s.LogPath, err)
	}
	defer func() { _ = logFile.Close() }()

	cmd := commandFor(binary)
	cmd.Stdout = logFile
	cmd.Stderr = logFile
	cmd.Stdin = nil
	if err := cmd.Start(); err != nil {
		return nil, fmt.Errorf("host: launch %s: %w", binary, err)
	}
	// Reap the child and notice an early exit: a refused authorisation or a
	// missing privilege must be reported now, not after the timeout.
	exited := make(chan error, 1)
	go func() { exited <- cmd.Wait() }()

	deadline := time.Now().Add(wait)
	for {
		if client, err := dial(s.Socket); err == nil {
			return client, nil
		}
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		case err := <-exited:
			return nil, fmt.Errorf("host: exited before listening: %v (log: %s)", describeExit(err), tailOf(s.LogPath))
		case <-time.After(120 * time.Millisecond):
		}
		if time.Now().After(deadline) {
			return nil, fmt.Errorf("host: no socket at %s after %s (log: %s)", s.Socket, wait, tailOf(s.LogPath))
		}
	}
}

// describeExit turns the exit code of an elevated launch into something the user
// can act on. 126/127 are what pkexec and sudo use for "not authorised".
func describeExit(err error) string {
	if err == nil {
		return "exited cleanly without listening"
	}
	var exitErr *exec.ExitError
	if errors.As(err, &exitErr) {
		switch exitErr.ExitCode() {
		case 126:
			return "authorisation refused or dismissed (" + err.Error() + ")"
		case 127:
			return "host binary not found by the launcher (" + err.Error() + ")"
		}
	}
	return err.Error()
}

// tailOf returns the last few lines of a file, for error messages that would
// otherwise force the user to go looking.
// Tail returns the last n lines of a file, for messages that would otherwise
// force the reader to go looking. A file that cannot be read yields nothing: the
// caller is already reporting a failure, and two failures in one line help
// nobody.
func Tail(path string, n int) []string {
	if n <= 0 {
		n = 3
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	lines := bytes.Split(bytes.TrimSpace(raw), []byte("\n"))
	if len(lines) > n {
		lines = lines[len(lines)-n:]
	}
	out := make([]string, 0, len(lines))
	for _, line := range lines {
		if text := string(bytes.TrimSpace(line)); text != "" {
			out = append(out, text)
		}
	}
	return out
}

// tailOf is Tail in one line, for error messages.
func tailOf(path string) string {
	lines := Tail(path, 3)
	if len(lines) == 0 {
		return path
	}
	return path + ": " + strings.Join(lines, " | ")
}

// resolveBinary finds barewire-host next to this executable first, then in PATH.
// pkexec runs with a reduced PATH, so an absolute path matters.
func (s *Starter) resolveBinary() (string, error) {
	if s.Binary != "" {
		if info, err := os.Stat(s.Binary); err != nil || info.IsDir() {
			return "", fmt.Errorf("host: %s is not an executable file", s.Binary)
		}
		return s.Binary, nil
	}
	if exe, err := os.Executable(); err == nil {
		candidate := filepath.Join(filepath.Dir(exe), "barewire-host")
		if info, err := os.Stat(candidate); err == nil && !info.IsDir() {
			return candidate, nil
		}
	}
	if path, err := exec.LookPath("barewire-host"); err == nil {
		return path, nil
	}
	return "", errors.New("host: barewire-host not found next to the interface or in PATH")
}

// elevatedCommand builds the command that asks the desktop for authorisation.
func elevatedCommand(binary string) *exec.Cmd {
	if pkexec, err := exec.LookPath("pkexec"); err == nil {
		return exec.Command(pkexec, binary)
	}
	// Without polkit there is no way to ask for a password without taking the
	// terminal away from the interface, so only a cached sudo ticket is used.
	// The failure is immediate and names the log.
	return exec.Command("sudo", "-n", binary)
}
