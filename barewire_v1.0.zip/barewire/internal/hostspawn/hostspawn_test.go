package hostspawn

import (
	"context"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/hostclient"
	"github.com/mrazowner/barewire/internal/proto"
)

// stubClient satisfies hostclient.Client without a socket.
type stubClient struct{ events chan proto.Event }

var _ hostclient.Client = (*stubClient)(nil)

func (c *stubClient) Snapshot() proto.Status                   { return proto.Status{HostRunning: true} }
func (c *stubClient) Events() <-chan proto.Event               { return c.events }
func (c *stubClient) Connect() error                           { return nil }
func (c *stubClient) Disconnect() error                        { return nil }
func (c *stubClient) Apply(config.Settings) error              { return nil }
func (c *stubClient) SelectNode(config.Node) error             { return nil }
func (c *stubClient) FlushKillSwitch() error                   { return nil }
func (c *stubClient) AutoMTU() (int, error)                    { return 0, nil }
func (c *stubClient) AutoBrutal() (int, int, error)            { return 0, 0, nil }
func (c *stubClient) TestKernel() ([]proto.KernelTrial, error) { return nil, nil }
func (c *stubClient) Connections() []proto.Connection          { return nil }
func (c *stubClient) Close() error                             { return nil }

func TestStartUsesRunningHost(t *testing.T) {
	stub := &stubClient{events: make(chan proto.Event)}
	s := &Starter{
		Socket: filepath.Join(t.TempDir(), "host.sock"),
		Wait:   time.Second,
		Dial:   func(string) (hostclient.Client, error) { return stub, nil },
	}
	client, err := s.Start(context.Background())
	if err != nil {
		t.Fatalf("start: %v", err)
	}
	if client != stub {
		t.Fatal("Start must return the client the dial produced")
	}
}

func TestStartFailsWhenHostNeverAppears(t *testing.T) {
	dir := t.TempDir()
	binary := filepath.Join(dir, "barewire-host")
	if err := os.WriteFile(binary, []byte("#!/bin/sh\nexit 0\n"), 0o755); err != nil {
		t.Fatal(err)
	}
	s := &Starter{
		Socket:  filepath.Join(dir, "host.sock"),
		LogPath: filepath.Join(dir, "host.log"),
		Wait:    250 * time.Millisecond,
		Dial:    func(string) (hostclient.Client, error) { return nil, errors.New("no socket") },
		Binary:  binary,
		Command: func(string) *exec.Cmd { return exec.Command("true") },
	}
	_, err := s.Start(context.Background())
	if err == nil {
		t.Fatal("expected an error when the host never appears")
	}
	if !contains(err.Error(), "no socket at") && !contains(err.Error(), "exited before listening") {
		t.Fatalf("error must explain the failure: %v", err)
	}
}

func TestStartReportsMissingBinary(t *testing.T) {
	s := &Starter{
		Socket:  filepath.Join(t.TempDir(), "host.sock"),
		LogPath: filepath.Join(t.TempDir(), "host.log"),
		Wait:    time.Second,
		Dial:    func(string) (hostclient.Client, error) { return nil, errors.New("no socket") },
		Binary:  filepath.Join(t.TempDir(), "definitely-missing"),
	}
	_, err := s.Start(context.Background())
	if err == nil {
		t.Fatal("expected an error for a missing host binary")
	}
}

func TestResolveBinaryPrefersConfiguredPath(t *testing.T) {
	dir := t.TempDir()
	binary := filepath.Join(dir, "barewire-host")
	if err := os.WriteFile(binary, []byte("#!/bin/sh\n"), 0o755); err != nil {
		t.Fatal(err)
	}
	got, err := (&Starter{Binary: binary}).resolveBinary()
	if err != nil {
		t.Fatalf("resolve: %v", err)
	}
	if got != binary {
		t.Fatalf("resolved %q, want %q", got, binary)
	}
}

func TestDescribeExitExplainsAuthorisation(t *testing.T) {
	cmd := exec.Command("sh", "-c", "exit 126")
	err := cmd.Run()
	if err == nil {
		t.Fatal("expected an exit error")
	}
	msg := describeExit(err)
	if !contains(msg, "authorisation") {
		t.Fatalf("exit 126 must be explained as a refused authorisation: %q", msg)
	}
	cmd = exec.Command("sh", "-c", "exit 127")
	if msg := describeExit(cmd.Run()); !contains(msg, "not found") {
		t.Fatalf("exit 127 must be explained as a missing binary: %q", msg)
	}
	if msg := describeExit(nil); !contains(msg, "cleanly") {
		t.Fatalf("a clean exit needs its own wording: %q", msg)
	}
}

func contains(s, sub string) bool {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}
