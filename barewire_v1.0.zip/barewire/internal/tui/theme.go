package tui

import (
	"os"
	"strings"

	"github.com/charmbracelet/lipgloss"

	"github.com/mrazowner/barewire/internal/config"
)

// Palette is the user's two accent colors plus a switch for terminals that
// cannot show color at all.
type Palette struct {
	Accent    string
	AccentAlt string
	Colored   bool
}

// PaletteFrom reads the theme out of the settings.
func PaletteFrom(s config.Settings) Palette {
	return Palette{
		Accent:    s.Theme.Accent,
		AccentAlt: s.Theme.AccentAlt,
		Colored:   ColorEnabled(),
	}
}

// ColorEnabled reports whether the terminal can show color. NO_COLOR and a dumb
// terminal turn the interface into a monochrome one instead of a broken one.
func ColorEnabled() bool {
	if os.Getenv("NO_COLOR") != "" {
		return false
	}
	return !strings.EqualFold(os.Getenv("TERM"), "dumb")
}

// Styles is the rendered style set. Only two accent hues exist; everything else
// is the terminal default with weight, underline or dim.
type Styles struct {
	Brand   lipgloss.Style // the product name in the header
	TabOn   lipgloss.Style // the active tab
	TabOff  lipgloss.Style // the other tabs
	Rule    lipgloss.Style // separators and box borders
	BoxName lipgloss.Style // the title inside a box border
	Label   lipgloss.Style // fact labels
	Value   lipgloss.Style // fact values
	Key     lipgloss.Style // key hints
	Dim     lipgloss.Style // small print
	Sel     lipgloss.Style // the focused row
	Accent  lipgloss.Style // structural accent
	Alt     lipgloss.Style // second accent, used for values that change
	Err     lipgloss.Style
	Warn    lipgloss.Style
}

// Styles builds the style set. When color is off the hues are simply not set,
// so weight and underlines carry the structure.
func (p Palette) Styles() Styles {
	fg := func(color string, bold, underline bool) lipgloss.Style {
		st := lipgloss.NewStyle()
		if bold {
			st = st.Bold(true)
		}
		if underline {
			st = st.Underline(true)
		}
		if p.Colored && color != "" {
			st = st.Foreground(lipgloss.Color(color))
		}
		return st
	}

	return Styles{
		Brand:   fg(p.Accent, true, false),
		TabOn:   fg(p.Accent, true, true),
		TabOff:  lipgloss.NewStyle().Faint(true),
		Rule:    lipgloss.NewStyle().Faint(true),
		BoxName: fg(p.Accent, true, false),
		Label:   lipgloss.NewStyle().Faint(true),
		Value:   fg("", false, false),
		Key:     fg(p.Accent, true, false),
		Dim:     lipgloss.NewStyle().Faint(true),
		Sel:     fg(p.Accent, true, false),
		Accent:  fg(p.Accent, false, false),
		Alt:     fg(p.AccentAlt, false, false),
		Err:     fg(p.AccentAlt, true, true),
		Warn:    lipgloss.NewStyle().Bold(true),
	}
}

// LevelStyle maps a log level onto the two available accents.
func (s Styles) LevelStyle(level string) lipgloss.Style {
	switch level {
	case "error":
		return s.Err
	case "warn":
		return s.Warn
	case "debug":
		return s.Dim
	default:
		return lipgloss.NewStyle()
	}
}

// Swatch renders a color sample for the theme picker.
func (p Palette) Swatch(color string) string {
	if !p.Colored {
		return "■"
	}
	return lipgloss.NewStyle().Foreground(lipgloss.Color(color)).Render("■")
}
