package tui

import (
	"strings"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/proto"
)

type rowKind int

const (
	rowHeader rowKind = iota
	rowChoice
	rowToggle
	rowNumber
	rowText
	rowColor
	rowAction
	rowInfo
)

// formRow is one lever. Every row is always visible: there is no beginner mode.
type formRow struct {
	label  string
	kind   rowKind
	value  func(*Model) string
	adjust func(*Model, int)
	text   func(*Model) string
	commit func(*Model, string) (string, error)
	run    func(*Model) tea.Cmd
	note   func(*Model) string
}

type settingsScreen struct {
	w, h    int
	rows    []formRow
	cursor  int
	scroll  int
	editing bool
	input   Input
	errLine string
}

func newSettingsScreen() *settingsScreen {
	s := &settingsScreen{rows: buildSettingsRows()}
	s.snapCursor()
	return s
}

func (s *settingsScreen) Resize(w, h int) {
	s.w, s.h = w, h
}

func (s *settingsScreen) Capturing() bool { return s.editing }

func (s *settingsScreen) Hints() []Hint {
	if s.editing {
		return []Hint{{"enter", "commit"}, {"esc", "cancel"}}
	}
	return []Hint{
		{"j/k", "move"},
		{"space", "toggle/cycle"},
		{"h/l", "adjust"},
		{"enter", "edit/run"},
	}
}

func (s *settingsScreen) Body(m *Model, w, h int) []string {
	sty := m.styles
	if len(s.rows) == 0 || h < 1 {
		return nil
	}
	all, cursorLine := s.renderLines(m, w)
	if len(all) <= h {
		s.scroll = 0
		return all
	}
	start := s.scroll
	if cursorLine >= 0 {
		if cursorLine < start {
			start = cursorLine
		}
		if cursorLine >= start+h {
			start = cursorLine - h + 1
		}
	}
	if maxStart := len(all) - h; start > maxStart {
		start = maxStart
	}
	if start < 0 {
		start = 0
	}
	out := append([]string(nil), all[start:start+h]...)
	if start+h < len(all) && start+h-1 != cursorLine {
		out[h-1] = sty.Dim.Render("↓ more")
	}
	s.scroll = start
	return out
}

// renderLines renders every row and reports the line index of the cursor, so the
// window can always include it. Rendering everything is cheap: the lever list is
// a few dozen rows.
func (s *settingsScreen) renderLines(m *Model, w int) ([]string, int) {
	sty := m.styles
	out := make([]string, 0, len(s.rows)+8)
	cursorLine := -1
	for i, row := range s.rows {
		switch row.kind {
		case rowHeader:
			if i != 0 {
				out = append(out, "")
			}
			out = append(out, sty.Accent.Render(strings.ToUpper(row.label)))
			continue
		case rowInfo:
			val := row.value(m)
			out = append(out, twoCols(sty.Label.Render(padRight("  "+row.label, 28)), sty.Dim.Render(val), w))
			continue
		}

		focused := i == s.cursor
		marker := "  "
		if focused {
			marker = sty.Sel.Render("› ")
		}
		label := sty.Label.Render(padRight("  "+row.label, 28))
		var line string
		if focused && s.editing {
			width := w - 30
			if width < 8 {
				width = 8
			}
			line = marker + label + s.input.View(width)
		} else {
			line = marker + label + row.value(m)
			if row.note != nil {
				if note := row.note(m); note != "" {
					line = twoCols(line, sty.Dim.Render(note), w)
				}
			}
		}
		if focused {
			cursorLine = len(out)
		}
		out = append(out, line)
	}
	if s.errLine != "" {
		out = append(out, sty.Err.Render(clip(s.errLine, w)))
	}
	return out, cursorLine
}

func (s *settingsScreen) Update(msg tea.Msg, m *Model) tea.Cmd {
	key, ok := msg.(tea.KeyMsg)
	if !ok {
		return nil
	}
	if s.editing {
		return s.handleEdit(key, m)
	}
	switch key.String() {
	case "j", "down":
		s.move(1)
	case "k", "up":
		s.move(-1)
	case "g":
		s.cursor = 0
		s.snapCursor()
	case "G":
		s.cursor = len(s.rows) - 1
		s.snapCursor()
	case "h", "left":
		s.adjust(m, -1)
	case "l", "right", " ":
		s.adjust(m, 1)
	case "enter":
		return s.activate(m)
	case "esc":
		s.errLine = ""
	}
	return nil
}

func (s *settingsScreen) handleEdit(key tea.KeyMsg, m *Model) tea.Cmd {
	switch key.String() {
	case "esc":
		s.editing = false
		s.errLine = ""
	case "enter":
		row := s.rows[s.cursor]
		if row.commit == nil {
			s.editing = false
			return nil
		}
		note, err := row.commit(m, s.input.Value)
		if err != nil {
			s.errLine = err.Error()
			return nil
		}
		s.editing = false
		s.errLine = ""
		if note != "" {
			m.logf(proto.LevelInfo, "%s", note)
		}
	case "backspace":
		s.input.Backspace()
	case "delete":
		s.input.Delete()
	case "left":
		s.input.Left()
	case "right":
		s.input.Right()
	case "home", "ctrl+a":
		s.input.Home()
	case "end", "ctrl+e":
		s.input.End()
	default:
		for _, r := range key.Runes {
			s.input.Insert(r)
		}
	}
	return nil
}

// move advances the cursor to the next selectable row.
func (s *settingsScreen) move(delta int) {
	for i := 0; i < len(s.rows); i++ {
		s.cursor += delta
		if s.cursor < 0 {
			s.cursor = 0
			break
		}
		if s.cursor >= len(s.rows) {
			s.cursor = len(s.rows) - 1
			break
		}
		if s.selectable(s.cursor) {
			break
		}
	}
}

func (s *settingsScreen) snapCursor() {
	if s.selectable(s.cursor) {
		return
	}
	for i := range s.rows {
		if s.selectable(i) {
			s.cursor = i
			return
		}
	}
}

func (s *settingsScreen) selectable(i int) bool {
	if i < 0 || i >= len(s.rows) {
		return false
	}
	switch s.rows[i].kind {
	case rowHeader, rowInfo:
		return false
	default:
		return true
	}
}

func (s *settingsScreen) adjust(m *Model, delta int) {
	if !s.selectable(s.cursor) {
		return
	}
	row := s.rows[s.cursor]
	if row.adjust != nil {
		row.adjust(m, delta)
	}
}

func (s *settingsScreen) activate(m *Model) tea.Cmd {
	if !s.selectable(s.cursor) {
		return nil
	}
	row := s.rows[s.cursor]
	switch row.kind {
	case rowAction:
		if row.run != nil {
			return row.run(m)
		}
	case rowChoice, rowToggle:
		s.adjust(m, 1)
	case rowNumber, rowText, rowColor:
		if row.text != nil {
			s.editing = true
			s.errLine = ""
			s.input.Set(row.text(m))
		}
	}
	return nil
}
