package tui

import (
	"strings"

	"github.com/charmbracelet/lipgloss"
)

// Input is a single-line text editor with a visible cursor block. It exists so
// that the interface needs no widget library to edit a hex color or a URL.
type Input struct {
	Value  string
	Cursor int
}

// Set replaces the value and puts the cursor at the end.
func (i *Input) Set(v string) {
	i.Value = v
	i.Cursor = len([]rune(v))
}

// Reset clears the input.
func (i *Input) Reset() { i.Set("") }

func (i *Input) runes() []rune { return []rune(i.Value) }

func (i *Input) store(r []rune) {
	i.Value = string(r)
	if i.Cursor > len(r) {
		i.Cursor = len(r)
	}
}

// Insert writes ch at the cursor.
func (i *Input) Insert(ch rune) {
	r := i.runes()
	if i.Cursor < 0 {
		i.Cursor = 0
	}
	if i.Cursor > len(r) {
		i.Cursor = len(r)
	}
	r = append(r[:i.Cursor], append([]rune{ch}, r[i.Cursor:]...)...)
	i.Cursor++
	i.store(r)
}

// Backspace removes the rune before the cursor.
func (i *Input) Backspace() {
	r := i.runes()
	if i.Cursor <= 0 || len(r) == 0 {
		return
	}
	if i.Cursor > len(r) {
		i.Cursor = len(r)
	}
	r = append(r[:i.Cursor-1], r[i.Cursor:]...)
	i.Cursor--
	i.store(r)
}

// Delete removes the rune under the cursor.
func (i *Input) Delete() {
	r := i.runes()
	if i.Cursor < 0 || i.Cursor >= len(r) {
		return
	}
	r = append(r[:i.Cursor], r[i.Cursor+1:]...)
	i.store(r)
}

// Left moves the cursor one rune left.
func (i *Input) Left() {
	if i.Cursor > 0 {
		i.Cursor--
	}
}

// Right moves the cursor one rune right.
func (i *Input) Right() {
	if i.Cursor < len(i.runes()) {
		i.Cursor++
	}
}

// Home moves the cursor to the start.
func (i *Input) Home() { i.Cursor = 0 }

// End moves the cursor to the end.
func (i *Input) End() { i.Cursor = len(i.runes()) }

// View renders the input inside width cells with a reversed cursor cell.
func (i *Input) View(width int) string {
	if width <= 1 {
		return ""
	}
	r := i.runes()
	c := i.Cursor
	if c > len(r) {
		c = len(r)
	}
	if c < 0 {
		c = 0
	}
	start := 0
	if c >= width {
		start = c - width + 1
	}
	end := start + width - 1
	if end > len(r) {
		end = len(r)
	}

	var b strings.Builder
	b.WriteString(string(r[start:c]))
	ch := " "
	if c < len(r) {
		ch = string(r[c])
	}
	b.WriteString(lipgloss.NewStyle().Reverse(true).Render(ch))
	if c+1 < end {
		b.WriteString(string(r[c+1 : end]))
	}
	return b.String()
}
