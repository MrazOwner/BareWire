package tui

import (
	"strings"
	"testing"
	"time"

	"github.com/mrazowner/barewire/internal/proto"
)

func TestClipAndPad(t *testing.T) {
	if got := clip("abcdef", 4); got != "abc…" {
		t.Fatalf("clip = %q", got)
	}
	if got := clip("abc", 5); got != "abc" {
		t.Fatalf("clip of short string = %q", got)
	}
	if got := padRight("abc", 5); got != "abc  " {
		t.Fatalf("padRight = %q", got)
	}
	if got := padLeft("abc", 5); got != "  abc" {
		t.Fatalf("padLeft = %q", got)
	}
	if got := fit("abcdef", 4); got != "abc…" {
		t.Fatalf("fit = %q", got)
	}
	if got := clip("anything", 0); got != "" {
		t.Fatalf("clip to zero = %q", got)
	}
}

func TestClipKeepsANSIWidth(t *testing.T) {
	styled := "\x1b[31mred text\x1b[0m"
	if ansiWidth(styled) != 8 {
		t.Fatalf("ansiWidth = %d", ansiWidth(styled))
	}
	if w := ansiWidth(clip(styled, 4)); w != 4 {
		t.Fatalf("clipped width = %d, want 4", w)
	}
}

func TestTwoCols(t *testing.T) {
	if got := twoCols("left", "right", 20); got != "left"+strings.Repeat(" ", 11)+"right" {
		t.Fatalf("twoCols = %q", got)
	}
	if got := twoCols("a very long left side", "right", 20); ansiWidth(got) != 20 {
		t.Fatalf("twoCols width = %d (%q)", ansiWidth(got), got)
	}
	if got := twoCols("left", "", 10); got != "left      " {
		t.Fatalf("twoCols without right = %q", got)
	}
	if got := twoCols("left", "much too long right", 8); ansiWidth(got) != 8 {
		t.Fatalf("twoCols overflow = %q", got)
	}
}

func TestHumanFormats(t *testing.T) {
	tests := []struct {
		name string
		got  string
		want string
	}{
		{"bytes zero", bytesHuman(0), "0 B"},
		{"bytes small", bytesHuman(999), "999 B"},
		{"bytes kibi", bytesHuman(1024), "1.0 KiB"},
		{"bytes fractional", bytesHuman(1500), "1.5 KiB"},
		{"bytes mebi", bytesHuman(5 * 1024 * 1024), "5.0 MiB"},
		{"rate zero", rateHuman(0), "0 B/s"},
		{"rate kibi", rateHuman(2048), "2.0 KiB/s"},
		{"duration zero", durationHuman(0), "0:00"},
		{"duration minute", durationHuman(65 * time.Second), "1:05"},
		{"duration hour", durationHuman(3725 * time.Second), "1:02:05"},
		{"clock zero", clock(time.Time{}), "--:--:--"},
		{"datetime zero", dateTime(time.Time{}), "never"},
	}
	for _, tc := range tests {
		if tc.got != tc.want {
			t.Errorf("%s: got %q, want %q", tc.name, tc.got, tc.want)
		}
	}
}

func TestListWindowKeepsSelectionVisible(t *testing.T) {
	cases := []struct {
		name                    string
		count, sel, per, height int
		wantStart, wantEnd      int
	}{
		{"short list", 3, 2, 2, 10, 0, 3},
		{"first item", 20, 0, 2, 6, 0, 3},
		{"middle", 20, 10, 2, 6, 8, 11},
		{"last item", 20, 19, 2, 6, 17, 20},
		{"single line items", 20, 19, 1, 5, 15, 20},
		{"empty", 0, 0, 2, 10, 0, 0},
		{"zero height", 10, 3, 2, 0, 0, 0},
	}
	for _, tc := range cases {
		start, end := listWindow(tc.count, tc.sel, tc.per, tc.height)
		if start != tc.wantStart || end != tc.wantEnd {
			t.Errorf("%s: window = [%d,%d), want [%d,%d)", tc.name, start, end, tc.wantStart, tc.wantEnd)
		}
		if tc.count == 0 || tc.height <= 0 {
			continue
		}
		if tc.sel < start || tc.sel >= end {
			t.Errorf("%s: selection %d outside window [%d,%d)", tc.name, tc.sel, start, end)
		}
	}
}

func TestJoinNonEmpty(t *testing.T) {
	if got := joinNonEmpty(" · ", "a", "", "b"); got != "a · b" {
		t.Fatalf("joinNonEmpty = %q", got)
	}
	if got := joinNonEmpty(" · "); got != "" {
		t.Fatalf("joinNonEmpty empty = %q", got)
	}
}

func TestRenderBoxShape(t *testing.T) {
	st := Palette{Colored: false}.Styles()
	out := RenderBox("STATUS", 20, 4, []string{"one", "a very long line that will not fit"}, st)
	lines := strings.Split(out, "\n")
	if len(lines) != 4 {
		t.Fatalf("got %d lines, want 4", len(lines))
	}
	for i, l := range lines {
		if w := ansiWidth(l); w != 20 {
			t.Fatalf("line %d width = %d (%q)", i, w, l)
		}
	}
	if !strings.Contains(lines[0], "STATUS") {
		t.Fatalf("title missing from border: %q", lines[0])
	}
	if !strings.Contains(lines[3], "╰") {
		t.Fatalf("bottom border missing: %q", lines[3])
	}
}

func TestRenderBoxTooSmall(t *testing.T) {
	st := Palette{}.Styles()
	if got := RenderBox("X", 3, 1, nil, st); got != "" {
		t.Fatalf("expected empty box, got %q", got)
	}
}

func TestInputEditing(t *testing.T) {
	var in Input
	in.Set("abc")
	in.Left()
	in.Insert('X')
	if in.Value != "abXc" || in.Cursor != 3 {
		t.Fatalf("insert: %q at %d", in.Value, in.Cursor)
	}
	in.Backspace()
	if in.Value != "abc" || in.Cursor != 2 {
		t.Fatalf("backspace: %q at %d", in.Value, in.Cursor)
	}
	in.Delete()
	if in.Value != "ab" {
		t.Fatalf("delete: %q", in.Value)
	}
	in.Home()
	in.Insert('я')
	if in.Value != "яab" || in.Cursor != 1 {
		t.Fatalf("unicode insert: %q at %d", in.Value, in.Cursor)
	}
	in.End()
	in.Insert('!')
	if in.Value != "яab!" || in.Cursor != 4 {
		t.Fatalf("end insert: %q at %d", in.Value, in.Cursor)
	}
	if in.View(10) == "" {
		t.Fatal("view must render something")
	}
}

func TestLogBufferRingKeepsNewest(t *testing.T) {
	b := NewLogBuffer(3)
	for i := 0; i < 5; i++ {
		b.Add(proto.LogEntry{Text: string(rune('a' + i))})
	}
	if b.Len() != 3 {
		t.Fatalf("len = %d", b.Len())
	}
	got := b.Entries()
	want := []string{"c", "d", "e"}
	for i, e := range got {
		if e.Text != want[i] {
			t.Fatalf("entry %d = %q, want %q", i, e.Text, want[i])
		}
	}
	if b.At(-1).Text != "" || b.At(99).Text != "" {
		t.Fatal("out of range access must return the zero entry")
	}
}

func TestLogBufferFlattensMultilineMessages(t *testing.T) {
	b := NewLogBuffer(4)
	b.Add(proto.LogEntry{Text: "first line\nsecond line\r\nthird\tcolumn"})
	if b.Len() != 1 {
		t.Fatalf("len = %d", b.Len())
	}
	text := b.At(0).Text
	if strings.ContainsAny(text, "\r\n\t") {
		t.Fatalf("message still spans lines: %q", text)
	}
	if text != "first line second line  third column" {
		t.Fatalf("flattened text = %q", text)
	}
}

func TestLogBufferStripsEscapes(t *testing.T) {
	b := NewLogBuffer(4)
	b.Add(proto.LogEntry{Text: "\x1b[31mERROR\x1b[0m[0034] connection: canceled", Source: "\x1b[1mcore\x1b[0m"})
	entry := b.At(0)
	if strings.Contains(entry.Text, "\x1b") || strings.Contains(entry.Source, "\x1b") {
		t.Fatalf("escapes survived: %q / %q", entry.Text, entry.Source)
	}
	if entry.Text != "ERROR[0034] connection: canceled" || entry.Source != "core" {
		t.Fatalf("unexpected entry: %+v", entry)
	}
}

func TestLogBufferFilter(t *testing.T) {
	b := NewLogBuffer(10)
	b.Add(proto.LogEntry{Level: proto.LevelDebug, Source: "tun", Text: "gso disabled"})
	b.Add(proto.LogEntry{Level: proto.LevelInfo, Source: "router", Text: "matched geosite:cn"})
	b.Add(proto.LogEntry{Level: proto.LevelWarn, Source: "outbound/vless", Text: "connection reset"})
	b.Add(proto.LogEntry{Level: proto.LevelError, Source: "dns", Text: "no such host"})

	if got := b.Filter(proto.LevelWarn, ""); len(got) != 2 {
		t.Fatalf("warn+ filter returned %d entries", len(got))
	}
	if got := b.Filter(proto.LevelDebug, "ROUTER"); len(got) != 1 || got[0].Source != "router" {
		t.Fatalf("query filter = %+v", got)
	}
	if got := b.Filter(proto.LevelError, "nothing"); len(got) != 0 {
		t.Fatalf("expected no matches, got %d", len(got))
	}
	b.Clear()
	if b.Len() != 0 {
		t.Fatalf("clear left %d entries", b.Len())
	}
}
