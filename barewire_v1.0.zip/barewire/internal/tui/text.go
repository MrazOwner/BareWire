package tui

import (
	"fmt"
	"strings"
	"time"

	"github.com/charmbracelet/x/ansi"
)

// ansiWidth is the number of terminal cells a styled string occupies.
func ansiWidth(s string) int { return ansi.StringWidth(s) }

// clip shortens a styled string to at most w cells.
func clip(s string, w int) string {
	if w <= 0 {
		return ""
	}
	if ansiWidth(s) <= w {
		return s
	}
	if w == 1 {
		return "…"
	}
	return ansi.Truncate(s, w, "…")
}

// padRight pads a styled string with spaces to exactly w cells.
func padRight(s string, w int) string {
	got := ansiWidth(s)
	if got >= w {
		return clip(s, w)
	}
	return s + strings.Repeat(" ", w-got)
}

// padLeft right-aligns a styled string inside w cells.
func padLeft(s string, w int) string {
	got := ansiWidth(s)
	if got >= w {
		return clip(s, w)
	}
	return strings.Repeat(" ", w-got) + s
}

// fit clips and pads in one step: the result is exactly w cells wide.
func fit(s string, w int) string { return padRight(clip(s, w), w) }

// twoCols puts left at the start and right at the end of a w-cell line. When
// they do not fit, the left side is clipped: the right side is the shorter,
// more specific fact.
func twoCols(left, right string, w int) string {
	lw, rw := ansiWidth(left), ansiWidth(right)
	if rw == 0 {
		return padRight(left, w)
	}
	if rw >= w {
		return clip(right, w)
	}
	if lw+rw+2 <= w {
		return left + strings.Repeat(" ", w-lw-rw) + right
	}
	return clip(left, w-rw-2) + "  " + right
}

// bytesHuman renders a byte counter with a binary unit.
func bytesHuman(n uint64) string {
	const unit = 1024
	if n < unit {
		return fmt.Sprintf("%d B", n)
	}
	div, exp := uint64(unit), 0
	for v := n / unit; v >= unit; v /= unit {
		div *= unit
		exp++
	}
	units := "KMGTPE"
	return fmt.Sprintf("%.1f %ciB", float64(n)/float64(div), units[exp])
}

// rateHuman renders bytes per second.
func rateHuman(bps uint64) string {
	if bps == 0 {
		return "0 B/s"
	}
	return bytesHuman(bps) + "/s"
}

// durationHuman renders an elapsed time as h:mm:ss or m:ss.
func durationHuman(d time.Duration) string {
	if d < 0 {
		d = 0
	}
	total := int64(d / time.Second)
	h := total / 3600
	m := (total % 3600) / 60
	s := total % 60
	if h > 0 {
		return fmt.Sprintf("%d:%02d:%02d", h, m, s)
	}
	return fmt.Sprintf("%d:%02d", m, s)
}

// clock renders a wall-clock time for log lines.
func clock(t time.Time) string {
	if t.IsZero() {
		return "--:--:--"
	}
	return t.Format("15:04:05")
}

// dateTime renders a timestamp for facts that outlive the current hour.
func dateTime(t time.Time) string {
	if t.IsZero() {
		return "never"
	}
	return t.Format("2006-01-02 15:04:05")
}

// listWindow returns the item range [start,end) that keeps sel visible when the
// list has height lines and each item occupies per lines. It is the only place
// that decides what a scrolled list shows, so the cursor can never leave the
// screen: a list you cannot see the cursor in is a broken list.
func listWindow(count, sel, per, height int) (int, int) {
	if count <= 0 || per <= 0 || height <= 0 {
		return 0, 0
	}
	visible := height / per
	if visible < 1 {
		visible = 1
	}
	if visible > count {
		visible = count
	}
	if sel < 0 {
		sel = 0
	}
	if sel >= count {
		sel = count - 1
	}
	start := sel - visible + 1
	if start < 0 {
		start = 0
	}
	if start > count-visible {
		start = count - visible
	}
	return start, start + visible
}

// joinNonEmpty joins the non-empty parts with sep.
func joinNonEmpty(sep string, parts ...string) string {
	out := parts[:0]
	for _, p := range parts {
		if p != "" {
			out = append(out, p)
		}
	}
	return strings.Join(out, sep)
}
