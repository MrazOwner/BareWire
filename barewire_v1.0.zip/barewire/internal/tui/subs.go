package tui

import (
	"strconv"
	"strings"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/subscription"
	"github.com/mrazowner/barewire/internal/system"
)

type subsFetchedMsg struct {
	idx int
	res subscription.Result
	err error
}

// pingReportMsg carries the measurements of one "ping" press.
type pingReportMsg struct {
	idx     int
	results []system.PingResult
}

// subsScreen holds the subscription list and the nodes parsed out of it. Nothing
// here runs on a timer: refresh happens when the user presses r.
type subsScreen struct {
	w, h int
	path string
	st   config.SubscriptionStore
	sel  int
	pane int // 0 subscriptions, 1 nodes
	ns   int // node cursor

	editing bool
	editUA  bool
	input   Input
	busy    bool
	pinging bool
	confirm bool
	note    string
}

func newSubsScreen(path string) *subsScreen {
	s := &subsScreen{path: path}
	st, err := config.LoadSubscriptions(path)
	if err != nil {
		s.note = err.Error()
	}
	s.st = st
	return s
}

func (s *subsScreen) Resize(w, h int) {
	s.w, s.h = w, h
}

func (s *subsScreen) Capturing() bool { return s.editing }

func (s *subsScreen) Hints() []Hint {
	if s.editing {
		return []Hint{{"enter", "add"}, {"esc", "cancel"}}
	}
	if s.pane == 1 {
		return []Hint{
			{"j/k", "move"},
			{"space", "select node"},
			{"enter", "select node"},
			{"p", "ping nodes"},
			{"h", "subscriptions"},
			{"u", "user-agent"},
			{"r", "refresh"},
			{"d", "remove"},
		}
	}
	return []Hint{
		{"j/k", "move"},
		{"enter", "open nodes"},
		{"l", "nodes"},
		{"p", "ping nodes"},
		{"a", "add url or vless:// link"},
		{"u", "user-agent"},
		{"r", "refresh"},
		{"f", "format"},
		{"d", "remove"},
	}
}

func (s *subsScreen) Body(m *Model, w, h int) []string {
	if len(s.st.Items) == 0 && !s.editing {
		lines := []string{
			m.styles.Dim.Render("no subscriptions"),
			"",
			m.styles.Key.Render("[a]") + " " + m.styles.Dim.Render("add a subscription url"),
		}
		if s.note != "" {
			lines = append(lines, "", m.styles.Err.Render(s.note))
		}
		return lines
	}

	leftW := w / 2
	if leftW < 30 {
		leftW = w
	}
	rightW := w - leftW - 2
	left := RenderBox("Subscriptions", leftW, h, s.subLines(m, leftW-2, h-2), m.styles)
	if rightW < 20 {
		return strings.Split(left, "\n")
	}
	right := RenderBox("Nodes", rightW, h, s.nodeLines(m, rightW-2, h-2), m.styles)
	return strings.Split(Columns(2, []int{leftW, rightW}, []string{left, right}), "\n")
}

func (s *subsScreen) subLines(m *Model, w, h int) []string {
	sty := m.styles
	start, end := listWindow(len(s.st.Items), s.sel, 2, h)
	out := make([]string, 0, (end-start)*2+3)
	for i := start; i < end; i++ {
		sub := s.st.Items[i]
		marker := "  "
		if i == s.sel {
			if s.pane == 0 {
				marker = sty.Sel.Render("› ")
			} else {
				marker = sty.Accent.Render("· ")
			}
		}
		out = append(out, marker+sty.Value.Render(clip(sub.Name, w-2)))
		updated := "never"
		if !sub.UpdatedAt.IsZero() {
			updated = dateTime(sub.UpdatedAt)
		}
		detail := sub.Format + " · " + pluralNodes(len(sub.Nodes)) + " · " + updated
		if sub.UserAgent != "" {
			detail += " · ua " + sub.UserAgent
		}
		out = append(out, "  "+sty.Dim.Render(clip(detail, w-2)))
	}
	if s.editing {
		width := w - 7
		if width < 8 {
			width = 8
		}
		label := "url: "
		if s.editUA {
			label = "ua: "
		}
		out = append(out, "", sty.Key.Render(label)+s.input.View(width))
	}
	if s.busy {
		out = append(out, sty.Dim.Render("fetching…"))
	}
	if s.confirm {
		out = append(out, sty.Err.Render("press d again to remove"))
	}
	if s.note != "" {
		out = append(out, sty.Dim.Render(clip(s.note, w)))
	}
	return out
}

func (s *subsScreen) nodeLines(m *Model, w, h int) []string {
	if len(s.st.Items) == 0 {
		return nil
	}
	sty := m.styles
	sub := s.st.Items[s.sel]
	if len(sub.Nodes) == 0 {
		// The provider's answer belongs where the user is looking: this pane.
		out := []string{
			sty.Dim.Render("no nodes"),
			"",
			sty.Dim.Render("[r] fetch   [u] user-agent"),
		}
		if s.note != "" {
			out = append(out, "", sty.Err.Render(clip(s.note, w)))
		}
		return out
	}
	start, end := listWindow(len(sub.Nodes), s.ns, 2, h)
	out := make([]string, 0, (end-start)*2+2)
	for i := start; i < end; i++ {
		n := sub.Nodes[i]
		marker := "  "
		if s.pane == 1 && i == s.ns {
			marker = sty.Sel.Render("› ")
		}
		latency := "—"
		switch {
		case n.LatencyMS >= 0:
			latency = strconv.Itoa(n.LatencyMS) + "ms"
		case n.LatencyMS == config.LatencyUnreachable:
			latency = "✗"
		}
		out = append(out, marker+sty.Value.Render(clip(n.Name, w-12))+" "+sty.Dim.Render(padLeft(latency, 7)))
		out = append(out, "  "+sty.Dim.Render(clip(n.Kind+" · "+n.Endpoint(), w-2)))
	}
	if s.pinging {
		out = append(out, sty.Dim.Render("pinging…"))
	}
	if s.note != "" {
		out = append(out, sty.Err.Render(clip(s.note, w)))
	}
	return out
}
