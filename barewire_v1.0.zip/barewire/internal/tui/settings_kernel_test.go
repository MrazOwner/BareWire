package tui

import (
	"errors"
	"strings"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
	"github.com/mrazowner/barewire/internal/system"
)

// The lever walks the whole catalogue, not just what is loaded right now. A
// congestion control that the kernel carries as a module is a usable choice — the
// apply loads it — and showing only the registered list is why the user saw four
// algorithms on a machine that offers eighteen.
func TestKernelAlgorithmRowOffersTheWholeCatalogue(t *testing.T) {
	m := newTestModel(t)
	row := findRow(t, "Algorithm")
	if got := row.value(m); !strings.Contains(got, "keep") {
		t.Fatalf("empty value must render as keep, got %q", got)
	}

	seen := map[string]bool{}
	for i := 0; i < len(system.KernelOptions())+1; i++ {
		row.adjust(m, 1)
		seen[m.cfg.Kernel.Congestion] = true
		if !strings.Contains(row.value(m), keepLabel(m.cfg.Kernel.Congestion)) {
			t.Fatalf("value cell %q does not show %q", row.value(m), m.cfg.Kernel.Congestion)
		}
		if row.note(m) == "" {
			t.Fatalf("no note for %q", m.cfg.Kernel.Congestion)
		}
	}
	for _, opt := range system.KernelOptions() {
		if !seen[opt.Value] {
			t.Fatalf("%s was never offered", opt.Value)
		}
	}
	if !seen[""] {
		t.Fatal("keep has to stay reachable")
	}
}

// What the machine already registers comes first, so the usual choice is one
// press away and the rest of the catalogue is behind it.
func TestKernelAlgorithmPutsRegisteredFirst(t *testing.T) {
	m := newTestModel(t)
	m.status.CCOptions = []string{"bbr", "cubic"}
	choices := kernelChoices(m)
	if len(choices) < 3 || choices[0] != "" || choices[1] != "bbr" || choices[2] != "cubic" {
		t.Fatalf("choices = %v", choices[:min(4, len(choices))])
	}
	// No duplicates: a value that is both registered and in the catalogue appears
	// once, or the walk silently jumps back.
	seen := map[string]int{}
	for _, c := range choices {
		seen[c]++
	}
	for value, n := range seen {
		if n > 1 {
			t.Fatalf("%q appears %d times", value, n)
		}
	}
}

// An algorithm whose module is not loaded says so, because applying it is what
// loads the module.
func TestKernelNoteNamesTheModule(t *testing.T) {
	m := newTestModel(t)
	m.status.HostRunning = true
	m.status.CCOptions = []string{"cubic"}
	if got := kernelNote(m, "bbr"); !strings.Contains(got, "tcp_bbr") || !strings.Contains(got, "loads on apply") {
		t.Fatalf("note for an unloaded bbr = %q", got)
	}
	if got := kernelNote(m, "cubic"); strings.Contains(got, "loads on apply") {
		t.Fatalf("a registered algorithm must not promise a load: %q", got)
	}
	if got := kernelNote(m, ""); !strings.Contains(got, "leave the kernel alone") {
		t.Fatalf("keep note = %q", got)
	}
}

// The MTU lever reaches every size that matters in one step, including the top of
// what any encapsulation can carry: ±10 made 1452 a seventeen-press chore.
func TestMTURowWalksEverySize(t *testing.T) {
	m := newTestModel(t)
	row := findRow(t, "MTU")
	seen := map[int]bool{}
	for i := 0; i < len(mtuSizes); i++ {
		row.adjust(m, 1)
		seen[m.cfg.MTU] = true
	}
	for _, size := range mtuSizes {
		if !seen[size] {
			t.Fatalf("size %d is unreachable: %v", size, seen)
		}
	}
	if !seen[0] {
		t.Fatal("auto has to stay in the walk")
	}
}

// A typed value keeps its place: the next step goes to the size around it, not to
// the top of the list.
func TestCycleMTUFromATypedValue(t *testing.T) {
	if got := cycleMTU(1390, 1); got != 1400 {
		t.Fatalf("1390 + 1 = %d, want 1400", got)
	}
	if got := cycleMTU(1390, -1); got != 1380 {
		t.Fatalf("1390 - 1 = %d, want 1380", got)
	}
	if got := cycleMTU(0, -1); got != 1452 {
		t.Fatalf("auto backwards = %d, want the last size", got)
	}
	if got := cycleMTU(1452, 1); got != 0 {
		t.Fatalf("the last size must wrap to auto, got %d", got)
	}
}

func TestKernelQueueDisciplineRow(t *testing.T) {
	m := newTestModel(t)
	row := findRow(t, "Queue discipline")
	seen := map[string]bool{}
	for i := 0; i < len(config.KernelQdiscs)+1; i++ {
		row.adjust(m, 1)
		seen[m.cfg.Kernel.Qdisc] = true
	}
	if len(seen) != len(config.KernelQdiscs)+1 {
		t.Fatalf("walked %v", seen)
	}
	row.adjust(m, -1)
	if m.cfg.Kernel.Qdisc != "cake" {
		t.Fatalf("backwards step = %q", m.cfg.Kernel.Qdisc)
	}
}

// The switches are tri-state: keep, on and off, and each step lands on a value
// Normalize keeps.
func TestKernelSwitchesAreTriState(t *testing.T) {
	m := newTestModel(t)
	for _, label := range []string{"MTU probing", "Slow start after idle"} {
		row := findRow(t, label)
		seen := map[string]bool{}
		for i := 0; i < len(config.KernelStates)+1; i++ {
			row.adjust(m, 1)
			v := m.cfg.Kernel.MTUProbing
			if label == "Slow start after idle" {
				v = m.cfg.Kernel.SlowStartAfterIdle
			}
			seen[v] = true
		}
		if len(seen) != len(config.KernelStates)+1 {
			t.Fatalf("%s walked %v", label, seen)
		}
	}
}

// The Applied row is the machine's answer, not the user's wish: it reads the
// status, not the settings.
func TestKernelAppliedRowShowsTheLiveState(t *testing.T) {
	m := newTestModel(t)
	m.status.Congestion = ""
	m.status.Qdisc = ""
	row := findRow(t, "Applied")
	if got := row.value(m); !strings.Contains(got, "unknown") {
		t.Fatalf("empty status must say unknown, got %q", got)
	}
	m.status.Congestion = "bbr"
	m.status.Qdisc = "fq"
	got := row.value(m)
	if !strings.Contains(got, "bbr") || !strings.Contains(got, "fq") {
		t.Fatalf("applied value = %q", got)
	}
	if m.cfg.Kernel.Congestion != "" {
		t.Fatal("reading the status must not change the lever")
	}
}

// The trial row exists, shows the saved winner, and a run updates it. A failed
// run must not wipe a previous winner.
func TestKernelTestRowAndResult(t *testing.T) {
	m := newTestModel(t)
	row := findRow(t, "Test algorithms")
	if row.run == nil {
		t.Fatal("the row must start a run")
	}
	if got := row.value(m); !strings.Contains(got, "measures") {
		t.Fatalf("value without a result = %q", got)
	}
	m.status.KernelBest = "bbr"
	if got := row.value(m); !strings.Contains(got, "bbr") {
		t.Fatalf("value with a result = %q", got)
	}

	m.status.KernelBest = ""
	m.applyKernelTest(kernelTestResult{trials: []proto.KernelTrial{
		{Algorithm: "cubic", DownMbps: 300, Score: 10},
		{Algorithm: "bbr", DownMbps: 400, Score: 20},
		{Algorithm: "vegas", Err: "unavailable"},
	}})
	if m.status.KernelBest != "bbr" {
		t.Fatalf("winner = %q", m.status.KernelBest)
	}

	m.applyKernelTest(kernelTestResult{err: errKernelTest})
	if m.status.KernelBest != "bbr" {
		t.Fatalf("a failed run must keep the old winner, got %q", m.status.KernelBest)
	}
}

var errKernelTest = errors.New("kernel test: connect first")

// A held arrow key must not queue one restart per step: the newest settings
// replace whatever was waiting.
func TestApplyQueueCoalesces(t *testing.T) {
	m := &Model{applyCh: make(chan config.Settings, 1)}
	for i := 1; i <= 5; i++ {
		s := config.Defaults()
		s.MTU = 1000 + i
		m.queueApply(s)
	}
	if got := <-m.applyCh; got.MTU != 1005 {
		t.Fatalf("queued mtu = %d, want the newest", got.MTU)
	}
	select {
	case s := <-m.applyCh:
		t.Fatalf("a second change stayed queued: %+v", s)
	default:
	}
}

// The profile summary must show the kernel lever in its new shape.
func TestKernelLabel(t *testing.T) {
	if got := kernelLabel(config.KernelSettings{}); got != "keep" {
		t.Fatalf("empty = %q", got)
	}
	got := kernelLabel(config.KernelSettings{Congestion: "bbr", Qdisc: "fq", MTUProbing: "on"})
	if !strings.Contains(got, "bbr") || !strings.Contains(got, "fq") || !strings.Contains(got, "mtu probing on") {
		t.Fatalf("label = %q", got)
	}
}
