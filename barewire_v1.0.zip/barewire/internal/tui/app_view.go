package tui

import (
	"fmt"
	"strings"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
)

// Update implements tea.Model.
func (m *Model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.w, m.h = msg.Width, msg.Height
		if m.w < 40 {
			m.w = 40
		}
		if m.h < 12 {
			m.h = 12
		}
		m.resizeScreens()
		return m, nil
	case eventMsg:
		m.ApplyEvent(msg.ev)
		return m, m.waitEvent()
	case eventClosedMsg:
		// The host went away: it crashed, someone killed it, or its socket was
		// removed. Either way the tunnel is gone with it, and the interface used to
		// go deaf until the user opened a new window. The host is launched again
		// here, and the reason stays in the log.
		wasConnected := m.status.State == proto.LinkConnected
		if wasConnected {
			m.logf(proto.LevelError, "host: gone while connected; the tunnel went with it")
		} else {
			m.logf(proto.LevelWarn, "host: gone")
		}
		// The host's own log has the reason. Reading it here is the difference
		// between "it died again" and "it died because the TUN device was busy".
		if m.hostLogTail != nil {
			for _, line := range m.hostLogTail() {
				m.logf(proto.LevelWarn, "host log: %s", line)
			}
		}
		// A host that stayed up for a while earns back its restarts: a crash every
		// few hours is not a crash loop.
		if !m.status.Since.IsZero() && time.Since(m.status.Since) > hostStable {
			m.hostRestarts = 0
		}
		m.status.HostRunning = false
		m.status.State = proto.LinkDisconnected
		if !m.ownsHost || m.starter == nil {
			return m, nil
		}
		if m.hostRestarts >= hostRestartLimit {
			m.logf(proto.LevelError, "host: gone %d times, not launching it again; the host log says why", hostRestartLimit)
			return m, nil
		}
		m.hostRestarts++
		m.logf(proto.LevelWarn, "host: relaunching (attempt %d of %d)", m.hostRestarts, hostRestartLimit)
		if wasConnected {
			// The tunnel was up, so putting it back is what the user wanted.
			m.pending = pendingConnect
		}
		return m, m.startHost()
	case hostStartedMsg:
		return m, m.onHostStarted(msg)
	case autoMTUResult:
		return m, m.applyAutoMTU(msg)
	case autoBrutalResult:
		return m, m.applyAutoBrutal(msg)
	case killSwitchFlushed:
		if msg.err != nil {
			m.logf(proto.LevelError, "nftables: flush: %v", msg.err)
		}
		return m, nil
	case kernelTestResult:
		return m, m.applyKernelTest(msg)
	case settingsAppliedMsg:
		if msg.err != nil {
			m.logf(proto.LevelError, "settings: %v", msg.err)
		}
		return m, nil
	case subsFetchedMsg:
		return m, m.subsView.handleFetched(m, msg)
	case pingReportMsg:
		return m, m.subsView.applyPing(m, msg)
	case tea.KeyMsg:
		return m, m.handleKey(msg)
	}
	return m, m.screen(m.tab).Update(msg, m)
}

// onHostStarted adopts the freshly launched host and immediately connects: the
// user pressed Connect, so that is the command that follows the launch.
func (m *Model) onHostStarted(msg hostStartedMsg) tea.Cmd {
	if msg.err != nil {
		m.pending = pendingNone
		m.pendingNode = config.Node{}
		m.logf(proto.LevelError, "%v", msg.err)
		return nil
	}
	if msg.client == nil {
		m.logf(proto.LevelError, "host: starter returned no client")
		return nil
	}
	m.client = msg.client
	m.ownsHost = true
	m.status = msg.client.Snapshot()
	m.logf(proto.LevelInfo, "host: running, %s, stack %s", m.status.CoreVersion, m.status.TUNStack)

	action := m.pending
	node := m.pendingNode
	m.pending = pendingNone
	m.pendingNode = config.Node{}

	switch action {
	case pendingSelectNode:
		return tea.Batch(m.waitEvent(), m.selectNode(node))
	case pendingConnect:
		return tea.Batch(m.waitEvent(), m.connect())
	}
	// A host that was launched without a command behind it — the relaunch after a
	// crash while the link was down — is not a reason to connect anything.
	return m.waitEvent()
}

func (m *Model) handleKey(msg tea.KeyMsg) tea.Cmd {
	key := msg.String()
	if key == "ctrl+c" {
		m.quit = true
		return tea.Quit
	}
	scr := m.screen(m.tab)
	if scr.Capturing() {
		return scr.Update(msg, m)
	}
	if t, ok := tabFromKey(key); ok {
		m.switchTab(t)
		return nil
	}
	switch key {
	case "tab":
		m.switchTab((m.tab + 1) % tabCount)
		return nil
	case "shift+tab":
		m.switchTab((m.tab + tabCount - 1) % tabCount)
		return nil
	case "q":
		m.quit = true
		return tea.Quit
	}
	return scr.Update(msg, m)
}

func tabFromKey(key string) (tab, bool) {
	if len(key) != 1 {
		return 0, false
	}
	switch key[0] {
	case '1':
		return tabStatus, true
	case '2':
		return tabSettings, true
	case '3':
		return tabLogs, true
	case '4':
		return tabSubscriptions, true
	case '5':
		return tabProfiles, true
	}
	return 0, false
}

// ApplyEvent folds one host event into the model: status, log line or traffic
// sample. It is exported so that a harness (and later the socket client) can
// drive the same code path the program uses.
func (m *Model) ApplyEvent(ev proto.Event) {
	switch ev.Type {
	case proto.EventStatus:
		if ev.Status != nil {
			m.status = *ev.Status
		}
	case proto.EventSample:
		if ev.Sample != nil {
			s := ev.Sample
			m.status.UpBps = s.UpBps
			m.status.DownBps = s.DownBps
			m.status.BytesUp = s.BytesUp
			m.status.BytesDown = s.BytesDown
			m.status.Connections = s.Connections
		}
	case proto.EventLog:
		if ev.Log != nil {
			m.logs.Add(*ev.Log)
			m.logsView.noteAppended()
		}
	}
}

func (m *Model) applyAutoMTU(res autoMTUResult) tea.Cmd {
	if res.err != nil {
		m.logf(proto.LevelError, "mtu probe: %v", res.err)
		return nil
	}
	m.cfg.MTU = res.mtu
	m.applySettings()
	return nil
}

func (m *Model) applyAutoBrutal(res autoBrutalResult) tea.Cmd {
	if res.err != nil {
		m.logf(proto.LevelError, "brutal probe: %v", res.err)
		return nil
	}
	if res.up <= 0 || res.down <= 0 {
		m.logf(proto.LevelWarn, "brutal probe: no measurement (%d/%d Mbps), values left alone", res.up, res.down)
		return nil
	}
	m.cfg.Brutal.UpMbps = res.up
	m.cfg.Brutal.DownMbps = res.down
	m.applySettings()
	state := "off"
	if m.cfg.Brutal.Enabled {
		state = "on"
	}
	m.logf(proto.LevelInfo, "brutal probe: rates set to %d/%d Mbps, TCP Brutal is %s", res.up, res.down, state)
	return nil
}

// applyKernelTest records the winner of a trial run. The per-algorithm lines are
// already in the log stream from the host; this only announces the result.
func (m *Model) applyKernelTest(res kernelTestResult) tea.Cmd {
	if res.err != nil {
		m.logf(proto.LevelError, "kernel test: %v", res.err)
		return nil
	}
	if best := bestTrial(res.trials); best != "" {
		m.status.KernelBest = best
		m.logf(proto.LevelInfo, "kernel test: best is %s", best)
	} else {
		m.logf(proto.LevelWarn, "kernel test: no algorithm produced a measurable result")
	}
	return nil
}

// bestTrial picks the highest score, skipping trials that failed.
func bestTrial(trials []proto.KernelTrial) string {
	best := ""
	bestScore := 0.0
	for _, t := range trials {
		if t.Err != "" || t.Score <= 0 {
			continue
		}
		if t.Score > bestScore {
			best, bestScore = t.Algorithm, t.Score
		}
	}
	return best
}

// View implements tea.Model.
func (m *Model) View() string {
	bodyW, bodyH := m.bodySize()
	content := m.screen(m.tab).Body(m, bodyW-2, bodyH-2)
	panel := RenderBox(strings.ToUpper(tabTitles[m.tab]), bodyW, bodyH, content, m.styles)
	return strings.Join([]string{
		m.headerView(),
		m.tabsView(),
		Rule(m.w, m.styles),
		panel,
		Rule(m.w, m.styles),
		m.legendView(),
	}, "\n")
}

func (m *Model) headerView() string {
	left := m.styles.Brand.Render("BAREWIRE")
	parts := make([]string, 0, 3)
	if m.status.HostRunning {
		parts = append(parts, m.styles.Value.Render(string(m.status.State)))
	} else {
		parts = append(parts, m.styles.Err.Render("host not running"))
		if m.socket != "" {
			parts = append(parts, m.styles.Dim.Render(m.socket))
		}
	}
	if m.status.CoreVersion != "" {
		parts = append(parts, m.styles.Dim.Render(m.status.CoreVersion))
	}
	right := strings.Join(parts, " · ")
	return fit(twoCols(left, right, m.w), m.w)
}

func (m *Model) tabsView() string {
	parts := make([]string, 0, tabCount)
	for t := tab(0); t < tabCount; t++ {
		label := fmt.Sprintf("%d %s", int(t)+1, tabTitles[t])
		if t == m.tab {
			parts = append(parts, m.styles.TabOn.Render(label))
			continue
		}
		parts = append(parts, m.styles.TabOff.Render(label))
	}
	return fit(strings.Join(parts, "   "), m.w)
}

func (m *Model) legendView() string {
	hints := append(m.screen(m.tab).Hints(),
		Hint{"1-5", "tabs"},
		Hint{"tab", "next tab"},
		Hint{"q", "quit"},
	)
	parts := make([]string, 0, len(hints))
	for _, h := range hints {
		parts = append(parts, m.styles.Key.Render(h.Key)+" "+m.styles.Dim.Render(h.Label))
	}
	return fit(strings.Join(parts, "  "), m.w)
}
