package tui

import (
	"fmt"
	"strings"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/proto"
)

// statusScreen is the fact sheet: what the link is doing right now.
type statusScreen struct {
	w, h int
}

func newStatusScreen() *statusScreen { return &statusScreen{} }

func (s *statusScreen) Resize(w, h int) {
	s.w, s.h = w, h
}

func (s *statusScreen) Capturing() bool { return false }

func (s *statusScreen) Update(msg tea.Msg, m *Model) tea.Cmd {
	key, ok := msg.(tea.KeyMsg)
	if !ok {
		return nil
	}
	switch key.String() {
	case "enter", " ":
		if m.status.State == proto.LinkConnected || m.status.State == proto.LinkConnecting {
			return m.disconnect()
		}
		return m.connect()
	case "x":
		return m.disconnect()
	case "p":
		m.switchTab(tabProfiles)
		return nil
	case "4":
		m.switchTab(tabSubscriptions)
		return nil
	}
	return nil
}

func (s *statusScreen) Hints() []Hint {
	// The lever row inside the panel already lists what this screen can do.
	return nil
}

func (s *statusScreen) Body(m *Model, w, h int) []string {
	st := m.status
	sty := m.styles

	value := func(v string) string { return sty.Value.Render(v) }
	alt := func(v string) string { return sty.Alt.Render(v) }
	fact := func(label, v, right string) string {
		return twoCols(sty.Label.Render(padRight(label, 20))+value(v), right, w)
	}

	since := ""
	if st.CarriesTraffic() {
		since = sty.Dim.Render("since " + durationHuman(timeSince(st.Since)))
	}

	lines := []string{
		fact("State", string(st.State), since),
		fact("Profile", dashes(st.Profile), ""),
		fact("Server", dashes(st.Server), alt(st.Protocol)),
		fact("Outbound", dashes(st.Outbound), sty.Dim.Render(ruleFact(st.Rule))),
		fact("TUN stack", dashes(st.TUNStack), sty.Dim.Render(mtuFact(st))),
		fact("Multiplexing", smuxFact(st), ""),
		fact("TCP Brutal", brutalFact(st), ""),
		fact("Congestion", congestionFact(st), sty.Dim.Render("kernel")),
		fact("DNS", dashes(st.DNS.Mode), sty.Dim.Render(strings.Join(st.DNS.Servers, ", "))),
		fact("Kill switch", killFact(st), ""),
		fact("Reconnects", fmt.Sprintf("%d", st.Reconnects), sty.Dim.Render(disconnectFact(st))),
		fact("Throughput", alt("↑ "+rateHuman(st.UpBps))+"  "+alt("↓ "+rateHuman(st.DownBps)),
			sty.Dim.Render("total "+bytesHuman(st.BytesUp)+" / "+bytesHuman(st.BytesDown))),
		fact("Connections", fmt.Sprintf("%d", st.Connections), ""),
		fact("Resources", mib(st.MemRSSKB), sty.Dim.Render(fmt.Sprintf("cpu %.1f%%", st.CPUPercent))),
	}
	if st.LastError != "" && st.CarriesTraffic() {
		lines = append(lines, sty.Err.Render(clip(lastErrorFact(st), w)))
	}

	out := make([]string, 0, len(lines)+3)
	out = append(out, lines...)
	out = append(out, "")
	out = append(out, sty.Dim.Render(strings.Repeat("─", maxInt(0, w))))
	out = append(out, m.actionLine())
	return out
}

// actionLine is the lever row: what the user can press from this screen.
func (m *Model) actionLine() string {
	sty := m.styles
	act := func(key, label string) string {
		return sty.Key.Render("["+key+"]") + " " + sty.Dim.Render(label)
	}
	connectLabel := "connect"
	if m.status.CarriesTraffic() {
		connectLabel = "disconnect"
	} else if !m.status.HostRunning && m.starter != nil {
		connectLabel = "start host & connect"
	}
	return strings.Join([]string{
		act("enter", connectLabel),
		act("2", "settings"),
		act("3", "logs"),
		act("5", "profiles"),
	}, "   ")
}

func mtuFact(st proto.Status) string {
	if st.MTU == 0 {
		return "mtu auto"
	}
	return fmt.Sprintf("mtu %d (%s)", st.MTU, st.MTUSource)
}

func smuxFact(st proto.Status) string {
	if !st.Smux.Enabled {
		return "off"
	}
	padding := "padding off"
	if st.Smux.Padding {
		padding = "padding on"
	}
	return st.Smux.Protocol + " · " + padding
}

func brutalFact(st proto.Status) string {
	if !st.Brutal.Enabled {
		return "off"
	}
	return fmt.Sprintf("on · up %d Mbps · down %d Mbps", st.Brutal.UpMbps, st.Brutal.DownMbps)
}

func killFact(st proto.Status) string {
	ks := st.KillSwitch
	if !ks.Enabled {
		return "off"
	}
	state := "present"
	if ks.Active {
		state = fmt.Sprintf("active · ruleset v%d", ks.RulesetVersion)
	}
	return joinNonEmpty(" · ", state, "crash "+ks.OnCrash, "netchange "+ks.OnNetworkChange)
}

func disconnectFact(st proto.Status) string {
	if st.LastDisconnect == "" {
		return "no disconnect yet"
	}
	return clock(st.LastDisconnectAt) + " " + st.LastDisconnect
}

// lastErrorFact shows the newest core error: a link can be up while every egress
// attempt fails, and that is exactly the state the user needs to see.
func lastErrorFact(st proto.Status) string {
	return "last error " + clock(st.LastErrorAt) + " " + st.LastError
}

func ruleFact(rule string) string {
	if rule == "" {
		return "rule none"
	}
	return "rule " + rule
}

// mib renders a KiB value from /proc as MiB.
func mib(kb uint64) string {
	if kb == 0 {
		return "—"
	}
	return fmt.Sprintf("%.1f MiB", float64(kb)/1024)
}

func dashes(s string) string {
	if s == "" {
		return "—"
	}
	return s
}

func timeSince(t time.Time) time.Duration {
	if t.IsZero() {
		return 0
	}
	return time.Since(t)
}

func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}
