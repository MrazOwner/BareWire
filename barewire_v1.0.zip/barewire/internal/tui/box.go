package tui

import (
	"strings"
)

// RenderBox draws a panel that is exactly w cells wide and h lines tall, with
// the title embedded in the top border. Content is clipped and padded, so the
// panel is always a rectangle no matter what the screen produced.
func RenderBox(title string, w, h int, content []string, st Styles) string {
	if w < 6 || h < 2 {
		return ""
	}
	inner := w - 2

	label := " " + title + " "
	if ansiWidth(label) > inner-2 {
		label = " " + clip(title, inner-3) + " "
	}
	filler := inner - 1 - ansiWidth(label)
	if filler < 0 {
		filler = 0
	}
	top := st.Rule.Render("╭─") + st.BoxName.Render(label) +
		st.Rule.Render(strings.Repeat("─", filler)+"╮")

	lines := make([]string, 0, h)
	lines = append(lines, top)
	for i := 0; i < h-2; i++ {
		line := ""
		if i < len(content) {
			line = content[i]
		}
		lines = append(lines, st.Rule.Render("│")+fit(line, inner)+st.Rule.Render("│"))
	}
	lines = append(lines, st.Rule.Render("╰"+strings.Repeat("─", inner)+"╯"))
	return strings.Join(lines, "\n")
}

// Rule renders a horizontal separator of exactly w cells.
func Rule(w int, st Styles) string {
	if w <= 0 {
		return ""
	}
	return st.Rule.Render(strings.Repeat("─", w))
}

// Columns lays out pre-rendered blocks side by side, each with its own width.
// Every block must already be the requested height; RenderBox guarantees that.
func Columns(gap int, widths []int, blocks []string) string {
	if len(blocks) == 0 {
		return ""
	}
	split := make([][]string, len(blocks))
	height := 0
	for i, b := range blocks {
		split[i] = strings.Split(b, "\n")
		if len(split[i]) > height {
			height = len(split[i])
		}
	}
	gapStr := strings.Repeat(" ", gap)
	var out []string
	for row := 0; row < height; row++ {
		var cells []string
		for i := range blocks {
			line := ""
			if row < len(split[i]) {
				line = split[i][row]
			}
			cells = append(cells, padRight(line, widths[i]))
		}
		out = append(out, strings.Join(cells, gapStr))
	}
	return strings.Join(out, "\n")
}
