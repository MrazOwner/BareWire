package tui

import (
	"errors"
	"strings"
	"testing"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/hostclient"
	"github.com/mrazowner/barewire/internal/hostclient/offline"
	"github.com/mrazowner/barewire/internal/proto"
	"github.com/mrazowner/barewire/internal/system"
)

// fakeHost records what the interface asks of it.
type fakeHost struct {
	events    chan proto.Event
	connected bool
	shutdown  bool
	selected  string
}

var _ hostclient.Client = (*fakeHost)(nil)

func (f *fakeHost) Snapshot() proto.Status {
	return proto.Status{HostRunning: true, CoreVersion: "fake", TUNStack: "gvisor"}
}
func (f *fakeHost) Events() <-chan proto.Event               { return f.events }
func (f *fakeHost) Connect() error                           { f.connected = true; return nil }
func (f *fakeHost) Disconnect() error                        { return nil }
func (f *fakeHost) Apply(config.Settings) error              { return nil }
func (f *fakeHost) SelectNode(n config.Node) error           { f.selected = n.Name; return nil }
func (f *fakeHost) FlushKillSwitch() error                   { return nil }
func (f *fakeHost) AutoMTU() (int, error)                    { return 0, nil }
func (f *fakeHost) AutoBrutal() (int, int, error)            { return 0, 0, nil }
func (f *fakeHost) TestKernel() ([]proto.KernelTrial, error) { return nil, nil }
func (f *fakeHost) Connections() []proto.Connection          { return nil }
func (f *fakeHost) Close() error                             { return nil }
func (f *fakeHost) Shutdown() error                          { f.shutdown = true; return nil }

func newHostStartModel(t *testing.T, starter func() (hostclient.Client, error)) *Model {
	t.Helper()
	dir := t.TempDir()
	m := New(Options{
		Client:            offline.New(),
		Settings:          config.Defaults(),
		SettingsPath:      dir + "/settings.json",
		ProfilesPath:      dir + "/profiles.json",
		SubscriptionsPath: dir + "/subscriptions.json",
		HostStarter:       starter,
		SocketPath:        "/run/user/1000/barewire/host.sock",
	})
	m.Update(tea.WindowSizeMsg{Width: 120, Height: 40})
	return m
}

// The header must say why there is no host and where it looked, so a path
// mismatch is visible without reading the log.
func TestOfflineHeaderShowsSocketPath(t *testing.T) {
	m := newHostStartModel(t, func() (hostclient.Client, error) {
		return nil, errHelper("not used")
	})
	out := m.View()
	if !strings.Contains(out, "host not running") {
		t.Fatalf("header must report the missing host:\n%s", out)
	}
	if !strings.Contains(out, "/run/user/1000/barewire/host.sock") {
		t.Fatalf("header must show the socket it looked for:\n%s", out)
	}
	if !strings.Contains(out, "start host & connect") {
		t.Fatalf("the status lever must say what enter does:\n%s", out)
	}
}

func TestConnectStartsHostOnDemand(t *testing.T) {
	host := &fakeHost{events: make(chan proto.Event)}
	calls := 0
	m := newHostStartModel(t, func() (hostclient.Client, error) {
		calls++
		return host, nil
	})

	if m.status.HostRunning {
		t.Fatal("the offline client must report a host that is not running")
	}

	_, cmd := m.Update(tea.KeyMsg{Type: tea.KeyEnter})
	if cmd == nil {
		t.Fatal("connect must return a command that launches the host")
	}
	msg := cmd()
	if _, ok := msg.(hostStartedMsg); !ok {
		t.Fatalf("expected hostStartedMsg, got %T", msg)
	}
	m.Update(msg)

	if calls != 1 {
		t.Fatalf("starter called %d times, want 1", calls)
	}
	if m.client != host {
		t.Fatal("the interface must adopt the client the starter returned")
	}
	if !host.connected {
		t.Fatal("connect must follow the launch: the user pressed Connect")
	}
	if !m.status.HostRunning {
		t.Fatal("status must reflect the running host")
	}
	if !m.ownsHost {
		t.Fatal("the interface must remember that it started the host")
	}

	m.ShutdownHost()
	if !host.shutdown {
		t.Fatal("closing the interface must stop the host it started")
	}
}

func TestSelectNodeStartsHostWhenMissing(t *testing.T) {
	host := &fakeHost{events: make(chan proto.Event)}
	m := newHostStartModel(t, func() (hostclient.Client, error) { return host, nil })
	node := config.Node{Name: "de1.example.net", Kind: "vless", Address: "de1.example.net", Port: 443}

	cmd := m.selectNode(node)
	if cmd == nil {
		t.Fatal("selecting a node without a host must launch the host")
	}
	m.Update(cmd())

	if host.selected != node.Name {
		t.Fatalf("the node was not selected after the launch: %q", host.selected)
	}
	for i := 0; i < m.logs.Len(); i++ {
		if containsText(m.logs.At(i).Text, "node not selected") {
			t.Fatalf("selection must not be refused when the host can be started: %q", m.logs.At(i).Text)
		}
	}
}

func TestPasteShareLinkAddsNode(t *testing.T) {
	m := newSubsModel(t)
	m.subsView.pane = 0
	m.subsView.sel = 0

	link := `vless://ada8a202-5356-448d-8dec-8193a6b05f1c@2.26.72.167:55023` +
		`?type=tcp&encryption=none&security=reality&pbk=FvBYKIEvdEU4q3STfph7oK2cQJrY3poTYCQ-26ucCU8` +
		`&fp=chrome&sni=vk.com&sid=fce552&spx=%2F#udj-puamcb9bs1`

	m.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'a'}})
	for _, r := range link {
		m.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{r}})
	}
	m.Update(tea.KeyMsg{Type: tea.KeyEnter})

	sv := m.subsView
	if sv.pane != 1 {
		t.Fatal("after adding a link the cursor must move to its nodes")
	}
	if len(sv.st.Items) != 3 {
		t.Fatalf("got %d subscriptions, want a new one for pasted links", len(sv.st.Items))
	}
	sub := sv.st.Items[sv.sel]
	if sub.Name != "pasted links" || len(sub.Nodes) != 1 {
		t.Fatalf("unexpected subscription: %+v", sub)
	}
	if sub.Nodes[0].Name != "udj-puamcb9bs1" || !sub.Nodes[0].Connectable() {
		t.Fatalf("node = %+v", sub.Nodes[0])
	}
	if !strings.Contains(m.View(), "udj-puamcb9bs1") {
		t.Fatal("the new node must be visible")
	}
}

func TestPasteSecondLinkAppendsToSameSubscription(t *testing.T) {
	m := newSubsModel(t)
	m.subsView.pane = 0
	for _, link := range []string{
		"vless://11111111-2222-3333-4444-555555555555@a.example:443?sni=a.example#a",
		"vless://11111111-2222-3333-4444-555555555555@b.example:443?sni=b.example#b",
	} {
		m.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'a'}})
		for _, r := range link {
			m.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{r}})
		}
		m.Update(tea.KeyMsg{Type: tea.KeyEnter})
	}
	var manual *config.Subscription
	count := 0
	for i := range m.subsView.st.Items {
		if m.subsView.st.Items[i].Name == "pasted links" {
			manual = &m.subsView.st.Items[i]
			count++
		}
	}
	if count != 1 || manual == nil {
		t.Fatalf("pasted links subscription count = %d", count)
	}
	if len(manual.Nodes) != 2 {
		t.Fatalf("nodes = %d, want 2", len(manual.Nodes))
	}
}

func TestPingUpdatesNodeLatency(t *testing.T) {
	m := newSubsModel(t)
	sv := m.subsView
	sv.pane = 1
	sv.sel = 0

	_, cmd := m.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'p'}})
	if cmd == nil {
		t.Fatal("p must start a ping")
	}
	if !sv.pinging {
		t.Fatal("the screen must show that a ping is running")
	}

	// Synthetic measurements: no network in tests.
	m.Update(pingReportMsg{idx: 0, results: []system.PingResult{
		{Index: 0, Latency: 42 * time.Millisecond},
		{Index: 1, Err: errors.New("timeout")},
		{Index: 2, Latency: 55 * time.Millisecond},
	}})

	if got := sv.st.Items[0].Nodes[0].LatencyMS; got != 42 {
		t.Fatalf("latency = %d", got)
	}
	if got := sv.st.Items[0].Nodes[1].LatencyMS; got != config.LatencyUnreachable {
		t.Fatalf("failed node latency = %d", got)
	}
	if sv.pinging {
		t.Fatal("ping must clear its running flag")
	}

	out := m.View()
	if !strings.Contains(out, "42ms") {
		t.Fatalf("measured latency is not shown:\n%s", out)
	}
	if !strings.Contains(out, "✗") {
		t.Fatalf("unreachable node is not marked:\n%s", out)
	}

	found := false
	for i := 0; i < m.logs.Len(); i++ {
		if strings.Contains(m.logs.At(i).Text, "2/3 reachable") {
			found = true
		}
	}
	if !found {
		t.Fatal("the ping summary must be a log fact")
	}
}

func TestConnectWithoutStarterIsRefused(t *testing.T) {
	m := newHostStartModel(t, nil)
	_, cmd := m.Update(tea.KeyMsg{Type: tea.KeyEnter})
	if cmd != nil {
		t.Fatal("without a starter connect must not produce a command")
	}
	if m.client != nil && m.client.Snapshot().HostRunning {
		t.Fatal("no host can appear without a starter")
	}
}

func TestStarterErrorIsReported(t *testing.T) {
	m := newHostStartModel(t, func() (hostclient.Client, error) {
		return nil, errHelper("authorisation cancelled")
	})
	_, cmd := m.Update(tea.KeyMsg{Type: tea.KeyEnter})
	if cmd == nil {
		t.Fatal("expected a command")
	}
	m.Update(cmd())

	if m.ownsHost {
		t.Fatal("a failed launch must not mark the host as owned")
	}
	if m.status.HostRunning {
		t.Fatal("a failed launch must not report a running host")
	}
	found := false
	for i := 0; i < m.logs.Len(); i++ {
		if containsText(m.logs.At(i).Text, "authorisation cancelled") {
			found = true
		}
	}
	if !found {
		t.Fatal("the launch failure must be a log fact")
	}
}

// A host that goes away used to leave the interface deaf: no events, no host,
// and the tunnel gone. The interface now launches it again and says why.
func TestHostDeathRelaunchesAndReconnects(t *testing.T) {
	first := &fakeHost{events: make(chan proto.Event)}
	second := &fakeHost{events: make(chan proto.Event)}
	calls := 0
	m := newHostStartModel(t, func() (hostclient.Client, error) {
		calls++
		if calls == 1 {
			return first, nil
		}
		return second, nil
	})

	// Connect once so the interface owns a host and the link is up.
	_, cmd := m.Update(tea.KeyMsg{Type: tea.KeyEnter})
	m.Update(cmd())
	m.status.State = proto.LinkConnected
	m.status.Since = time.Now()

	_, cmd = m.Update(eventClosedMsg{})
	if cmd == nil {
		t.Fatal("a lost host must be launched again")
	}
	if m.pending != pendingConnect {
		t.Fatal("a link that was up has to come back on its own")
	}
	m.Update(cmd())

	if calls != 2 {
		t.Fatalf("the host was launched %d times, want 2", calls)
	}
	if m.client != second {
		t.Fatal("the interface must adopt the relaunched host")
	}
}

// A host that cannot stay up is not relaunched forever: each attempt is a
// password prompt, and the log has to say that the client stopped trying.
func TestHostDeathStopsAfterTheLimit(t *testing.T) {
	m := newHostStartModel(t, func() (hostclient.Client, error) {
		return &fakeHost{events: make(chan proto.Event)}, nil
	})
	m.ownsHost = true
	m.hostRestarts = hostRestartLimit

	_, cmd := m.Update(eventClosedMsg{})
	if cmd != nil {
		t.Fatal("the limit has to stop the relaunches")
	}
	found := false
	for i := 0; i < m.logs.Len(); i++ {
		if strings.Contains(m.logs.At(i).Text, "not launching it again") {
			found = true
		}
	}
	if !found {
		t.Fatal("giving up must be a log fact")
	}
}

type errHelper string

func (e errHelper) Error() string { return string(e) }

func containsText(haystack, needle string) bool {
	for i := 0; i+len(needle) <= len(haystack); i++ {
		if haystack[i:i+len(needle)] == needle {
			return true
		}
	}
	return false
}
