package tui

import (
	"fmt"
	"strings"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/proto"
)

func (s *logsScreen) entryLine(m *Model, e proto.LogEntry, w int) string {
	sty := m.styles
	head := sty.Dim.Render(clock(e.Time)) + " " + sty.LevelStyle(string(e.Level)).Render(levelTag(e.Level)) + " "
	if e.Source != "" {
		head += sty.Dim.Render(padRight(e.Source, 15)) + " "
	}
	body := sty.Value.Render(e.Text)
	if e.Level == proto.LevelError {
		body = sty.Err.Render(e.Text)
	}
	return fit(head+body, w)
}

func (s *logsScreen) connectionLines(m *Model, w, h int) []string {
	conns := m.client.Connections()
	if len(conns) == 0 {
		return []string{m.styles.Dim.Render("no active connections")}
	}
	head := fmt.Sprintf("%-6s %-18s %-16s %s", "id", "outbound", "rule", "host")
	out := []string{m.styles.Label.Render(clip(head, w))}
	for i, c := range conns {
		if i >= h-1 {
			break
		}
		line := fmt.Sprintf("%-6d %-18s %-16s %s", c.ID, clip(c.Outbound, 18), clip(c.Rule, 16), c.Host)
		out = append(out, m.styles.Value.Render(clip(line, w)))
	}
	return out
}

func (s *logsScreen) Update(msg tea.Msg, m *Model) tea.Cmd {
	key, ok := msg.(tea.KeyMsg)
	if !ok {
		s.noteAppended()
		return nil
	}
	if s.editing {
		s.handleEdit(key, m)
		return nil
	}
	switch key.String() {
	case "j", "down":
		s.scroll(-1)
	case "k", "up":
		s.scroll(1)
	case "pgdown":
		s.scroll(-s.page())
	case "pgup":
		s.scroll(s.page())
	case "g":
		s.auto = false
		s.offset = 1 << 20
	case "G":
		s.auto = true
		s.offset = 0
	case "a":
		s.auto = !s.auto
		if s.auto {
			s.offset = 0
		}
	case "l":
		s.cycleLevel()
	case "/":
		s.editing = true
		s.input.Set(s.query)
	case "esc":
		s.query = ""
		s.input.Reset()
	case "c":
		s.conns = !s.conns
	}
	return nil
}

func (s *logsScreen) handleEdit(key tea.KeyMsg, m *Model) {
	switch key.String() {
	case "esc":
		s.editing = false
		s.input.Reset()
	case "enter":
		s.query = strings.TrimSpace(s.input.Value)
		s.editing = false
		s.offset = 0
		s.auto = true
		m.logf(proto.LevelInfo, "log filter: %q", s.query)
	case "backspace":
		s.input.Backspace()
	case "delete":
		s.input.Delete()
	case "left":
		s.input.Left()
	case "right":
		s.input.Right()
	case "home", "ctrl+a":
		s.input.Home()
	case "end", "ctrl+e":
		s.input.End()
	default:
		for _, r := range key.Runes {
			s.input.Insert(r)
		}
	}
}

func (s *logsScreen) scroll(delta int) {
	s.offset += delta
	if s.offset < 0 {
		s.offset = 0
	}
	if delta < 0 {
		s.auto = false
	}
}

func (s *logsScreen) page() int {
	p := s.viewport
	if p < 1 {
		p = 1
	}
	return p
}

func (s *logsScreen) cycleLevel() {
	switch s.min {
	case proto.LevelDebug:
		s.min = proto.LevelInfo
	case proto.LevelInfo:
		s.min = proto.LevelWarn
	case proto.LevelWarn:
		s.min = proto.LevelError
	default:
		s.min = proto.LevelDebug
	}
}

func (s *logsScreen) noteAppended() {
	if s.auto {
		s.offset = 0
	}
}

func levelTag(level proto.LogLevel) string {
	switch level {
	case proto.LevelDebug:
		return "DBG"
	case proto.LevelWarn:
		return "WRN"
	case proto.LevelError:
		return "ERR"
	default:
		return "INF"
	}
}
