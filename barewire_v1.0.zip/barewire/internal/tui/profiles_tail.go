package tui

import (
	"fmt"
	"strings"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
)

func (s *profilesScreen) Update(msg tea.Msg, m *Model) tea.Cmd {
	key, ok := msg.(tea.KeyMsg)
	if !ok {
		return nil
	}
	if s.mode != profileModeIdle {
		s.handleInput(key, m)
		return nil
	}
	switch key.String() {
	case "j", "down":
		s.move(1)
	case "k", "up":
		s.move(-1)
	case "enter":
		return s.activate(m)
	case "s":
		return s.saveCurrent(m)
	case "n":
		s.mode = profileModeNew
		s.input.Set(fmt.Sprintf("profile-%d", len(s.st.Items)+1))
	case "r":
		if len(s.st.Items) > 0 {
			s.mode = profileModeRename
			s.input.Set(s.st.Items[s.sel].Name)
		}
	case "d":
		return s.remove(m)
	case "b":
		if len(s.st.Items) == 0 {
			return nil
		}
		s.mode = profileModeBindNetwork
		s.input.Set(s.st.Items[s.sel].BoundNetwork)
	case "S":
		return s.bindServer(m)
	case "esc":
		s.confirm = false
	}
	return nil
}

// saveCurrent writes the live lever set into the selected profile. It is the
// explicit half of what the settings screen does automatically: a change made
// with "activate" never happened keeps this profile as it was.
func (s *profilesScreen) saveCurrent(m *Model) tea.Cmd {
	if len(s.st.Items) == 0 {
		return nil
	}
	p := &s.st.Items[s.sel]
	p.Settings = m.cfg.Clone()
	p.Settings.Profile = p.Name
	p.UpdatedAt = time.Now()
	m.cfg.Profile = p.Name
	s.st.Active = p.Name
	m.logf(proto.LevelInfo, "profile %s: current settings saved into it", p.Name)
	s.save(m)
	m.applySettings()
	return nil
}

func (s *profilesScreen) move(delta int) {
	if len(s.st.Items) == 0 {
		return
	}
	s.sel += delta
	if s.sel < 0 {
		s.sel = 0
	}
	if s.sel >= len(s.st.Items) {
		s.sel = len(s.st.Items) - 1
	}
	s.confirm = false
}

func (s *profilesScreen) handleInput(key tea.KeyMsg, m *Model) {
	switch key.String() {
	case "esc":
		s.mode = profileModeIdle
		s.input.Reset()
	case "enter":
		value := strings.TrimSpace(s.input.Value)
		mode := s.mode
		s.mode = profileModeIdle
		s.input.Reset()
		switch mode {
		case profileModeNew:
			s.create(m, value)
		case profileModeBindNetwork:
			s.bindNetwork(m, value)
		case profileModeRename:
			s.rename(m, value)
		}
	case "backspace":
		s.input.Backspace()
	case "delete":
		s.input.Delete()
	case "left":
		s.input.Left()
	case "right":
		s.input.Right()
	case "home", "ctrl+a":
		s.input.Home()
	case "end", "ctrl+e":
		s.input.End()
	default:
		for _, r := range key.Runes {
			s.input.Insert(r)
		}
	}
}

func (s *profilesScreen) create(m *Model, name string) {
	if name == "" {
		return
	}
	if _, exists := s.st.Find(name); exists {
		s.note = "profile exists: " + name
		return
	}
	p := config.Profile{Name: name, Settings: m.cfg.Clone(), UpdatedAt: time.Now()}
	s.st.Items = append(s.st.Items, p)
	s.sel = len(s.st.Items) - 1
	s.note = ""
	m.logf(proto.LevelInfo, "profile saved: %s", name)
	s.save(m)
}

func (s *profilesScreen) bindNetwork(m *Model, network string) {
	if len(s.st.Items) == 0 {
		return
	}
	p := &s.st.Items[s.sel]
	p.BoundNetwork = network
	p.UpdatedAt = time.Now()
	m.logf(proto.LevelInfo, "profile %s: bound network %q", p.Name, network)
	s.save(m)
}

func (s *profilesScreen) bindServer(m *Model) tea.Cmd {
	if len(s.st.Items) == 0 {
		return nil
	}
	p := &s.st.Items[s.sel]
	p.BoundServer = m.status.Server
	p.UpdatedAt = time.Now()
	m.logf(proto.LevelInfo, "profile %s: bound server %q", p.Name, p.BoundServer)
	s.save(m)
	return nil
}

func (s *profilesScreen) rename(m *Model, name string) {
	if len(s.st.Items) == 0 || name == "" {
		return
	}
	old := s.st.Items[s.sel].Name
	s.st.Items[s.sel].Name = name
	s.st.Items[s.sel].UpdatedAt = time.Now()
	if s.st.Active == old {
		s.st.Active = name
	}
	// The settings carry the profile name they came from; a rename that left it
	// behind would write every later change into a name that no longer exists.
	if m.cfg.Profile == old {
		m.cfg.Profile = name
		m.applySettings()
	}
	s.save(m)
}

func (s *profilesScreen) activate(m *Model) tea.Cmd {
	if len(s.st.Items) == 0 {
		return nil
	}
	p := s.st.Items[s.sel]
	m.cfg = p.Settings.Clone()
	m.cfg.Profile = p.Name
	m.cfg.Normalize()
	m.applySettings()
	s.st.Active = p.Name
	m.logf(proto.LevelInfo, "profile activated: %s", p.Name)
	s.save(m)
	return nil
}

func (s *profilesScreen) remove(m *Model) tea.Cmd {
	if len(s.st.Items) == 0 {
		return nil
	}
	if !s.confirm {
		s.confirm = true
		return nil
	}
	name := s.st.Items[s.sel].Name
	s.st.Items = append(s.st.Items[:s.sel], s.st.Items[s.sel+1:]...)
	if s.sel >= len(s.st.Items) && s.sel > 0 {
		s.sel--
	}
	if s.st.Active == name {
		s.st.Active = ""
	}
	if m.cfg.Profile == name {
		// The lever set outlives the profile it came from: it stays in charge,
		// with no name to write back to.
		m.cfg.Profile = ""
		m.applySettings()
	}
	s.confirm = false
	m.logf(proto.LevelInfo, "profile removed: %s", name)
	s.save(m)
	return nil
}

func (s *profilesScreen) save(m *Model) {
	if err := config.SaveProfiles(s.path, s.st); err != nil {
		m.logf(proto.LevelError, "profiles: %v", err)
	}
}
