package tui

import (
	"fmt"
	"strings"
	"testing"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/config"
)

// The cursor must never leave the screen, no matter how long the list is.
func TestSettingsCursorStaysVisible(t *testing.T) {
	m := newTestModel(t)
	m.Update(tabKey(2))
	for i := 0; i < 60; i++ {
		m.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'j'}})
	}
	out := m.View()
	if !strings.Contains(out, "›") {
		t.Fatalf("cursor marker missing after scrolling:\n%s", out)
	}
	// The last selectable row is the second accent color.
	if !strings.Contains(out, "Accent alt") {
		t.Fatalf("the focused row is off screen:\n%s", out)
	}
}

func TestProfilesCursorStaysVisible(t *testing.T) {
	m := newTestModel(t)
	// The list is re-read when the tab comes into view, so the store has to be the
	// source of truth here too — poking the screen's memory would only prove that
	// the cursor works on a list nobody else can see.
	st := config.ProfileStore{}
	for i := 0; i < 30; i++ {
		st.Items = append(st.Items, config.Profile{
			Name:     fmt.Sprintf("profile-%02d", i),
			Settings: config.Defaults(),
		})
	}
	if err := config.SaveProfiles(m.profPath, st); err != nil {
		t.Fatalf("save profiles: %v", err)
	}
	m.profilesView.Refresh(m.cfg)
	m.profilesView.sel = 29
	m.Update(tabKey(5))
	out := m.View()
	if !strings.Contains(out, "profile-29") {
		t.Fatalf("selected profile is off screen:\n%s", out)
	}
	if !strings.Contains(out, "›") {
		t.Fatalf("cursor marker missing:\n%s", out)
	}
}

func TestSubscriptionsCursorStaysVisible(t *testing.T) {
	m := newTestModel(t)
	m.subsView.st.Items = nil
	for i := 0; i < 20; i++ {
		m.subsView.st.Items = append(m.subsView.st.Items, config.Subscription{
			Name:   fmt.Sprintf("sub-%02d", i),
			URL:    "https://example.invalid/sub",
			Format: "v2ray",
		})
	}
	m.subsView.sel = 19
	m.Update(tabKey(4))
	out := m.View()
	if !strings.Contains(out, "sub-19") {
		t.Fatalf("selected subscription is off screen:\n%s", out)
	}
}

func TestNodesCursorStaysVisible(t *testing.T) {
	m := newTestModel(t)
	m.subsView.st.Items = []config.Subscription{{
		Name:   "big",
		URL:    "https://example.invalid/sub",
		Format: "clash",
	}}
	for i := 0; i < 60; i++ {
		m.subsView.st.Items[0].Nodes = append(m.subsView.st.Items[0].Nodes, config.Node{
			Name: fmt.Sprintf("node-%02d", i), Kind: "vless",
			Address: "example.net", Port: 443, LatencyMS: -1,
		})
	}
	m.subsView.sel = 0
	m.subsView.pane = 1
	m.subsView.ns = 59
	m.Update(tabKey(4))
	out := m.View()
	if !strings.Contains(out, "node-59") {
		t.Fatalf("selected node is off screen:\n%s", out)
	}
	if !strings.Contains(out, "›") {
		t.Fatalf("cursor marker missing:\n%s", out)
	}
}
