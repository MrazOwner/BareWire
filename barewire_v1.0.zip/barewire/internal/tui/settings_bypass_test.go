package tui

import (
	"strings"
	"testing"
)

// The three direct lists are one line each. A commit replaces the whole list, an
// empty line clears it, and a value the core cannot use never reaches the
// settings file.
func TestBypassRows(t *testing.T) {
	m := newTestModel(t)

	ips := findRow(t, "IPs")
	if _, err := ips.commit(m, "10.0.0.0/8, 1.1.1.1"); err != nil {
		t.Fatalf("prefixes rejected: %v", err)
	}
	if len(m.cfg.Bypass.IPs) != 2 || m.cfg.Bypass.IPs[0] != "10.0.0.0/8" {
		t.Fatalf("ips = %v", m.cfg.Bypass.IPs)
	}
	if _, err := ips.commit(m, "example.com"); err == nil {
		t.Fatal("a name was accepted as a prefix")
	}
	if len(m.cfg.Bypass.IPs) != 2 {
		t.Fatalf("a refused edit must not change the list: %v", m.cfg.Bypass.IPs)
	}
	if _, err := ips.commit(m, ""); err != nil {
		t.Fatalf("clearing the list failed: %v", err)
	}
	if len(m.cfg.Bypass.IPs) != 0 {
		t.Fatalf("cleared list is %v", m.cfg.Bypass.IPs)
	}

	sites := findRow(t, "Sites")
	if _, err := sites.commit(m, "example.com, .internal.lan, *steam*"); err != nil {
		t.Fatalf("domains rejected: %v", err)
	}
	if len(m.cfg.Bypass.Domains) != 3 {
		t.Fatalf("domains = %v", m.cfg.Bypass.Domains)
	}
	if _, err := sites.commit(m, "https://example.com"); err == nil {
		t.Fatal("a pasted URL was accepted")
	}

	procs := findRow(t, "Processes")
	if _, err := procs.commit(m, "steam, EpicGamesLauncher, msedge web"); err != nil {
		t.Fatalf("processes rejected: %v", err)
	}
	if len(m.cfg.Bypass.Processes) != 3 || m.cfg.Bypass.Processes[2] != "msedge web" {
		t.Fatalf("processes = %v (a name with a space must survive)", m.cfg.Bypass.Processes)
	}
	if text := procs.text(m); !strings.Contains(text, "steam") {
		t.Fatalf("row text = %q", text)
	}
}

// An empty list reads as a fact, not as a blank cell.
func TestListText(t *testing.T) {
	if got := listText(nil); got != "none" {
		t.Fatalf("empty list = %q", got)
	}
	if got := listText([]string{"a", "b"}); got != "a, b" {
		t.Fatalf("list = %q", got)
	}
}
