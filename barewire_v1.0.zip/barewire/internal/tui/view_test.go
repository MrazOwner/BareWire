package tui

import (
	"strings"
	"testing"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/mock"
	"github.com/mrazowner/barewire/internal/proto"
)

func newTestModel(t *testing.T) *Model {
	t.Helper()
	dir := t.TempDir()
	client := mock.New()
	t.Cleanup(func() { _ = client.Close() })

	m := New(Options{
		Client:            client,
		Settings:          config.Defaults(),
		SettingsPath:      dir + "/settings.json",
		ProfilesPath:      dir + "/profiles.json",
		SubscriptionsPath: dir + "/subscriptions.json",
	})
	m.Update(tea.WindowSizeMsg{Width: 120, Height: 40})
	return m
}

func tabKey(n int) tea.KeyMsg {
	return tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{rune('0' + n)}}
}

// TestViewRendersEveryTab checks the invariant the box renderer promises: every
// tab fills the terminal exactly, with no ragged lines and no overflow.
func TestViewRendersEveryTab(t *testing.T) {
	m := newTestModel(t)
	for n := 1; n <= int(tabCount); n++ {
		m.Update(tabKey(n))
		if int(m.tab) != n-1 {
			t.Fatalf("tab key %d selected tab %d", n, m.tab)
		}
		lines := strings.Split(m.View(), "\n")
		if len(lines) != 40 {
			t.Fatalf("tab %d: %d lines, want 40", n, len(lines))
		}
		for i, line := range lines {
			if w := ansiWidth(line); w != 120 {
				t.Fatalf("tab %d line %d width = %d (%q)", n, i, w, line)
			}
		}
	}
}

func TestViewSurvivesSmallTerminal(t *testing.T) {
	m := newTestModel(t)
	m.Update(tea.WindowSizeMsg{Width: 60, Height: 18})
	for n := 1; n <= int(tabCount); n++ {
		m.Update(tabKey(n))
		if out := m.View(); out == "" {
			t.Fatalf("tab %d rendered nothing", n)
		}
	}
}

func TestStatusShowsLastCoreError(t *testing.T) {
	m := newTestModel(t)
	m.status = proto.Status{
		HostRunning: true,
		State:       proto.LinkConnected,
		LastError:   "connection: dial tcp 50.7.245.58:443: operation was canceled",
		LastErrorAt: time.Now(),
	}
	out := m.View()
	if !strings.Contains(out, "last error") {
		t.Fatalf("an up link with failing egress must show the error:\n%s", out)
	}
	if !strings.Contains(out, "50.7.245.58:443") {
		t.Fatalf("the error text must be visible:\n%s", out)
	}
}

func TestConnectRefusedWhenHostIsGone(t *testing.T) {
	m := newTestModel(t)
	m.status.HostRunning = false
	m.connect()
	found := false
	for i := 0; i < m.logs.Len(); i++ {
		if strings.Contains(m.logs.At(i).Text, "not running") {
			found = true
		}
	}
	if !found {
		t.Fatalf("refusal must be a log fact, log has %d lines", m.logs.Len())
	}
}

func TestCycleChoice(t *testing.T) {
	v := "gvisor"
	cycleChoice(&v, config.TUNStacks, 1)
	if v != "system" {
		t.Fatalf("forward cycle = %q", v)
	}
	cycleChoice(&v, config.TUNStacks, 1)
	if v != config.TUNStackSingTun {
		t.Fatalf("wrap cycle = %q", v)
	}
	cycleChoice(&v, config.TUNStacks, -1)
	if v != "system" {
		t.Fatalf("backward cycle = %q", v)
	}
	unknown := "quantum"
	cycleChoice(&unknown, config.TUNStacks, 1)
	if unknown != "mixed" {
		t.Fatalf("an unknown value must start from the first choice, got %q", unknown)
	}
}

func TestNextPreset(t *testing.T) {
	first := config.ColorPresets[0]
	if got := nextPreset("hand-typed", 1); got != config.ColorPresets[1] {
		t.Fatalf("unpreset value should start the walk at index 1, got %q", got)
	}
	last := config.ColorPresets[len(config.ColorPresets)-1]
	if got := nextPreset(last, 1); got != first {
		t.Fatalf("preset walk must wrap, got %q", got)
	}
}

func TestSplitList(t *testing.T) {
	got := splitList("1.1.1.1, 8.8.8.8;9.9.9.9   [2606:4700::1111]")
	want := []string{"1.1.1.1", "8.8.8.8", "9.9.9.9", "[2606:4700::1111]"}
	if len(got) != len(want) {
		t.Fatalf("splitList = %v", got)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("splitList = %v, want %v", got, want)
		}
	}
	if len(splitList("   ")) != 0 {
		t.Fatal("blank input must produce no entries")
	}
}

func TestGuessFormat(t *testing.T) {
	cases := map[string]string{
		"https://example.com/clash.yaml":                        "clash",
		"https://example.com/sub?clash=1":                       "clash",
		"https://example.com/api/v1/client/subscribe?token=abc": "v2ray",
	}
	for url, want := range cases {
		if got := guessFormat(url); got != want {
			t.Errorf("guessFormat(%q) = %q, want %q", url, got, want)
		}
	}
}
