package tui

import (
	"fmt"
	"strings"
	"testing"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/proto"
)

// A noisy core must not push the header, tabs or legend off the screen.
func TestLogsScreenKeepsGeometryWithManyLines(t *testing.T) {
	m := newTestModel(t)
	now := time.Now()
	for i := 0; i < 600; i++ {
		m.logs.Add(proto.LogEntry{
			Time:   now,
			Level:  proto.LevelError,
			Source: "core",
			Text: fmt.Sprintf(
				"\x1b[31mERROR\x1b[0m[0034] [%d 24.37s] connection: open connection to %s using outbound/vless[proxy]: dial tcp 82.139.249.1:443: operation was canceled",
				i, strings.Repeat("very.long.host.name.example.net.", 3)),
		})
	}
	m.Update(tabKey(3))

	for _, size := range [][2]int{{120, 40}, {80, 24}, {60, 18}} {
		m.Update(tea.WindowSizeMsg{Width: size[0], Height: size[1]})
		lines := strings.Split(m.View(), "\n")
		if len(lines) != size[1] {
			t.Fatalf("%dx%d: %d lines, want %d", size[0], size[1], len(lines), size[1])
		}
		for i, line := range lines {
			if w := ansiWidth(line); w != size[0] {
				t.Fatalf("%dx%d: line %d width %d, want %d (%q)", size[0], size[1], i, w, size[0], line)
			}
		}
	}

	m.Update(tea.WindowSizeMsg{Width: 120, Height: 40})
	if !strings.Contains(m.View(), "stream") {
		t.Fatal("the log stream must live in its own panel")
	}
	if !strings.Contains(m.View(), "1 Status") || !strings.Contains(m.View(), "BAREWIRE") {
		t.Fatal("header and tabs must stay on screen with a full log")
	}
}

func TestMultilineLogEntryDoesNotBreakLayout(t *testing.T) {
	m := newTestModel(t)
	m.logs.Add(proto.LogEntry{
		Time:  time.Now(),
		Level: proto.LevelError,
		Text:  "panic: something\n\ngoroutine 1 [running]:\nmain.main()",
	})
	m.Update(tabKey(3))
	m.Update(tea.WindowSizeMsg{Width: 100, Height: 30})
	lines := strings.Split(m.View(), "\n")
	if len(lines) != 30 {
		t.Fatalf("%d lines, want 30", len(lines))
	}
}
