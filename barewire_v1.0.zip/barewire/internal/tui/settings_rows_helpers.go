package tui

import (
	"fmt"
	"strconv"
	"strings"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
	"github.com/mrazowner/barewire/internal/system"
)

// mbpsRow builds a numeric row measured in Mbps.
func mbpsRow(label string, get func(*Model) int, set func(*Model, int)) formRow {
	return formRow{
		label: label,
		kind:  rowNumber,
		value: func(m *Model) string { return m.styles.Value.Render(strconv.Itoa(get(m))) },
		note:  func(*Model) string { return "h/l ±5 Mbps" },
		adjust: func(m *Model, d int) {
			set(m, clampMbps(get(m)+d*5))
			m.applySettings()
		},
		text: func(m *Model) string { return strconv.Itoa(get(m)) },
		commit: func(m *Model, raw string) (string, error) {
			v, err := strconv.Atoi(strings.TrimSpace(raw))
			if err != nil || v < 1 || v > 100000 {
				return "", fmt.Errorf("%s: want a number in 1..100000", strings.ToLower(label))
			}
			set(m, v)
			m.applySettings()
			return fmt.Sprintf("%s: %d Mbps", strings.ToLower(label), v), nil
		},
	}
}

// keepLabel renders the "leave it alone" value as a word instead of an empty
// cell: the kernel lever writes nothing when it is chosen.
func keepLabel(v string) string {
	if v == "" {
		return "keep"
	}
	return v
}

// kernelChoices is what the Algorithm lever walks: the whole catalogue, with the
// algorithms this machine already registers first.
//
// Showing only the registered list was the bug the user hit: `bbr` appeared once
// its module happened to be loaded and the rest never appeared at all, so a
// machine that can load `hybla` or `westwood` on demand looked like it had four
// options. Applying a value loads its module (Kernel.Ensure does the modprobe and
// verifies the result), so the list can offer them.
func kernelChoices(m *Model) []string {
	out := []string{""}
	seen := make(map[string]struct{}, len(system.KernelOptions())+1)
	for _, v := range m.status.CCOptions {
		if _, dup := seen[v]; dup {
			continue
		}
		seen[v] = struct{}{}
		out = append(out, v)
	}
	for _, opt := range system.KernelOptions() {
		if _, dup := seen[opt.Value]; dup {
			continue
		}
		seen[opt.Value] = struct{}{}
		out = append(out, opt.Value)
	}
	return out
}

// kernelNote explains a choice, and says when it is not loaded yet: an algorithm
// that arrives with a module is a different promise from one that is built in.
func kernelNote(m *Model, value string) string {
	if value == "" {
		return "leave the kernel alone"
	}
	note := system.KernelNote(value)
	if m.status.HostRunning && !kernelOffers(m, value) {
		if module := system.ModuleFor(value); module != "" {
			return note + " · the " + module + " module loads on apply"
		}
		return note + " · not registered by this kernel"
	}
	return note
}

// kernelStates puts the "keep" value in front of a choice list.
func kernelStates(all []string) []string {
	out := make([]string, 0, len(all)+1)
	out = append(out, "")
	return append(out, all...)
}

// congestionFact renders the live kernel state as one value: the algorithm and
// the queue discipline behind it.
func congestionFact(st proto.Status) string {
	if st.Congestion == "" {
		return dashes("")
	}
	if st.Qdisc == "" {
		return st.Congestion
	}
	return st.Congestion + " · " + st.Qdisc
}

// kernelLive is what the machine actually runs, read from the last status: the
// lever shows the wish, this shows the result.
func kernelLive(m *Model) string {
	cc := m.status.Congestion
	if cc == "" {
		cc = "unknown"
	}
	if m.status.Qdisc == "" {
		return m.styles.Dim.Render(cc)
	}
	return m.styles.Value.Render(cc) + m.styles.Dim.Render(" · "+m.status.Qdisc)
}

// qdiscNote explains a queue discipline in one line.
func qdiscNote(q string) string {
	switch q {
	case "":
		return "leave the kernel's queue discipline alone"
	case "fq":
		return "fair queueing · required by bbr"
	case "fq_codel":
		return "AQM, the usual default · keeps latency down"
	case "cake":
		return "AQM with shaping built in"
	}
	return "reported by the kernel"
}

// kernelLabel renders a lever set as one fact, for the profile list.
func kernelLabel(k config.KernelSettings) string {
	if k.Empty() {
		return "keep"
	}
	parts := make([]string, 0, 4)
	if k.Congestion != "" {
		parts = append(parts, k.Congestion)
	}
	if k.Qdisc != "" {
		parts = append(parts, k.Qdisc)
	}
	if k.MTUProbing != "" {
		parts = append(parts, "mtu probing "+k.MTUProbing)
	}
	if k.SlowStartAfterIdle != "" {
		parts = append(parts, "slow start "+k.SlowStartAfterIdle)
	}
	return strings.Join(parts, " · ")
}

// muxNote says what multiplexing needs before it can do anything: the outbound
// type must carry a multiplex section, the link must not use a flow, and the
// server must speak sing-mux.
func muxNote(m *Model) string {
	kind := m.status.Protocol
	if kind != "" && !config.SupportsMultiplex(kind) {
		return kind + " has no multiplex section · the lever is ignored"
	}
	if m.status.Flow != "" {
		return "the link uses flow " + m.status.Flow + " · a flow cannot be multiplexed"
	}
	return "needs a server that speaks sing-mux · tested once per connect"
}

// brutalNote says what TCP Brutal needs: a multiplex section, the kernel's
// "brutal" congestion control from the tcp_brutal module, and a server that
// agrees to the rate.
func brutalNote(m *Model) string {
	kind := m.status.Protocol
	if kind != "" && !config.SupportsMultiplex(kind) {
		return kind + " has no multiplex section · nothing to set"
	}
	if !kernelOffers(m, "brutal") {
		return "needs the tcp_brutal module · absent here, so it stays off"
	}
	return "fixed rate in the kernel · the server must enable it too"
}

// kernelOffers reports whether the last status listed a congestion control.
func kernelOffers(m *Model, value string) bool {
	for _, v := range m.status.CCOptions {
		if v == value {
			return true
		}
	}
	return false
}

// stackNote says what the chosen stack is made of. There is no separate
// implementation to pick: sing-tun is the library that implements all four, and
// the only thing the lever changes is who moves the packets.
func stackNote(stack string) string {
	switch stack {
	case config.TUNStackSingTun:
		return "sing-tun own stack · no stack field"
	case "mixed":
		return "sing-tun · kernel TCP, gvisor UDP · deprecated 1.15"
	case "gvisor":
		return "sing-tun · userspace TCP and UDP · deprecated 1.15"
	case "system":
		return "sing-tun · kernel TCP and UDP · deprecated 1.15"
	}
	return "sing-tun"
}

// listRow edits one comma-separated list in a single line. An empty line is a
// valid answer: it means the list is empty, which is how a lever is cleared.
func listRow(label, note string, get func(*Model) []string, set func(*Model, []string), validate func([]string) error) formRow {
	return formRow{
		label: label,
		kind:  rowText,
		value: func(m *Model) string { return m.styles.Value.Render(listText(get(m))) },
		text:  func(m *Model) string { return strings.Join(get(m), ", ") },
		note:  func(*Model) string { return note },
		commit: func(m *Model, raw string) (string, error) {
			entries := splitCommas(raw)
			if validate != nil {
				if err := validate(entries); err != nil {
					return "", err
				}
			}
			set(m, entries)
			m.applySettings()
			return "direct " + strings.ToLower(label) + ": " + listText(entries), nil
		},
	}
}

// listText renders an empty list as a fact instead of a blank cell.
func listText(entries []string) string {
	if len(entries) == 0 {
		return "none"
	}
	return strings.Join(entries, ", ")
}

// validatePrefixes keeps a typo out of ip_cidr.
func validatePrefixes(entries []string) error {
	for _, e := range entries {
		if err := config.ValidPrefix(e); err != nil {
			return fmt.Errorf("direct: %w", err)
		}
	}
	return nil
}

// validateDomains keeps a pasted URL or a lone star out of the domain rule; the
// rule itself would never match them.
func validateDomains(entries []string) error {
	for _, e := range entries {
		if strings.ContainsAny(e, "/@ ") || e == "*" {
			return fmt.Errorf("direct: %q is not a domain, a suffix or *keyword*", e)
		}
	}
	return nil
}

// colorRow builds an accent color row: presets on h/l, any valid color typed.
func colorRow(label string, get func(*Model) string, set func(*Model, string)) formRow {
	return formRow{
		label: label,
		kind:  rowColor,
		value: func(m *Model) string {
			c := get(m)
			return m.palette.Swatch(c) + " " + m.styles.Alt.Render(c)
		},
		adjust: func(m *Model, d int) {
			set(m, nextPreset(get(m), d))
			m.applySettings()
		},
		text: func(m *Model) string { return get(m) },
		commit: func(m *Model, raw string) (string, error) {
			c := strings.TrimSpace(raw)
			if !config.ValidColor(c) {
				return "", fmt.Errorf("color: %q is not #rgb, #rrggbb or an ansi name", c)
			}
			set(m, c)
			m.applySettings()
			return "theme: " + strings.ToLower(label) + " " + c, nil
		},
	}
}

// nextDNSPreset steps through the resolver presets. A hand-written list is not
// any preset, so it starts at the first one.
func nextDNSPreset(current string, d int) string {
	idx := -1
	for i, p := range config.DNSPresets {
		if p.Name == current {
			idx = i
			break
		}
	}
	n := len(config.DNSPresets)
	if idx < 0 {
		// A hand-written list is not a preset: step into the table from whichever
		// end the lever is heading towards.
		if d > 0 {
			idx = -1
		} else {
			idx = 0
		}
	}
	idx = ((idx+d)%n + n) % n
	return config.DNSPresets[idx].Name
}

// toggleValue renders a boolean lever as on/off.
func toggleValue(get func(*Model) bool) func(*Model) string {
	return func(m *Model) string {
		if get(m) {
			return m.styles.Alt.Render("on")
		}
		return m.styles.Dim.Render("off")
	}
}

func killSwitchState(m *Model) string {
	ks := m.status.KillSwitch
	switch {
	case !ks.Enabled:
		return "disabled in settings"
	case ks.Active:
		return fmt.Sprintf("active · ruleset v%d", ks.RulesetVersion)
	default:
		return "no ruleset present"
	}
}

// cycleChoice moves dst through choices by delta, wrapping around.
func cycleChoice(dst *string, choices []string, delta int) {
	if len(choices) == 0 {
		return
	}
	idx := 0
	for i, c := range choices {
		if c == *dst {
			idx = i
			break
		}
	}
	idx = ((idx+delta)%len(choices) + len(choices)) % len(choices)
	*dst = choices[idx]
}

// nextPreset moves through the accent presets; a hand-typed color that is not a
// preset starts the walk at the first entry.
func nextPreset(cur string, delta int) string {
	presets := config.ColorPresets
	idx := 0
	for i, c := range presets {
		if strings.EqualFold(c, cur) {
			idx = i
			break
		}
	}
	idx = ((idx+delta)%len(presets) + len(presets)) % len(presets)
	return presets[idx]
}

// splitCommas keeps entries that contain spaces — a path, a process name — so
// only a comma or a semicolon separates them. It is what the direct lists use.
func splitCommas(raw string) []string {
	fields := strings.FieldsFunc(raw, func(r rune) bool {
		return r == ',' || r == ';'
	})
	out := make([]string, 0, len(fields))
	for _, f := range fields {
		if f = strings.TrimSpace(f); f != "" {
			out = append(out, f)
		}
	}
	return out
}

// splitList splits resolvers, where a space is a separator too.
func splitList(raw string) []string {
	fields := strings.FieldsFunc(raw, func(r rune) bool {
		return r == ',' || r == ' ' || r == '\t' || r == ';'
	})
	out := make([]string, 0, len(fields))
	for _, f := range fields {
		if f = strings.TrimSpace(f); f != "" {
			out = append(out, f)
		}
	}
	return out
}

func mtuLabel(v int) string {
	if v == 0 {
		return "auto"
	}
	return strconv.Itoa(v)
}

func clampMbps(v int) int {
	if v < 1 {
		return 1
	}
	if v > 100000 {
		return 100000
	}
	return v
}
