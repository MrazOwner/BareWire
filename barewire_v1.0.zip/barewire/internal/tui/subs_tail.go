package tui

import (
	"context"
	"net/url"
	"strconv"
	"strings"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
	"github.com/mrazowner/barewire/internal/subscription"
	"github.com/mrazowner/barewire/internal/system"
)

func (s *subsScreen) Update(msg tea.Msg, m *Model) tea.Cmd {
	key, ok := msg.(tea.KeyMsg)
	if !ok {
		return nil
	}
	if s.editing {
		s.handleEdit(key, m)
		return nil
	}
	switch key.String() {
	case "j", "down":
		s.move(1)
	case "k", "up":
		s.move(-1)
	case "h", "left":
		s.pane = 0
		s.confirm = false
	case "l", "right":
		if len(s.st.Items) > 0 {
			s.pane = 1
		}
	case "a":
		s.editing = true
		s.editUA = false
		s.input.Reset()
		s.note = ""
	case "u":
		if len(s.st.Items) == 0 {
			return nil
		}
		s.editing = true
		s.editUA = true
		s.input.Set(s.st.Items[s.sel].UserAgent)
		s.note = ""
	case "r":
		return s.refresh(m)
	case "p":
		return s.ping(m)
	case "f":
		s.toggleFormat(m)
	case "enter":
		if s.pane == 1 {
			return s.selectNode(m)
		}
		s.openNodes()
		return nil
	case " ":
		// Space is the second way to pick a node: the list is a list of levers.
		if s.pane == 1 {
			return s.selectNode(m)
		}
		return nil
	case "d":
		return s.remove(m)
	}
	return nil
}

// openNodes moves the cursor into the node pane of the selected subscription.
func (s *subsScreen) openNodes() {
	if len(s.st.Items) == 0 {
		return
	}
	if len(s.st.Items[s.sel].Nodes) == 0 {
		return
	}
	s.pane = 1
	if s.ns >= len(s.st.Items[s.sel].Nodes) {
		s.ns = 0
	}
}

func (s *subsScreen) move(delta int) {
	if len(s.st.Items) == 0 || delta == 0 {
		return
	}
	s.confirm = false
	if s.pane == 1 {
		s.moveNode(delta)
		return
	}
	s.sel = clampIndex(s.sel+delta, len(s.st.Items))
	s.ns = 0
}

// moveNode walks the node list and continues into the neighbouring subscription
// instead of stopping at the edge: the cursor must always have somewhere to go
// while there is anything below or above it.
func (s *subsScreen) moveNode(delta int) {
	step := 1
	if delta < 0 {
		step = -1
	}
	nodes := len(s.st.Items[s.sel].Nodes)
	if next := s.ns + delta; next >= 0 && next < nodes {
		s.ns = next
		return
	}
	for i := s.sel + step; i >= 0 && i < len(s.st.Items); i += step {
		count := len(s.st.Items[i].Nodes)
		if count == 0 {
			continue
		}
		s.sel = i
		if step > 0 {
			s.ns = 0
		} else {
			s.ns = count - 1
		}
		return
	}
	if nodes > 0 {
		s.ns = clampIndex(s.ns, nodes)
	}
}

func clampIndex(v, count int) int {
	if count <= 0 {
		return 0
	}
	if v < 0 {
		return 0
	}
	if v >= count {
		return count - 1
	}
	return v
}

// manualSubName is where links pasted by hand live.
const manualSubName = "pasted links"

// addLinks parses share links and stores them in the manual subscription. A
// pasted list is normal: links that cannot be parsed are skipped.
func (s *subsScreen) addLinks(m *Model, raw string) {
	nodes := subscription.ParseLinks(raw)
	if len(nodes) == 0 {
		s.note = "no usable link found"
		m.logf(proto.LevelError, "link: nothing usable in %q", clip(strings.SplitN(raw, "\n", 2)[0], 60))
		return
	}
	idx := -1
	for i := range s.st.Items {
		if s.st.Items[i].Name == manualSubName {
			idx = i
			break
		}
	}
	if idx < 0 {
		s.st.Items = append(s.st.Items, config.Subscription{
			Name:      manualSubName,
			Format:    "links",
			UpdatedAt: time.Now(),
		})
		idx = len(s.st.Items) - 1
	}
	sub := &s.st.Items[idx]
	sub.Nodes = append(sub.Nodes, nodes...)
	sub.UpdatedAt = time.Now()
	s.sel = idx
	s.pane = 1
	s.ns = len(sub.Nodes) - len(nodes)
	s.note = ""
	s.save(m)
	m.logf(proto.LevelInfo, "link: %d node(s) added to %q: %s", len(nodes), manualSubName, nodes[0].Name)
}

func (s *subsScreen) handleEdit(key tea.KeyMsg, m *Model) {
	switch key.String() {
	case "esc":
		s.editing = false
		s.editUA = false
		s.input.Reset()
	case "enter":
		raw := strings.TrimSpace(s.input.Value)
		editingUA := s.editUA
		s.editing = false
		s.editUA = false
		s.input.Reset()
		if editingUA {
			if len(s.st.Items) == 0 {
				return
			}
			s.st.Items[s.sel].UserAgent = raw
			s.save(m)
			shown := raw
			if shown == "" {
				shown = "default"
			}
			m.logf(proto.LevelInfo, "subscription %s: user-agent %s", s.st.Items[s.sel].Name, shown)
			return
		}
		if raw == "" {
			return
		}
		if subscription.IsShareLink(raw) {
			s.addLinks(m, raw)
			return
		}
		sub := config.Subscription{Name: subNameFromURL(raw), URL: raw, Format: guessFormat(raw)}
		s.st.Items = append(s.st.Items, sub)
		s.sel = len(s.st.Items) - 1
		s.pane = 0
		s.save(m)
		m.logf(proto.LevelInfo, "subscription added: %s", sub.Name)
	case "backspace":
		s.input.Backspace()
	case "delete":
		s.input.Delete()
	case "left":
		s.input.Left()
	case "right":
		s.input.Right()
	case "home", "ctrl+a":
		s.input.Home()
	case "end", "ctrl+e":
		s.input.End()
	default:
		for _, r := range key.Runes {
			s.input.Insert(r)
		}
	}
}

func (s *subsScreen) refresh(m *Model) tea.Cmd {
	if len(s.st.Items) == 0 || s.busy {
		return nil
	}
	sub := s.st.Items[s.sel]
	idx := s.sel
	s.busy = true
	s.note = ""
	s.confirm = false
	m.logf(proto.LevelInfo, "subscription %s: fetch started", sub.Name)
	return func() tea.Msg {
		res, err := subscription.Fetch(context.Background(), sub.URL, sub.UserAgent)
		return subsFetchedMsg{idx: idx, res: res, err: err}
	}
}

func (s *subsScreen) handleFetched(m *Model, msg subsFetchedMsg) tea.Cmd {
	s.busy = false
	if msg.err != nil {
		m.logf(proto.LevelError, "subscription: %v", msg.err)
		s.note = msg.err.Error()
		return nil
	}
	if msg.idx < 0 || msg.idx >= len(s.st.Items) {
		return nil
	}
	sub := &s.st.Items[msg.idx]
	sub.Format = msg.res.Format
	sub.Nodes = msg.res.Nodes
	sub.UpdatedAt = time.Now()
	m.logf(proto.LevelInfo, "subscription %s: %s (%s), %s, %dms",
		sub.Name, pluralNodes(len(sub.Nodes)), msg.res.Format, bytesHuman(uint64(msg.res.Bytes)), msg.res.Took.Milliseconds())
	s.save(m)
	return nil
}

// ping measures every node of the selected subscription with a TCP handshake.
// It runs only on the key press: nothing is probed in the background.
func (s *subsScreen) ping(m *Model) tea.Cmd {
	if len(s.st.Items) == 0 || s.pinging {
		return nil
	}
	sub := s.st.Items[s.sel]
	if len(sub.Nodes) == 0 {
		return nil
	}
	idx := s.sel
	targets := make([]string, len(sub.Nodes))
	for i, n := range sub.Nodes {
		targets[i] = n.Endpoint()
	}
	s.pinging = true
	s.note = ""
	m.logf(proto.LevelInfo, "ping %s: %d nodes", sub.Name, len(targets))
	return func() tea.Msg {
		return pingReportMsg{idx: idx, results: system.PingAll(context.Background(), targets, 8, 2*time.Second)}
	}
}

// applyPing stores the measurements and reports the summary as a fact.
func (s *subsScreen) applyPing(m *Model, msg pingReportMsg) tea.Cmd {
	s.pinging = false
	if msg.idx < 0 || msg.idx >= len(s.st.Items) {
		return nil
	}
	sub := &s.st.Items[msg.idx]
	for _, r := range msg.results {
		if r.Index < 0 || r.Index >= len(sub.Nodes) {
			continue
		}
		if r.Err != nil {
			sub.Nodes[r.Index].LatencyMS = config.LatencyUnreachable
			continue
		}
		sub.Nodes[r.Index].LatencyMS = int(r.Latency.Milliseconds())
	}
	s.save(m)
	m.logf(proto.LevelInfo, "ping %s: %d/%d reachable, median %dms",
		sub.Name, system.Reachable(msg.results), len(msg.results), system.MedianLatency(msg.results).Milliseconds())
	return nil
}

func (s *subsScreen) toggleFormat(m *Model) {
	if len(s.st.Items) == 0 {
		return
	}
	sub := &s.st.Items[s.sel]
	if sub.Format == subscription.FormatClash {
		sub.Format = subscription.FormatV2Ray
	} else {
		sub.Format = subscription.FormatClash
	}
	m.logf(proto.LevelInfo, "subscription %s: format %s", sub.Name, sub.Format)
	s.save(m)
}

func (s *subsScreen) remove(m *Model) tea.Cmd {
	if len(s.st.Items) == 0 {
		return nil
	}
	if !s.confirm {
		s.confirm = true
		return nil
	}
	name := s.st.Items[s.sel].Name
	s.st.Items = append(s.st.Items[:s.sel], s.st.Items[s.sel+1:]...)
	if s.sel >= len(s.st.Items) && s.sel > 0 {
		s.sel--
	}
	s.confirm = false
	s.ns = 0
	m.logf(proto.LevelInfo, "subscription removed: %s", name)
	s.save(m)
	return nil
}

func (s *subsScreen) selectNode(m *Model) tea.Cmd {
	if s.pane != 1 || len(s.st.Items) == 0 {
		return nil
	}
	nodes := s.st.Items[s.sel].Nodes
	if s.ns < 0 || s.ns >= len(nodes) {
		return nil
	}
	node := nodes[s.ns]
	return m.selectNode(node)
}

func (s *subsScreen) save(m *Model) {
	if err := config.SaveSubscriptions(s.path, s.st); err != nil {
		m.logf(proto.LevelError, "subscriptions: %v", err)
	}
}

func subNameFromURL(raw string) string {
	u, err := url.Parse(raw)
	if err != nil || u.Hostname() == "" {
		return "subscription"
	}
	return u.Hostname()
}

func guessFormat(raw string) string {
	lower := strings.ToLower(raw)
	if strings.Contains(lower, "clash") || strings.HasSuffix(lower, ".yaml") || strings.HasSuffix(lower, ".yml") {
		return subscription.FormatClash
	}
	return subscription.FormatV2Ray
}

func pluralNodes(n int) string {
	if n == 1 {
		return "1 node"
	}
	return strconv.Itoa(n) + " nodes"
}
