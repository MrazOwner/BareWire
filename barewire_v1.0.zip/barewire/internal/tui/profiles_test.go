package tui

import (
	"strings"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
)

// A link with a flow says why multiplexing cannot be used, instead of offering a
// lever that the builder will ignore.
func TestMuxNoteExplainsAFlow(t *testing.T) {
	m := newTestModel(t)
	m.status.Protocol = "vless"
	if got := muxNote(m); !strings.Contains(got, "sing-mux") {
		t.Fatalf("plain note = %q", got)
	}
	m.status.Flow = "xtls-rprx-vision"
	if got := muxNote(m); !strings.Contains(got, "xtls-rprx-vision") {
		t.Fatalf("flow note = %q", got)
	}
	m.status.Protocol = "hysteria2"
	if got := muxNote(m); !strings.Contains(got, "no multiplex section") {
		t.Fatalf("protocol note = %q", got)
	}
}

// The presets ship with the program, so a fresh install has something to press
// instead of an empty list.
func TestProfilesAreSeeded(t *testing.T) {
	m := newTestModel(t)
	if got := len(m.profilesView.st.Items); got != len(config.Presets()) {
		t.Fatalf("%d profiles, want the %d presets", got, len(config.Presets()))
	}
	for _, p := range m.profilesView.st.Items {
		if !p.Builtin {
			t.Fatalf("seeded profile %q is not marked as built-in", p.Name)
		}
	}
}

// Activating a profile is a promise that later changes belong to it: editing a
// lever has to reach the profile, not only settings.json. Before this, activating
// the same profile again silently undid the work.
func TestActiveProfileFollowsTheSettings(t *testing.T) {
	m := newTestModel(t)
	s := m.profilesView
	s.sel = 0
	s.activate(m)
	name := m.cfg.Profile
	if name == "" {
		t.Fatal("activating a profile must name it in the settings")
	}

	findRow(t, "MTU").adjust(m, 1)
	if m.cfg.MTU == 0 {
		t.Fatal("the MTU row did not change anything")
	}

	st, err := config.LoadProfiles(m.profPath)
	if err != nil {
		t.Fatalf("load profiles: %v", err)
	}
	idx, ok := st.Find(name)
	if !ok {
		t.Fatalf("profile %q disappeared", name)
	}
	if st.Items[idx].Settings.MTU != m.cfg.MTU {
		t.Fatalf("profile mtu %d, live %d", st.Items[idx].Settings.MTU, m.cfg.MTU)
	}
	if !settingsEqual(st.Items[idx].Settings, m.cfg) {
		t.Fatal("the active profile does not match the live settings")
	}

	// Switching to the same profile again has to keep the change, which is what
	// "activate" used to destroy.
	s.Refresh(m.cfg)
	s.sel = 0
	s.activate(m)
	if m.cfg.MTU != st.Items[idx].Settings.MTU {
		t.Fatalf("re-activating reverted the mtu: %d", m.cfg.MTU)
	}
}

// "Save current into it" writes the live lever set into another profile without
// activating it.
func TestProfileSaveCurrent(t *testing.T) {
	m := newTestModel(t)
	s := m.profilesView
	m.cfg.MTU = 1300

	s.sel = 1
	target := s.st.Items[1].Name
	s.saveCurrent(m)
	if m.cfg.Profile != target {
		t.Fatalf("active profile = %q, want %q", m.cfg.Profile, target)
	}
	st, err := config.LoadProfiles(m.profPath)
	if err != nil {
		t.Fatalf("load: %v", err)
	}
	idx, ok := st.Find(target)
	if !ok {
		t.Fatalf("%q is gone", target)
	}
	if st.Items[idx].Settings.MTU != 1300 {
		t.Fatalf("saved mtu = %d, want 1300", st.Items[idx].Settings.MTU)
	}
}
