package tui

import (
	"fmt"
	"strings"

	"github.com/mrazowner/barewire/internal/proto"
)

// logsScreen is the mirror: facts on top, the raw stream below, no conclusions.
type logsScreen struct {
	w, h     int
	min      proto.LogLevel
	query    string
	editing  bool
	input    Input
	offset   int
	auto     bool
	conns    bool
	viewport int
}

func newLogsScreen() *logsScreen {
	return &logsScreen{min: proto.LevelInfo, auto: true}
}

func (s *logsScreen) Resize(w, h int) {
	s.w, s.h = w, h
}

func (s *logsScreen) Capturing() bool { return s.editing }

func (s *logsScreen) Hints() []Hint {
	if s.editing {
		return []Hint{{"enter", "apply filter"}, {"esc", "cancel"}}
	}
	return []Hint{
		{"j/k", "scroll"},
		{"a", "follow"},
		{"l", "level"},
		{"/", "filter"},
		{"c", "connections"},
	}
}

func (s *logsScreen) Body(m *Model, w, h int) []string {
	head := []string{
		s.factLine(m, w),
		s.tuningLine(m, w),
		s.trafficLine(m, w),
		s.filterLine(m, w),
	}
	boxH := h - len(head)
	if boxH < 4 || w < 10 {
		// Too small for a nested box: draw the stream bare, still clipped to the
		// height we were given.
		s.viewport = maxInt(h-len(head), 1)
		return append(head, s.streamLines(m, w, s.viewport)...)
	}
	title := "stream"
	if s.conns {
		title = "connections"
	}
	s.viewport = boxH - 2
	content := s.streamLines(m, w-2, s.viewport)
	box := RenderBox(title, w, boxH, content, m.styles)
	return append(head, strings.Split(box, "\n")...)
}

// streamLines renders the visible slice of the log stream (or the connection
// table) into at most height lines. Everything longer is clipped inside the
// panel, so a noisy core can never push the tabs off the screen.
func (s *logsScreen) streamLines(m *Model, w, height int) []string {
	if height < 1 {
		height = 1
	}
	if s.conns {
		return s.connectionLines(m, w, height)
	}
	entries := m.logs.Filter(s.min, s.query)
	total := len(entries)
	maxOffset := total - height
	if maxOffset < 0 {
		maxOffset = 0
	}
	if s.offset > maxOffset {
		s.offset = maxOffset
	}
	start := total - height - s.offset
	if start < 0 {
		start = 0
	}
	end := start + height
	if end > total {
		end = total
	}
	out := make([]string, 0, height)
	for i := start; i < end; i++ {
		out = append(out, s.entryLine(m, entries[i], w))
	}
	return out
}

func (s *logsScreen) factLine(m *Model, w int) string {
	st := m.status
	sty := m.styles
	part := func(label, value string) string {
		return sty.Label.Render(label+" ") + sty.Value.Render(dashes(value))
	}
	return fit(joinNonEmpty(" · ",
		part("outbound", st.Outbound),
		part("rule", st.Rule),
		part("server", st.Server),
	), w)
}

func (s *logsScreen) tuningLine(m *Model, w int) string {
	st := m.status
	sty := m.styles
	brutal := "off"
	if st.Brutal.Enabled {
		brutal = fmt.Sprintf("on %d/%d", st.Brutal.UpMbps, st.Brutal.DownMbps)
	}
	return fit(joinNonEmpty(" · ",
		sty.Label.Render("mtu ")+sty.Value.Render(fmt.Sprintf("%d", st.MTU)),
		sty.Label.Render("stack ")+sty.Value.Render(dashes(st.TUNStack)),
		sty.Label.Render("brutal ")+sty.Value.Render(brutal),
		sty.Label.Render("congestion ")+sty.Value.Render(dashes(st.Congestion)),
		sty.Label.Render("mux ")+sty.Value.Render(smuxFact(st)),
	), w)
}

func (s *logsScreen) trafficLine(m *Model, w int) string {
	st := m.status
	sty := m.styles
	return fit(joinNonEmpty(" · ",
		sty.Alt.Render("↑ "+rateHuman(st.UpBps)),
		sty.Alt.Render("↓ "+rateHuman(st.DownBps)),
		sty.Label.Render("reconnects ")+sty.Value.Render(fmt.Sprintf("%d", st.Reconnects)),
		sty.Label.Render("last ")+sty.Value.Render(disconnectFact(st)),
	), w)
}

func (s *logsScreen) filterLine(m *Model, w int) string {
	sty := m.styles
	if s.editing {
		width := w - 20
		if width < 8 {
			width = 8
		}
		return fit(sty.Key.Render("[filter: ")+s.input.View(width)+sty.Key.Render("]"), w)
	}
	level := sty.Key.Render("[level ≥ " + string(s.min) + "]")
	query := sty.Dim.Render("[filter: none]")
	if s.query != "" {
		query = sty.Key.Render("[filter: " + s.query + "]")
	}
	follow := sty.Dim.Render("[follow: off]")
	if s.auto {
		follow = sty.Key.Render("[follow: on]")
	}
	view := sty.Dim.Render("[view: logs]")
	if s.conns {
		view = sty.Key.Render("[view: connections]")
	}
	return fit(strings.Join([]string{level, query, follow, view}, "  "), w)
}
