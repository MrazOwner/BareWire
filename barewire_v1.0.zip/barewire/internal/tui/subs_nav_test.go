package tui

import (
	"fmt"
	"strings"
	"testing"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
)

func nodesN(prefix string, n int) []config.Node {
	out := make([]config.Node, 0, n)
	for i := 0; i < n; i++ {
		out = append(out, config.Node{
			Name: fmt.Sprintf("%s-%d", prefix, i), Kind: "vless",
			Address: "example.net", Port: 443, LatencyMS: -1,
		})
	}
	return out
}

func newSubsModel(t *testing.T) *Model {
	t.Helper()
	m := newHostStartModel(t, nil)
	m.subsView.st.Items = []config.Subscription{
		{Name: "first", URL: "https://example.invalid/a", Format: "clash", Nodes: nodesN("first", 3)},
		{Name: "second", URL: "https://example.invalid/b", Format: "v2ray", Nodes: nodesN("second", 2)},
	}
	m.switchTab(tabSubscriptions)
	return m
}

func TestSpaceSelectsNode(t *testing.T) {
	m := newSubsModel(t)
	host := &fakeHost{events: make(chan proto.Event)}
	m.client = host
	m.status.HostRunning = true
	m.subsView.pane = 1
	m.subsView.sel = 0
	m.subsView.ns = 1

	m.Update(tea.KeyMsg{Type: tea.KeySpace, Runes: []rune{' '}})

	if host.selected != "first-1" {
		t.Fatalf("space must select the node under the cursor, selected %q", host.selected)
	}
	if m.subsView.sel != 0 || m.subsView.ns != 1 {
		t.Fatalf("selection must not move: sel=%d ns=%d", m.subsView.sel, m.subsView.ns)
	}
}

func TestEnterOpensNodesThenSelects(t *testing.T) {
	m := newSubsModel(t)
	host := &fakeHost{events: make(chan proto.Event)}
	m.client = host
	m.status.HostRunning = true
	m.subsView.pane = 0
	m.subsView.sel = 0

	m.Update(tea.KeyMsg{Type: tea.KeyEnter})
	if m.subsView.pane != 1 {
		t.Fatalf("enter on a subscription must open its nodes, pane=%d", m.subsView.pane)
	}
	m.Update(tea.KeyMsg{Type: tea.KeyEnter})
	if host.selected != "first-0" {
		t.Fatalf("enter in the node pane must select, selected %q", host.selected)
	}
}

func TestArrowsWalkIntoNextSubscription(t *testing.T) {
	m := newSubsModel(t)
	sv := m.subsView
	sv.pane = 1
	sv.sel = 0
	sv.ns = 2 // last node of the first subscription

	m.Update(tea.KeyMsg{Type: tea.KeyDown})
	if sv.sel != 1 || sv.ns != 0 {
		t.Fatalf("down past the last node must move to the next subscription: sel=%d ns=%d", sv.sel, sv.ns)
	}
	m.Update(tea.KeyMsg{Type: tea.KeyUp})
	if sv.sel != 0 || sv.ns != 2 {
		t.Fatalf("up past the first node must move to the previous subscription: sel=%d ns=%d", sv.sel, sv.ns)
	}
}

func TestArrowsSkipEmptySubscriptions(t *testing.T) {
	m := newSubsModel(t)
	m.subsView.st.Items = []config.Subscription{
		{Name: "empty", Nodes: nil},
		{Name: "full", Nodes: nodesN("n", 2)},
		{Name: "also-empty", Nodes: nil},
	}
	sv := m.subsView
	sv.pane = 1
	sv.sel = 0
	sv.ns = 0

	m.Update(tea.KeyMsg{Type: tea.KeyDown})
	if sv.sel != 1 || sv.ns != 0 {
		t.Fatalf("down must skip subscriptions without nodes: sel=%d ns=%d", sv.sel, sv.ns)
	}
}

func TestUserAgentCanBeEdited(t *testing.T) {
	m := newSubsModel(t)
	m.subsView.pane = 0
	m.subsView.sel = 0

	m.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'u'}})
	if !m.subsView.editing || !m.subsView.editUA {
		t.Fatal("u must open the user-agent field")
	}
	for _, r := range "clash.meta" {
		m.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{r}})
	}
	m.Update(tea.KeyMsg{Type: tea.KeyEnter})

	if got := m.subsView.st.Items[0].UserAgent; got != "clash.meta" {
		t.Fatalf("user agent = %q", got)
	}
	if !strings.Contains(m.View(), "ua clash.meta") {
		t.Fatal("the subscription line must show the agent in use")
	}
}

func TestNodeListScrollsWithCursor(t *testing.T) {
	m := newSubsModel(t)
	m.subsView.st.Items = []config.Subscription{{Name: "big", Nodes: nodesN("node", 40)}}
	m.subsView.pane = 1
	m.subsView.sel = 0
	m.subsView.ns = 39

	out := m.View()
	if !strings.Contains(out, "node-39") {
		t.Fatalf("the selected node is off screen:\n%s", out)
	}
	if strings.Contains(out, "node-0 ") {
		t.Fatalf("the list did not move: the first node is still drawn:\n%s", out)
	}
}
