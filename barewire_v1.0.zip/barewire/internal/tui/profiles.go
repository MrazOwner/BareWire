package tui

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/mrazowner/barewire/internal/config"
)

// profilesScreen is the memory of what the user already configured: named lever
// sets, optionally bound to a server or a network. It never chooses on its own.
type profilesScreen struct {
	w, h int
	path string
	st   config.ProfileStore
	sel  int

	mode    int
	input   Input
	note    string
	confirm bool
}

const (
	profileModeIdle = iota
	profileModeNew
	profileModeRename
	profileModeBindNetwork
)

func newProfilesScreen(path string, cfg config.Settings) *profilesScreen {
	s := &profilesScreen{path: path}
	s.st, s.note = loadSeeded(path)
	s.selectActive(cfg)
	return s
}

// loadSeeded reads the store and fills an empty one with the built-in presets, so
// a fresh install has something to press. It returns the store and a note for the
// screen: a file that cannot be read is a fact, not something to swallow.
func loadSeeded(path string) (config.ProfileStore, string) {
	st, err := config.LoadProfiles(path)
	note := ""
	if err != nil {
		note = err.Error()
	}
	st, seeded := config.SeedProfiles(st)
	if seeded {
		if err := config.SaveProfiles(path, st); err != nil {
			note = err.Error()
		}
	}
	return st, note
}

// Refresh re-reads the store. The settings screen writes the active profile on
// every change, so a list rendered from a snapshot taken at startup would show
// values the user has already replaced.
func (s *profilesScreen) Refresh(cfg config.Settings) {
	selName := ""
	if s.sel >= 0 && s.sel < len(s.st.Items) {
		selName = s.st.Items[s.sel].Name
	}
	st, note := loadSeeded(s.path)
	s.st = st
	if note != "" {
		s.note = note
	}
	if idx, ok := s.st.Find(selName); ok {
		s.sel = idx
		return
	}
	s.selectActive(cfg)
}

// selectActive puts the cursor on the profile the settings came from.
func (s *profilesScreen) selectActive(cfg config.Settings) {
	if idx, ok := s.st.Find(cfg.Profile); ok {
		s.sel = idx
	}
	if s.sel >= len(s.st.Items) {
		s.sel = 0
	}
}

func (s *profilesScreen) Resize(w, h int) {
	s.w, s.h = w, h
}

func (s *profilesScreen) Capturing() bool { return s.mode != profileModeIdle }

func (s *profilesScreen) Hints() []Hint {
	if s.mode != profileModeIdle {
		return []Hint{{"enter", "commit"}, {"esc", "cancel"}}
	}
	return []Hint{
		{"j/k", "move"},
		{"enter", "activate"},
		{"s", "save current into it"},
		{"n", "new from current"},
		{"r", "rename"},
		{"d", "remove"},
		{"b", "bind network"},
		{"S", "bind server"},
	}
}

func (s *profilesScreen) Body(m *Model, w, h int) []string {
	leftW := w / 2
	if leftW < 28 {
		leftW = w
	}
	left := RenderBox("Profiles", leftW, h, s.listLines(m, leftW-2, h-2), m.styles)
	rightW := w - leftW - 2
	if rightW < 22 {
		return strings.Split(left, "\n")
	}
	right := RenderBox("Profile", rightW, h, s.detailLines(m, rightW-2, h-2), m.styles)
	return strings.Split(Columns(2, []int{leftW, rightW}, []string{left, right}), "\n")
}

func (s *profilesScreen) listLines(m *Model, w, h int) []string {
	sty := m.styles
	start, end := listWindow(len(s.st.Items), s.sel, 2, h)
	out := make([]string, 0, (end-start)*2+3)
	for i := start; i < end; i++ {
		p := s.st.Items[i]
		marker := "  "
		if i == s.sel {
			marker = sty.Sel.Render("› ")
		}
		name := p.Name
		if s.st.Active == p.Name {
			name += " " + sty.Alt.Render("active")
			// The settings file is the live lever set and the profile is the
			// memory of it; they are written together, so a difference means the
			// profile is out of step (an edit from outside, or a fresh preset).
			if !settingsEqual(p.Settings, m.cfg) {
				name += " " + sty.Dim.Render("(differs)")
			}
		}
		if p.Builtin {
			name = sty.Dim.Render("· ") + name
		}
		out = append(out, marker+sty.Value.Render(clip(name, w-2)))
		summary := profileSummary(p)
		if p.Note != "" {
			summary = p.Note
		}
		out = append(out, "  "+sty.Dim.Render(clip(summary, w-2)))
	}
	if s.mode != profileModeIdle {
		label := map[int]string{
			profileModeNew:         "name: ",
			profileModeRename:      "new name: ",
			profileModeBindNetwork: "network: ",
		}[s.mode]
		width := w - ansiWidth(label) - 2
		if width < 8 {
			width = 8
		}
		out = append(out, "", sty.Key.Render(label)+s.input.View(width))
	}
	if s.confirm && len(s.st.Items) > 0 {
		out = append(out, sty.Err.Render(clip("press d again to remove "+s.st.Items[s.sel].Name, w)))
	}
	if s.note != "" {
		out = append(out, sty.Dim.Render(clip(s.note, w)))
	}
	if len(s.st.Items) == 0 {
		out = append(out, sty.Dim.Render("no profiles"), "", sty.Dim.Render("[n] save current settings"))
	}
	return out
}

func (s *profilesScreen) detailLines(m *Model, w, h int) []string {
	if len(s.st.Items) == 0 {
		return []string{m.styles.Dim.Render("—")}
	}
	p := s.st.Items[s.sel]
	sty := m.styles
	fact := func(label, value string) string {
		return twoCols(sty.Label.Render(padRight(label, 16)), sty.Value.Render(dashes(value)), w)
	}
	brutal := "off"
	if p.Settings.Brutal.Enabled {
		brutal = fmt.Sprintf("on %d/%d", p.Settings.Brutal.UpMbps, p.Settings.Brutal.DownMbps)
	}
	mux := "off"
	if p.Settings.Smux.Enabled {
		mux = p.Settings.Smux.Protocol
	}
	kill := "off"
	if p.Settings.KillSwitch.Enabled {
		kill = "on · " + p.Settings.KillSwitch.OnCrash + " / " + p.Settings.KillSwitch.OnNetworkChange
	}
	lines := []string{
		fact("name", p.Name),
		fact("tun stack", p.Settings.TUNStack),
		fact("mtu", mtuLabel(p.Settings.MTU)),
		fact("dns", p.Settings.DNS.Mode+" · "+strings.Join(p.Settings.DNS.Servers, ", ")),
		fact("mux", mux),
		fact("brutal", brutal),
		fact("kill switch", kill),
		fact("congestion", kernelLabel(p.Settings.Kernel)),
		fact("bound server", p.BoundServer),
		fact("bound network", p.BoundNetwork),
		fact("updated", dateTime(p.UpdatedAt)),
	}
	if len(lines) > h {
		lines = lines[:h]
	}
	return lines
}

func profileSummary(p config.Profile) string {
	parts := []string{p.Settings.TUNStack, "mtu " + mtuLabel(p.Settings.MTU)}
	if p.Settings.Brutal.Enabled {
		parts = append(parts, "brutal")
	}
	if p.BoundNetwork != "" {
		parts = append(parts, "net:"+p.BoundNetwork)
	}
	if p.BoundServer != "" {
		parts = append(parts, "srv:"+p.BoundServer)
	}
	return strings.Join(parts, " · ")
}

// settingsEqual compares two lever sets by value. The profile list uses it to say
// whether the active profile still matches what the interface holds.
func settingsEqual(a, b config.Settings) bool {
	left, err := json.Marshal(a)
	if err != nil {
		return false
	}
	right, err := json.Marshal(b)
	if err != nil {
		return false
	}
	return string(left) == string(right)
}

func boolLabel(v bool) string {
	if v {
		return "on"
	}
	return "off"
}
