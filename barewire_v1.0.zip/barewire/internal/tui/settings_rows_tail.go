package tui

import (
	"github.com/mrazowner/barewire/internal/config"
)

// buildSettingsRowsTail is the second half of the lever list: multiplexing,
// congestion control, firewall and theme.
func buildSettingsRowsTail() []formRow {
	return []formRow{
		{label: "Multiplexing", kind: rowHeader},
		{
			label: "Enabled",
			kind:  rowToggle,
			value: toggleValue(func(m *Model) bool { return m.cfg.Smux.Enabled }),
			note:  func(m *Model) string { return muxNote(m) },
			adjust: func(m *Model, _ int) {
				m.cfg.Smux.Enabled = !m.cfg.Smux.Enabled
				m.applySettings()
			},
		},
		{
			label: "Protocol",
			kind:  rowChoice,
			value: func(m *Model) string { return m.styles.Value.Render(m.cfg.Smux.Protocol) },
			adjust: func(m *Model, d int) {
				cycleChoice(&m.cfg.Smux.Protocol, config.SmuxProtocols, d)
				m.applySettings()
			},
		},
		{
			label: "Padding",
			kind:  rowToggle,
			value: toggleValue(func(m *Model) bool { return m.cfg.Smux.Padding }),
			adjust: func(m *Model, _ int) {
				m.cfg.Smux.Padding = !m.cfg.Smux.Padding
				m.applySettings()
			},
		},

		{label: "TCP Brutal", kind: rowHeader},
		{
			label: "Enabled",
			kind:  rowToggle,
			value: toggleValue(func(m *Model) bool { return m.cfg.Brutal.Enabled }),
			note:  func(m *Model) string { return brutalNote(m) },
			adjust: func(m *Model, _ int) {
				m.cfg.Brutal.Enabled = !m.cfg.Brutal.Enabled
				m.applySettings()
			},
		},
		mbpsRow("Up Mbps", func(m *Model) int { return m.cfg.Brutal.UpMbps },
			func(m *Model, v int) { m.cfg.Brutal.UpMbps = v }),
		mbpsRow("Down Mbps", func(m *Model) int { return m.cfg.Brutal.DownMbps },
			func(m *Model, v int) { m.cfg.Brutal.DownMbps = v }),
		{
			label: "Auto-detect Brutal",
			kind:  rowAction,
			value: func(m *Model) string { return m.styles.Dim.Render("throughput test") },
			note:  func(*Model) string { return "measures the tunnel · needs the link up" },
			run:   probeBrutalCmd,
		},

		{label: "Kernel", kind: rowHeader},
		{
			label: "Algorithm",
			kind:  rowChoice,
			value: func(m *Model) string { return m.styles.Value.Render(keepLabel(m.cfg.Kernel.Congestion)) },
			note:  func(m *Model) string { return kernelNote(m, m.cfg.Kernel.Congestion) },
			adjust: func(m *Model, d int) {
				cycleChoice(&m.cfg.Kernel.Congestion, kernelChoices(m), d)
				m.applySettings()
			},
		},
		{
			label: "Queue discipline",
			kind:  rowChoice,
			value: func(m *Model) string { return m.styles.Value.Render(keepLabel(m.cfg.Kernel.Qdisc)) },
			note:  func(m *Model) string { return qdiscNote(m.cfg.Kernel.Qdisc) },
			adjust: func(m *Model, d int) {
				cycleChoice(&m.cfg.Kernel.Qdisc, kernelStates(config.KernelQdiscs), d)
				m.applySettings()
			},
		},
		{
			label: "MTU probing",
			kind:  rowChoice,
			value: func(m *Model) string { return m.styles.Value.Render(keepLabel(m.cfg.Kernel.MTUProbing)) },
			note:  func(*Model) string { return "on finds a shrinking path · fixes silent black holes" },
			adjust: func(m *Model, d int) {
				cycleChoice(&m.cfg.Kernel.MTUProbing, kernelStates(config.KernelStates), d)
				m.applySettings()
			},
		},
		{
			label: "Slow start after idle",
			kind:  rowChoice,
			value: func(m *Model) string { return m.styles.Value.Render(keepLabel(m.cfg.Kernel.SlowStartAfterIdle)) },
			note:  func(*Model) string { return "off keeps the window after a pause · on restarts from 10" },
			adjust: func(m *Model, d int) {
				cycleChoice(&m.cfg.Kernel.SlowStartAfterIdle, kernelStates(config.KernelStates), d)
				m.applySettings()
			},
		},
		{
			label: "QUIC congestion",
			kind:  rowChoice,
			value: func(m *Model) string { return m.styles.Value.Render(keepLabel(m.cfg.Kernel.QuicCongestion)) },
			note:  func(*Model) string { return "inside the QUIC transport · tuic only · the kernel cannot reach it" },
			adjust: func(m *Model, d int) {
				cycleChoice(&m.cfg.Kernel.QuicCongestion, kernelStates(config.QuicCongestions), d)
				m.applySettings()
			},
		},
		{
			label: "Test algorithms",
			kind:  rowAction,
			value: func(m *Model) string {
				if m.status.KernelBest != "" {
					return m.styles.Dim.Render("best for this server: " + m.status.KernelBest)
				}
				return m.styles.Dim.Render("measures the live path")
			},
			run: testKernelCmd,
		},
		{
			label: "Applied",
			kind:  rowInfo,
			value: func(m *Model) string { return kernelLive(m) },
		},

		{label: "Kill switch", kind: rowHeader},
		{
			label: "Enabled",
			kind:  rowToggle,
			value: toggleValue(func(m *Model) bool { return m.cfg.KillSwitch.Enabled }),
			adjust: func(m *Model, _ int) {
				m.cfg.KillSwitch.Enabled = !m.cfg.KillSwitch.Enabled
				m.applySettings()
			},
		},
		{
			label: "On core crash",
			kind:  rowChoice,
			value: func(m *Model) string { return m.styles.Value.Render(m.cfg.KillSwitch.OnCrash) },
			adjust: func(m *Model, d int) {
				cycleChoice(&m.cfg.KillSwitch.OnCrash, config.KillSwitchPolicies, d)
				m.applySettings()
			},
		},
		{
			label: "On network change",
			kind:  rowChoice,
			value: func(m *Model) string { return m.styles.Value.Render(m.cfg.KillSwitch.OnNetworkChange) },
			adjust: func(m *Model, d int) {
				cycleChoice(&m.cfg.KillSwitch.OnNetworkChange, config.KillSwitchPolicies, d)
				m.applySettings()
			},
		},
		{
			label: "Flush ruleset now",
			kind:  rowAction,
			value: func(m *Model) string { return m.styles.Dim.Render(killSwitchState(m)) },
			run:   flushKillSwitchCmd,
		},

		{label: "Theme", kind: rowHeader},
		colorRow("Accent", func(m *Model) string { return m.cfg.Theme.Accent },
			func(m *Model, v string) { m.cfg.Theme.Accent = v }),
		colorRow("Accent alt", func(m *Model) string { return m.cfg.Theme.AccentAlt },
			func(m *Model, v string) { m.cfg.Theme.AccentAlt = v }),
	}
}
