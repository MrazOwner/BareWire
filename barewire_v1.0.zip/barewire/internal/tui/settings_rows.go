package tui

import (
	"fmt"
	"strconv"
	"strings"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
)

// Async results produced by the lever actions.
type autoMTUResult struct {
	mtu int
	err error
}

type autoBrutalResult struct {
	up, down int
	err      error
}

type killSwitchFlushed struct {
	err error
}

// kernelTestResult carries the trials of one run; the table itself is already in
// the log, so the interface only needs the winner.
type kernelTestResult struct {
	trials []proto.KernelTrial
	err    error
}

func probeMTUCmd(m *Model) tea.Cmd {
	client := m.client
	return func() tea.Msg {
		mtu, err := client.AutoMTU()
		return autoMTUResult{mtu: mtu, err: err}
	}
}

func probeBrutalCmd(m *Model) tea.Cmd {
	client := m.client
	return func() tea.Msg {
		up, down, err := client.AutoBrutal()
		return autoBrutalResult{up: up, down: down, err: err}
	}
}

func flushKillSwitchCmd(m *Model) tea.Cmd {
	client := m.client
	return func() tea.Msg {
		return killSwitchFlushed{err: client.FlushKillSwitch()}
	}
}

func testKernelCmd(m *Model) tea.Cmd {
	client := m.client
	return func() tea.Msg {
		trials, err := client.TestKernel()
		return kernelTestResult{trials: trials, err: err}
	}
}

// mtuSizes are the sizes worth trying, in the order the lever walks them: auto
// first, then from the smallest that carries IPv6 up to the largest value any
// encapsulation can put on an Ethernet path. ±10 steps made reaching 1452 a
// seventeen-press chore; the exact value is still available by typing it.
var mtuSizes = []int{0, 1280, 1300, 1360, 1380, 1400, 1420, 1440, 1452}

// cycleMTU moves one step through mtuSizes: up to the next size, down to the
// previous one. A value the user typed that is not in the list keeps its place
// between the two sizes around it, which is why this compares values instead of
// indexes.
func cycleMTU(current, delta int) int {
	if delta > 0 {
		for _, v := range mtuSizes {
			if v > current {
				return v
			}
		}
		return mtuSizes[0]
	}
	for i := len(mtuSizes) - 1; i >= 0; i-- {
		if mtuSizes[i] < current {
			return mtuSizes[i]
		}
	}
	return mtuSizes[len(mtuSizes)-1]
}

// buildSettingsRows lays out every lever. Order groups them by what they touch,
// not by how advanced they are.
func buildSettingsRows() []formRow {
	rows := []formRow{
		{label: "Network", kind: rowHeader},
		{
			label: "TUN stack",
			kind:  rowChoice,
			value: func(m *Model) string { return m.styles.Value.Render(m.cfg.TUNStack) },
			note:  func(m *Model) string { return stackNote(m.cfg.TUNStack) },
			adjust: func(m *Model, d int) {
				cycleChoice(&m.cfg.TUNStack, config.TUNStacks, d)
				m.applySettings()
			},
		},
		{
			label: "MTU",
			kind:  rowNumber,
			value: func(m *Model) string {
				if m.cfg.MTU == 0 {
					return m.styles.Dim.Render("auto")
				}
				return m.styles.Value.Render(fmt.Sprintf("%d", m.cfg.MTU))
			},
			note: func(*Model) string { return "h/l any size · enter to type an exact one" },
			adjust: func(m *Model, d int) {
				m.cfg.MTU = cycleMTU(m.cfg.MTU, d)
				m.applySettings()
			},
			text: func(m *Model) string {
				if m.cfg.MTU == 0 {
					return "0"
				}
				return strconv.Itoa(m.cfg.MTU)
			},
			commit: func(m *Model, raw string) (string, error) {
				v, err := strconv.Atoi(strings.TrimSpace(raw))
				if err != nil {
					return "", fmt.Errorf("mtu: %q is not a number", raw)
				}
				if v != 0 && (v < 576 || v > 9000) {
					return "", fmt.Errorf("mtu: %d is outside 576..9000 (0 = auto)", v)
				}
				m.cfg.MTU = v
				m.applySettings()
				return "mtu: " + mtuLabel(v), nil
			},
		},
		{
			label: "Auto-detect MTU",
			kind:  rowAction,
			value: func(m *Model) string { return m.styles.Dim.Render("probe path mtu") },
			run:   probeMTUCmd,
		},
		{
			label: "Multi-queue",
			kind:  rowToggle,
			value: toggleValue(func(m *Model) bool { return m.cfg.MultiQueue }),
			note: func(m *Model) string {
				if m.cfg.TUNStack != config.TUNStackSingTun {
					return "needs the sing-tun stack"
				}
				return "linux, scales with cores"
			},
			adjust: func(m *Model, _ int) {
				m.cfg.MultiQueue = !m.cfg.MultiQueue
				m.applySettings()
			},
		},
		{
			label: "Auto redirect",
			kind:  rowToggle,
			value: toggleValue(func(m *Model) bool { return m.cfg.AutoRedirect }),
			note: func(*Model) string {
				return "claims traffic that bypasses the TUN · catches a resolver stub on the loopback"
			},
			adjust: func(m *Model, _ int) {
				m.cfg.AutoRedirect = !m.cfg.AutoRedirect
				m.applySettings()
			},
		},

		{label: "DNS", kind: rowHeader},
		{
			label: "Mode",
			kind:  rowChoice,
			value: func(m *Model) string { return m.styles.Value.Render(m.cfg.DNS.Mode) },
			adjust: func(m *Model, d int) {
				cycleChoice(&m.cfg.DNS.Mode, config.DNSModes, d)
				m.applySettings()
			},
		},
		{
			label: "Preset",
			kind:  rowChoice,
			value: func(m *Model) string {
				return m.styles.Value.Render(config.MatchDNSPreset(m.cfg.DNS.Servers))
			},
			adjust: func(m *Model, d int) {
				name := nextDNSPreset(config.MatchDNSPreset(m.cfg.DNS.Servers), d)
				if servers := config.DNSServersFor(name, m.cfg.DNS.UseIPv6); len(servers) > 0 {
					m.cfg.DNS.Servers = servers
				}
				m.applySettings()
			},
		},
		{
			label: "Include IPv6",
			kind:  rowToggle,
			value: toggleValue(func(m *Model) bool { return m.cfg.DNS.UseIPv6 }),
			adjust: func(m *Model, _ int) {
				m.cfg.DNS.UseIPv6 = !m.cfg.DNS.UseIPv6
				if m.cfg.DNS.UseIPv6 {
					if servers := config.DNSServersFor(config.MatchDNSPreset(m.cfg.DNS.Servers), true); len(servers) > 0 {
						m.cfg.DNS.Servers = servers
					}
				} else {
					m.cfg.DNS.Servers = config.OnlyIPv4(m.cfg.DNS.Servers)
				}
				m.applySettings()
			},
		},
		{
			label: "Servers",
			kind:  rowText,
			value: func(m *Model) string { return m.styles.Value.Render(strings.Join(m.cfg.DNS.Servers, ", ")) },
			text:  func(m *Model) string { return strings.Join(m.cfg.DNS.Servers, ", ") },
			commit: func(m *Model, raw string) (string, error) {
				servers := splitList(raw)
				if len(servers) == 0 {
					return "", fmt.Errorf("dns: empty server list")
				}
				expanded := make([]string, 0, len(servers))
				for _, srv := range servers {
					// A preset name typed here means that preset, not a host name.
					if preset := config.DNSServersFor(strings.ToLower(srv), m.cfg.DNS.UseIPv6); len(preset) > 0 {
						expanded = append(expanded, preset...)
						continue
					}
					if err := config.ValidateServerAddress(srv); err != nil {
						return "", err
					}
					expanded = append(expanded, srv)
				}
				m.cfg.DNS.Servers = expanded
				m.applySettings()
				return "dns: " + strings.Join(m.cfg.DNS.Servers, ", "), nil
			},
		},
		{
			label: "On network change",
			kind:  rowChoice,
			value: func(m *Model) string { return m.styles.Value.Render(m.cfg.DNS.OnNetworkChange) },
			adjust: func(m *Model, d int) {
				cycleChoice(&m.cfg.DNS.OnNetworkChange, config.NetworkChangePolicies, d)
				m.applySettings()
			},
		},

		{label: "DIRECT (bypass tunnel)", kind: rowHeader},
		listRow("IPs", "prefix or address, e.g. 10.0.0.0/8",
			func(m *Model) []string { return m.cfg.Bypass.IPs },
			func(m *Model, v []string) { m.cfg.Bypass.IPs = v },
			validatePrefixes),
		listRow("Sites", "example.com or *keyword*",
			func(m *Model) []string { return m.cfg.Bypass.Domains },
			func(m *Model, v []string) { m.cfg.Bypass.Domains = v },
			validateDomains),
		listRow("Processes", "part of the exe path, e.g. steam",
			func(m *Model) []string { return m.cfg.Bypass.Processes },
			func(m *Model, v []string) { m.cfg.Bypass.Processes = v },
			nil),
	}
	rows = append(rows, buildSettingsRowsTail()...)
	return rows
}
