package tui

import (
	"strings"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
)

func findRow(t *testing.T, label string) formRow {
	t.Helper()
	for _, r := range buildSettingsRows() {
		if r.label == label {
			return r
		}
	}
	t.Fatalf("no row %q", label)
	return formRow{}
}

// The preset lever must walk every set in the table and keep both families.
func TestDNSPresetRowCycles(t *testing.T) {
	m := newTestModel(t)
	row := findRow(t, "Preset")
	if got := config.MatchDNSPreset(m.cfg.DNS.Servers); got != "cloudflare" {
		t.Fatalf("default preset = %q", got)
	}

	seen := map[string]bool{}
	for i := 0; i < len(config.DNSPresets); i++ {
		row.adjust(m, 1)
		name := config.MatchDNSPreset(m.cfg.DNS.Servers)
		if name == "custom" {
			t.Fatalf("step %d produced a custom list: %v", i, m.cfg.DNS.Servers)
		}
		seen[name] = true
		want := 0
		for _, p := range config.DNSPresets {
			if p.Name == name {
				want = len(p.V4) + len(p.V6)
			}
		}
		if len(m.cfg.DNS.Servers) != want {
			t.Fatalf("%s has %d servers, want %d", name, len(m.cfg.DNS.Servers), want)
		}
	}
	if len(seen) != len(config.DNSPresets) {
		t.Fatalf("visited %d of %d presets", len(seen), len(config.DNSPresets))
	}

	// Forward then back: the lever is reversible.
	row.adjust(m, 1)
	if got := config.MatchDNSPreset(m.cfg.DNS.Servers); got != "google" {
		t.Fatalf("forward step = %q", got)
	}
	row.adjust(m, -1)
	if got := config.MatchDNSPreset(m.cfg.DNS.Servers); got != "cloudflare" {
		t.Fatalf("backwards step = %q", got)
	}
	if !strings.Contains(row.value(m), "cloudflare") {
		t.Fatalf("value does not show the preset: %q", row.value(m))
	}
}

// Turning IPv6 off strips the v6 resolvers; turning it back on restores them.
func TestDNSIPv6RowTogglesFamilies(t *testing.T) {
	m := newTestModel(t)
	row := findRow(t, "Include IPv6")

	row.adjust(m, 0)
	if m.cfg.DNS.UseIPv6 {
		t.Fatal("IPv6 still on")
	}
	for _, s := range m.cfg.DNS.Servers {
		if strings.Contains(s, ":") {
			t.Fatalf("IPv6 resolver kept while off: %v", m.cfg.DNS.Servers)
		}
	}
	if len(m.cfg.DNS.Servers) != 2 {
		t.Fatalf("servers after turning IPv6 off: %v", m.cfg.DNS.Servers)
	}

	row.adjust(m, 0)
	if !m.cfg.DNS.UseIPv6 {
		t.Fatal("IPv6 still off")
	}
	if got := config.MatchDNSPreset(m.cfg.DNS.Servers); got != "cloudflare" {
		t.Fatalf("preset after turning IPv6 on = %q", got)
	}
	if len(m.cfg.DNS.Servers) != 4 {
		t.Fatalf("servers after turning IPv6 on: %v", m.cfg.DNS.Servers)
	}
}

// The stack row names the library and what each stack does; the default is
// sing-tun's own stack, written as an absent field.
func TestTUNStackRowExplainsStacks(t *testing.T) {
	m := newTestModel(t)
	row := findRow(t, "TUN stack")
	if m.cfg.TUNStack != config.TUNStackSingTun {
		t.Fatalf("default stack = %q, want %q", m.cfg.TUNStack, config.TUNStackSingTun)
	}
	for stack, want := range map[string]string{
		config.TUNStackSingTun: "sing-tun own stack",
		"mixed":                "kernel TCP, gvisor UDP",
		"gvisor":               "userspace TCP and UDP",
		"system":               "kernel TCP and UDP",
	} {
		m.cfg.TUNStack = stack
		if note := row.note(m); !strings.Contains(note, want) {
			t.Fatalf("%s note = %q, want %q", stack, note, want)
		}
	}
}

// Multi-queue belongs to sing-tun's own stack: the toggle works everywhere, the
// note says so, and the row is what turns the lever.
func TestMultiQueueRow(t *testing.T) {
	m := newTestModel(t)
	row := findRow(t, "Multi-queue")
	if m.cfg.MultiQueue {
		t.Fatal("multi-queue must start off")
	}
	if note := row.note(m); !strings.Contains(note, "scales with cores") {
		t.Fatalf("note with the sing-tun stack = %q", note)
	}
	row.adjust(m, 1)
	if !m.cfg.MultiQueue {
		t.Fatal("toggle did not turn multi-queue on")
	}
	m.cfg.TUNStack = "mixed"
	if note := row.note(m); !strings.Contains(note, "needs the sing-tun stack") {
		t.Fatalf("note with another stack = %q", note)
	}
}

// A preset name typed into the address list means that preset. A name the core
// cannot dial is refused before it becomes a start failure.
func TestDNSServersRowAcceptsPresetNameAndRefusesHostnames(t *testing.T) {
	m := newTestModel(t)
	row := findRow(t, "Servers")

	if _, err := row.commit(m, "cloudflare"); err != nil {
		t.Fatalf("preset name rejected: %v", err)
	}
	if got := config.MatchDNSPreset(m.cfg.DNS.Servers); got != "cloudflare" {
		t.Fatalf("servers = %v", m.cfg.DNS.Servers)
	}

	before := append([]string(nil), m.cfg.DNS.Servers...)
	for _, bad := range []string{"dns.google", "cloudflare.example.net"} {
		if _, err := row.commit(m, bad); err == nil {
			t.Fatalf("%q accepted", bad)
		}
	}
	if len(m.cfg.DNS.Servers) != len(before) {
		t.Fatalf("a refused edit must not change the list: %v", m.cfg.DNS.Servers)
	}

	if _, err := row.commit(m, "9.9.9.9, [2620:fe::fe]:53"); err != nil {
		t.Fatalf("addresses rejected: %v", err)
	}
	if len(m.cfg.DNS.Servers) != 2 {
		t.Fatalf("servers = %v", m.cfg.DNS.Servers)
	}
}

// A hand-written list is "custom" and is left alone by the family toggle.
func TestDNSCustomListSurvivesIPv6Toggle(t *testing.T) {
	m := newTestModel(t)
	m.cfg.DNS.Servers = []string{"10.0.0.53"}
	row := findRow(t, "Include IPv6")
	row.adjust(m, 0)
	row.adjust(m, 0)
	if len(m.cfg.DNS.Servers) != 1 || m.cfg.DNS.Servers[0] != "10.0.0.53" {
		t.Fatalf("servers = %v", m.cfg.DNS.Servers)
	}
	if got := config.MatchDNSPreset(m.cfg.DNS.Servers); got != "custom" {
		t.Fatalf("preset = %q", got)
	}
}

func TestNextDNSPresetFromCustom(t *testing.T) {
	if got := nextDNSPreset("custom", 1); got != config.DNSPresets[0].Name {
		t.Fatalf("custom +1 = %q", got)
	}
	if got := nextDNSPreset("custom", -1); got != config.DNSPresets[len(config.DNSPresets)-1].Name {
		t.Fatalf("custom -1 = %q", got)
	}
}
