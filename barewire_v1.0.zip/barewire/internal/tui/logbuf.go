package tui

import (
	"strings"

	"github.com/charmbracelet/x/ansi"

	"github.com/mrazowner/barewire/internal/proto"
)

// LogBuffer is a fixed-capacity ring of log entries. A long-running session
// must not grow without bound, and losing the oldest lines is preferable to
// losing the newest ones.
type LogBuffer struct {
	buf   []proto.LogEntry
	start int
	count int
}

// NewLogBuffer creates a buffer holding at most capacity entries.
func NewLogBuffer(capacity int) *LogBuffer {
	if capacity < 1 {
		capacity = 1
	}
	return &LogBuffer{buf: make([]proto.LogEntry, capacity)}
}

// Capacity is the number of entries the ring keeps.
func (b *LogBuffer) Capacity() int { return len(b.buf) }

// Len is the number of stored entries.
func (b *LogBuffer) Len() int { return b.count }

// Add appends an entry, dropping the oldest one when full.
func (b *LogBuffer) Add(e proto.LogEntry) {
	// One log entry is one line: a message carrying a newline would otherwise
	// add lines the renderer knows nothing about and break the screen geometry.
	// Escape sequences are stripped here as well, so an older host binary that
	// still sends coloured lines cannot garble the interface.
	e.Text = flatten(ansi.Strip(e.Text))
	e.Source = flatten(ansi.Strip(e.Source))
	if b.count < len(b.buf) {
		b.buf[(b.start+b.count)%len(b.buf)] = e
		b.count++
		return
	}
	b.buf[b.start] = e
	b.start = (b.start + 1) % len(b.buf)
}

// flatten folds a multi-line message into a single line.
func flatten(s string) string {
	if !strings.ContainsAny(s, "\r\n\t") {
		return s
	}
	s = strings.ReplaceAll(s, "\r", " ")
	s = strings.ReplaceAll(s, "\n", " ")
	s = strings.ReplaceAll(s, "\t", " ")
	return s
}

// At returns the i-th entry, oldest first.
func (b *LogBuffer) At(i int) proto.LogEntry {
	if i < 0 || i >= b.count {
		return proto.LogEntry{}
	}
	return b.buf[(b.start+i)%len(b.buf)]
}

// Entries returns a copy of the stored entries, oldest first.
func (b *LogBuffer) Entries() []proto.LogEntry {
	out := make([]proto.LogEntry, b.count)
	for i := 0; i < b.count; i++ {
		out[i] = b.At(i)
	}
	return out
}

// Clear drops every entry.
func (b *LogBuffer) Clear() {
	b.start = 0
	b.count = 0
}

// Filter keeps entries at or above min level whose text or source contains
// query (case-insensitive). An empty query disables the text filter.
func (b *LogBuffer) Filter(min proto.LogLevel, query string) []proto.LogEntry {
	q := strings.ToLower(strings.TrimSpace(query))
	out := make([]proto.LogEntry, 0, b.count)
	for i := 0; i < b.count; i++ {
		e := b.At(i)
		if e.Level.Rank() < min.Rank() {
			continue
		}
		if q != "" {
			haystack := strings.ToLower(e.Text + " " + e.Source)
			if !strings.Contains(haystack, q) {
				continue
			}
		}
		out = append(out, e)
	}
	return out
}
