// Package tui is the Barewire text interface. It shows facts, exposes levers
// and never decides anything on its own.
package tui

import (
	"fmt"
	"sync"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/hostclient"
	"github.com/mrazowner/barewire/internal/proto"
	"github.com/mrazowner/barewire/internal/version"
)

const logCapacity = 5000

// hostRestartLimit is how many times one session relaunches a host that went
// away. Beyond that the failure is not a hiccup, and another polkit prompt would
// only hide it.
const hostRestartLimit = 3

// hostStable is how long a host has to stay up before its relaunch budget is
// refilled: a crash every few hours is not a crash loop.
const hostStable = 5 * time.Minute

type tab int

const (
	tabStatus tab = iota
	tabSettings
	tabLogs
	tabSubscriptions
	tabProfiles
	tabCount
)

var tabTitles = [tabCount]string{"Status", "Settings", "Logs", "Subscriptions", "Profiles"}

// Hint is one key/action pair for the legend line.
type Hint struct {
	Key   string
	Label string
}

// screen is one tab body. Screens own their cursor and scroll state; the model
// owns everything that is a fact.
type screen interface {
	Resize(w, h int)
	Update(msg tea.Msg, m *Model) tea.Cmd
	Body(m *Model, w, h int) []string
	Hints() []Hint
	Capturing() bool
}

// Options is what the shell hands to New.
type Options struct {
	Client            hostclient.Client
	Settings          config.Settings
	SettingsPath      string
	ProfilesPath      string
	SubscriptionsPath string
	// HostNotice is a fact about the host connection to show in the log, for
	// example why the socket could not be dialled.
	HostNotice string
	// HostStarter starts the privileged host and returns a client for it. Nil
	// means this interface never starts a host on its own.
	HostStarter func() (hostclient.Client, error)
	// HostLogTail returns the last lines of the host's own log, so a host that
	// died says why instead of leaving the interface to guess.
	HostLogTail func() []string
	// SocketPath is shown as a fact while no host is running, so a path
	// mismatch is visible without opening the log.
	SocketPath string
}

// Model is the root tea.Model.
type Model struct {
	client hostclient.Client

	cfg      config.Settings
	cfgPath  string
	profPath string
	subPath  string

	status  proto.Status
	palette Palette
	styles  Styles
	logs    *LogBuffer

	w, h int
	tab  tab

	statusView   *statusScreen
	settingsView *settingsScreen
	logsView     *logsScreen
	subsView     *subsScreen
	profilesView *profilesScreen

	starter  func() (hostclient.Client, error)
	ownsHost bool
	socket   string
	// hostRestarts counts how many times this session had to launch the host
	// again after it went away. A bounded number keeps a host that cannot stay
	// up from turning into a polkit prompt every few seconds.
	hostRestarts int
	// hostLogTail reads the host's own log, for the moment the host is gone.
	hostLogTail func() []string

	// pending is what to do as soon as a launched host is available.
	pending     pendingAction
	pendingNode config.Node

	// applyCh carries settings changes to one worker goroutine, so a restart
	// never blocks the update loop and a held arrow key does not queue seventeen
	// restarts. prog is how the worker reports back.
	applyCh chan config.Settings
	progMu  sync.Mutex
	prog    *tea.Program

	quit bool
}

// pendingAction is a user command that needs a running host.
type pendingAction int

const (
	pendingNone pendingAction = iota
	pendingConnect
	pendingSelectNode
)

// New builds the interface.
func New(o Options) *Model {
	m := &Model{
		client:   o.Client,
		cfg:      o.Settings.Clone(),
		cfgPath:  o.SettingsPath,
		profPath: o.ProfilesPath,
		subPath:  o.SubscriptionsPath,
		logs:     NewLogBuffer(logCapacity),
		w:        100,
		h:        32,
	}
	m.palette = PaletteFrom(m.cfg)
	m.styles = m.palette.Styles()
	m.status = m.client.Snapshot()
	m.applyCh = make(chan config.Settings, 1)
	go m.runApplier()

	m.statusView = newStatusScreen()
	m.settingsView = newSettingsScreen()
	m.logsView = newLogsScreen()
	m.subsView = newSubsScreen(m.subPath)
	m.profilesView = newProfilesScreen(m.profPath, m.cfg)
	m.starter = o.HostStarter
	m.hostLogTail = o.HostLogTail
	m.socket = o.SocketPath
	m.resizeScreens()
	if o.HostNotice != "" {
		m.logf(proto.LevelWarn, "host: %s", o.HostNotice)
	}
	m.logf(proto.LevelInfo, "barewire %s", version.String())
	return m
}

// Init implements tea.Model.
func (m *Model) Init() tea.Cmd {
	return m.waitEvent()
}

type eventMsg struct{ ev proto.Event }

// settingsAppliedMsg is the worker's report: the apply finished, or it failed.
type settingsAppliedMsg struct{ err error }
type eventClosedMsg struct{}

// hostStartedMsg carries the result of launching the privileged host.
type hostStartedMsg struct {
	client hostclient.Client
	err    error
}

func (m *Model) waitEvent() tea.Cmd {
	ch := m.client.Events()
	return func() tea.Msg {
		ev, ok := <-ch
		if !ok {
			return eventClosedMsg{}
		}
		return eventMsg{ev: ev}
	}
}

// screen returns the screen for a tab.
func (m *Model) screen(t tab) screen {
	switch t {
	case tabStatus:
		return m.statusView
	case tabSettings:
		return m.settingsView
	case tabLogs:
		return m.logsView
	case tabSubscriptions:
		return m.subsView
	default:
		return m.profilesView
	}
}

func (m *Model) resizeScreens() {
	bodyW, bodyH := m.bodySize()
	for t := tab(0); t < tabCount; t++ {
		m.screen(t).Resize(bodyW-2, bodyH-2)
	}
}

func (m *Model) bodySize() (int, int) {
	h := m.h - 5
	if h < 3 {
		h = 3
	}
	return m.w, h
}

func (m *Model) switchTab(t tab) {
	if t < 0 || t >= tabCount {
		return
	}
	m.tab = t
	// The settings screen writes the active profile on every change, so the list
	// has to be re-read when it comes into view instead of showing the snapshot
	// taken at startup.
	if t == tabProfiles && m.profilesView != nil {
		m.profilesView.Refresh(m.cfg)
	}
}

// applySettings pushes the whole lever set to the host and to disk. It is called
// on every change: the interface never waits for an "apply" button.
//
// The active profile is written too. Before this, a change went to settings.json
// only: the profile kept its old values, and activating it again silently undid
// the work — which is exactly what "the profiles are a mess" felt like. Now the
// profile you are editing follows you.
func (m *Model) applySettings() {
	m.cfg.Normalize()
	m.palette = PaletteFrom(m.cfg)
	m.styles = m.palette.Styles()
	if err := config.SaveSettings(m.cfgPath, m.cfg); err != nil {
		m.logf(proto.LevelError, "settings: %v", err)
	}
	if m.profPath != "" && m.cfg.Profile != "" {
		if err := config.SaveProfileInto(m.profPath, m.cfg.Profile, m.cfg); err != nil {
			m.logf(proto.LevelError, "profile %s: %v", m.cfg.Profile, err)
		}
	}
	m.queueApply(m.cfg.Clone())
}

// SetProgram is called once before Run so that the apply worker can report back
// through the program instead of touching the model from another goroutine.
func (m *Model) SetProgram(p *tea.Program) {
	m.progMu.Lock()
	m.prog = p
	m.progMu.Unlock()
}

// runApplier is the single goroutine that talks to the host about settings. It
// runs one apply at a time, in order, off the update loop.
func (m *Model) runApplier() {
	for s := range m.applyCh {
		err := m.client.Apply(s)
		m.progMu.Lock()
		p := m.prog
		m.progMu.Unlock()
		if p != nil {
			p.Send(settingsAppliedMsg{err: err})
		}
	}
}

// queueApply hands the settings to the worker. When one change is already waiting
// it is replaced: only the newest lever set matters, and a held arrow key must
// not restart the core once per step.
func (m *Model) queueApply(s config.Settings) {
	select {
	case m.applyCh <- s:
		return
	default:
	}
	select {
	case <-m.applyCh:
	default:
	}
	select {
	case m.applyCh <- s:
	default:
	}
}

// logf adds a line to the log buffer as a fact, not as a notification.
func (m *Model) logf(level proto.LogLevel, format string, args ...any) {
	m.logs.Add(proto.LogEntry{
		Time:   time.Now(),
		Level:  level,
		Source: "tui",
		Text:   fmt.Sprintf(format, args...),
	})
}

func (m *Model) connect() tea.Cmd {
	if !m.status.HostRunning {
		if m.starter == nil {
			m.logf(proto.LevelError, "host: not running, connect refused")
			return nil
		}
		m.pending = pendingConnect
		return m.startHost()
	}
	if err := m.client.Connect(); err != nil {
		m.logf(proto.LevelError, "%v", err)
	}
	return nil
}

// selectNode makes a node active. A node is only useful with a host, so the host
// is started when it is missing: the key press is the command either way.
func (m *Model) selectNode(node config.Node) tea.Cmd {
	if !m.status.HostRunning {
		if m.starter == nil {
			m.logf(proto.LevelError, "host: not running, node not selected")
			return nil
		}
		m.pending = pendingSelectNode
		m.pendingNode = node
		return m.startHost()
	}
	if err := m.client.SelectNode(node); err != nil {
		m.logf(proto.LevelError, "%v", err)
		return nil
	}
	m.logf(proto.LevelInfo, "node selected: %s", node.Name)
	return nil
}

// startHost launches the privileged host in the background: the interface stays
// responsive while the authorisation dialog is open.
func (m *Model) startHost() tea.Cmd {
	m.logf(proto.LevelInfo, "host: starting barewire-host, authorisation may be asked")
	starter := m.starter
	return func() tea.Msg {
		client, err := starter()
		return hostStartedMsg{client: client, err: err}
	}
}

// ShutdownHost stops the host when this interface started it. It is called after
// the program exits: a host must not outlive the interface that launched it.
func (m *Model) ShutdownHost() {
	if !m.ownsHost || m.client == nil {
		return
	}
	if stopper, ok := m.client.(interface{ Shutdown() error }); ok {
		_ = stopper.Shutdown()
	}
}

func (m *Model) disconnect() tea.Cmd {
	if !m.status.HostRunning {
		m.logf(proto.LevelError, "host: not running, disconnect refused")
		return nil
	}
	if err := m.client.Disconnect(); err != nil {
		m.logf(proto.LevelError, "%v", err)
	}
	return nil
}
