// Package hostclient is the seam between the TUI and whatever supplies the
// facts. There are two implementations: the mock (this build) and the unix
// socket client for barewire-host.
package hostclient

import (
	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
)

// Client is everything the interface needs from the host. It is deliberately
// small: anything the user cannot act on does not belong here.
type Client interface {
	// Snapshot returns the current facts. It must be safe to call at any time,
	// including when no host process is running.
	Snapshot() proto.Status

	// Events streams status, log and sample events. The channel is closed when
	// the host goes away, which is itself a fact the interface shows.
	Events() <-chan proto.Event

	// Connect starts the link with the currently selected node.
	Connect() error

	// Disconnect stops the link. It is never called implicitly.
	Disconnect() error

	// Apply hands the complete lever set to the host. The host rebuilds its
	// configuration and reports the result as events.
	Apply(config.Settings) error

	// SelectNode makes the node the active one.
	SelectNode(config.Node) error

	// FlushKillSwitch removes the nftables ruleset.
	FlushKillSwitch() error

	// AutoMTU probes the path MTU and returns the value it measured.
	AutoMTU() (int, error)

	// AutoBrutal runs a short throughput test and returns up/down in Mbps.
	AutoBrutal() (up, down int, err error)

	// TestKernel measures every congestion control the machine offers on the
	// live path and returns the trials. It takes minutes by design.
	TestKernel() ([]proto.KernelTrial, error)

	// Connections returns the live connection table.
	Connections() []proto.Connection

	// Close releases resources owned by the client.
	Close() error
}
