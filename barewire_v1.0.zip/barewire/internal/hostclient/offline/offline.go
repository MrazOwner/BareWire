// Package offline is the client used when no host process is running. It does
// not pretend: the status says the host is not running, connect is refused, and
// the levers are whatever the interface wrote to disk.
package offline

import (
	"errors"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/hostclient"
	"github.com/mrazowner/barewire/internal/proto"
)

// ErrNotRunning is returned by every action that needs a live host.
var ErrNotRunning = errors.New("host: not running")

// Client implements hostclient.Client without a host.
type Client struct {
	events chan proto.Event
}

// The interface is the contract the screens rely on; a compile-time assertion
// means a signature change breaks the build here, not at runtime.
var _ hostclient.Client = (*Client)(nil)

// New creates the offline client.
func New() *Client {
	// The channel is never written to and never closed: an absent host has no
	// events, and a closed stream would read as a crash.
	return &Client{events: make(chan proto.Event)}
}

// Snapshot implements hostclient.Client.
func (c *Client) Snapshot() proto.Status {
	return proto.Status{HostRunning: false, State: proto.LinkDisconnected}
}

// Events implements hostclient.Client.
func (c *Client) Events() <-chan proto.Event { return c.events }

// Connect implements hostclient.Client.
func (c *Client) Connect() error { return ErrNotRunning }

// Disconnect implements hostclient.Client: with no host there is no link to stop.
func (c *Client) Disconnect() error { return nil }

// Apply implements hostclient.Client. The interface writes settings to disk
// itself; a host started later reads them, so there is nothing to send now.
func (c *Client) Apply(config.Settings) error { return nil }

// SelectNode implements hostclient.Client.
func (c *Client) SelectNode(config.Node) error { return ErrNotRunning }

// FlushKillSwitch implements hostclient.Client.
func (c *Client) FlushKillSwitch() error { return ErrNotRunning }

// AutoMTU implements hostclient.Client.
func (c *Client) AutoMTU() (int, error) { return 0, ErrNotRunning }

// AutoBrutal implements hostclient.Client.
func (c *Client) AutoBrutal() (int, int, error) { return 0, 0, ErrNotRunning }

// TestKernel implements hostclient.Client: measuring a path needs a host.
func (c *Client) TestKernel() ([]proto.KernelTrial, error) { return nil, ErrNotRunning }

// Connections implements hostclient.Client.
func (c *Client) Connections() []proto.Connection { return nil }

// Close implements hostclient.Client.
func (c *Client) Close() error { return nil }
