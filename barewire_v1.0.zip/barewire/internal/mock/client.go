// Package mock is a stand-in for barewire-host. It lets the interface be driven
// without a TUN device, root or a real network path, and it produces the same
// events the socket client will produce later.
package mock

import (
	"errors"
	"fmt"
	"math/rand"
	"sync"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/hostclient"
	"github.com/mrazowner/barewire/internal/proto"
)

const eventBuffer = 256

// Client simulates the host.
type Client struct {
	mu       sync.Mutex
	st       proto.Status
	settings config.Settings
	subs     []chan proto.Event
	rnd      *rand.Rand
	up, down float64
	closed   bool
	done     chan struct{}
	wg       sync.WaitGroup
}

var _ hostclient.Client = (*Client)(nil)

// New starts the simulated host.
func New() *Client {
	c := &Client{
		rnd:      rand.New(rand.NewSource(time.Now().UnixNano())),
		done:     make(chan struct{}),
		settings: config.Defaults(),
	}
	c.st = proto.Status{
		HostRunning: true,
		HostVersion: "0.1.0-mock",
		CoreVersion: "sing-box 1.12.0-mock",
		State:       proto.LinkDisconnected,
		TUNStack:    c.settings.TUNStack,
		MTU:         1420,
		MTUSource:   "auto",
		Congestion:  "cubic",
		Qdisc:       "fq_codel",
		CCOptions:   config.KernelCongestions,
		DNS: proto.DNS{
			Mode:    c.settings.DNS.Mode,
			Servers: append([]string(nil), c.settings.DNS.Servers...),
		},
		KillSwitch: proto.KillSwitch{
			OnCrash:         c.settings.KillSwitch.OnCrash,
			OnNetworkChange: c.settings.KillSwitch.OnNetworkChange,
		},
		MemRSSKB:   42000,
		CPUPercent: 0.7,
	}
	c.wg.Add(2)
	go c.ticker()
	go c.backlog()
	return c
}

// Snapshot implements hostclient.Client.
func (c *Client) Snapshot() proto.Status {
	c.mu.Lock()
	defer c.mu.Unlock()
	return cloneStatus(c.st)
}

// Events implements hostclient.Client.
func (c *Client) Events() <-chan proto.Event {
	ch := make(chan proto.Event, eventBuffer)
	c.mu.Lock()
	if c.closed {
		close(ch)
	} else {
		c.subs = append(c.subs, ch)
	}
	c.mu.Unlock()
	return ch
}

// Connect implements hostclient.Client.
func (c *Client) Connect() error {
	c.mu.Lock()
	if c.st.State == proto.LinkConnected || c.st.State == proto.LinkConnecting {
		c.mu.Unlock()
		return nil
	}
	c.st.State = proto.LinkConnecting
	c.mu.Unlock()

	c.emitStatus()
	c.emitLog(proto.LevelInfo, "host", "link: connecting")
	time.AfterFunc(700*time.Millisecond, c.finishConnect)
	return nil
}

func (c *Client) finishConnect() {
	c.mu.Lock()
	if c.st.State != proto.LinkConnecting {
		c.mu.Unlock()
		return
	}
	if c.st.Server == "" {
		c.st.Server = "de1.example.net:443"
		c.st.Protocol = "vless"
		c.st.Outbound = "proxy[vless-de1]"
		c.st.Rule = "final"
	}
	c.st.State = proto.LinkConnected
	c.st.Since = time.Now()
	c.st.MTUSource = mtuSource(c.settings.MTU)
	stack, mtu, server := c.st.TUNStack, c.st.MTU, c.st.Server
	c.mu.Unlock()

	c.emitStatus()
	c.emitLog(proto.LevelInfo, "tun", fmt.Sprintf("%s stack started, mtu %d", stack, mtu))
	c.emitLog(proto.LevelInfo, "outbound/vless", "connected to "+server)
}

// Disconnect implements hostclient.Client.
func (c *Client) Disconnect() error {
	c.mu.Lock()
	if c.st.State == proto.LinkDisconnected || c.st.State == proto.LinkStopping {
		c.mu.Unlock()
		return nil
	}
	c.st.State = proto.LinkStopping
	c.mu.Unlock()
	c.emitStatus()

	time.AfterFunc(220*time.Millisecond, func() {
		c.mu.Lock()
		if c.st.State != proto.LinkStopping {
			c.mu.Unlock()
			return
		}
		c.st.State = proto.LinkDisconnected
		c.st.LastDisconnect = "user request"
		c.st.LastDisconnectAt = time.Now()
		c.st.UpBps, c.st.DownBps = 0, 0
		c.st.Connections = 0
		c.up, c.down = 0, 0
		c.mu.Unlock()
		c.emitStatus()
		c.emitLog(proto.LevelInfo, "host", "link: disconnected (user request)")
	})
	return nil
}

// Apply implements hostclient.Client.
func (c *Client) Apply(s config.Settings) error {
	s.Normalize()
	start := time.Now()
	c.mu.Lock()
	c.settings = s
	c.st.Profile = s.Profile
	c.st.TUNStack = s.TUNStack
	if s.MTU == 0 {
		c.st.MTUSource = "auto"
	} else {
		c.st.MTU = s.MTU
		c.st.MTUSource = "manual"
	}
	c.st.Smux = proto.Smux{Enabled: s.Smux.Enabled, Protocol: s.Smux.Protocol, Padding: s.Smux.Padding}
	c.st.Brutal = proto.Brutal{Enabled: s.Brutal.Enabled, UpMbps: s.Brutal.UpMbps, DownMbps: s.Brutal.DownMbps}
	c.st.DNS = proto.DNS{Mode: s.DNS.Mode, Servers: append([]string(nil), s.DNS.Servers...)}
	c.st.KillSwitch.Enabled = s.KillSwitch.Enabled
	c.st.KillSwitch.OnCrash = s.KillSwitch.OnCrash
	c.st.KillSwitch.OnNetworkChange = s.KillSwitch.OnNetworkChange
	if s.KillSwitch.Enabled {
		c.st.KillSwitch.Active = true
		c.st.KillSwitch.RulesetVersion++
	}
	if s.Kernel.Empty() {
		c.st.Congestion = "cubic"
		c.st.Qdisc = "fq_codel"
	} else {
		if s.Kernel.Congestion != "" {
			c.st.Congestion = s.Kernel.Congestion
		}
		if s.Kernel.Qdisc != "" {
			c.st.Qdisc = s.Kernel.Qdisc
		}
	}
	took := time.Since(start)
	c.mu.Unlock()

	c.emitStatus()
	c.emitLog(proto.LevelInfo, "host", fmt.Sprintf("config applied in %dms", took.Milliseconds()+3))
	return nil
}

// SelectNode implements hostclient.Client.
func (c *Client) SelectNode(n config.Node) error {
	c.mu.Lock()
	c.st.Server = n.Endpoint()
	c.st.Protocol = n.Kind
	c.st.Outbound = fmt.Sprintf("proxy[%s]", n.Name)
	c.st.Rule = "final"
	c.mu.Unlock()
	c.emitStatus()
	c.emitLog(proto.LevelInfo, "router", fmt.Sprintf("node selected: %s (%s)", n.Name, n.Endpoint()))
	return nil
}

// FlushKillSwitch implements hostclient.Client.
func (c *Client) FlushKillSwitch() error {
	c.mu.Lock()
	c.st.KillSwitch.Active = false
	version := c.st.KillSwitch.RulesetVersion
	c.mu.Unlock()
	c.emitStatus()
	c.emitLog(proto.LevelInfo, "nftables", fmt.Sprintf("ruleset v%d flushed", version))
	return nil
}

// AutoMTU implements hostclient.Client.
func (c *Client) AutoMTU() (int, error) {
	time.Sleep(250 * time.Millisecond)
	c.mu.Lock()
	probes := []int{1400, 1420, 1440, 1380}
	mtu := probes[c.rnd.Intn(len(probes))]
	c.settings.MTU = mtu
	c.st.MTU = mtu
	c.st.MTUSource = "auto"
	c.mu.Unlock()
	c.emitStatus()
	c.emitLog(proto.LevelInfo, "tun", fmt.Sprintf("mtu probe: 4 probes, best %d", mtu))
	return mtu, nil
}

// AutoBrutal implements hostclient.Client.
func (c *Client) AutoBrutal() (int, int, error) {
	time.Sleep(400 * time.Millisecond)
	c.mu.Lock()
	up := 40 + c.rnd.Intn(31)
	down := 150 + c.rnd.Intn(151)
	c.mu.Unlock()
	c.emitLog(proto.LevelInfo, "brutal", fmt.Sprintf("throughput probe: up %d Mbps, down %d Mbps", up, down))
	return up, down, nil
}

// TestKernel implements hostclient.Client. The mock answers with a fixed table:
// the interface only needs to know how to show a result, not how to produce one.
func (c *Client) TestKernel() ([]proto.KernelTrial, error) {
	c.mu.Lock()
	state := c.st.State
	c.mu.Unlock()
	if state != proto.LinkConnected {
		return nil, errors.New("kernel test: connect first")
	}
	trials := []proto.KernelTrial{
		{Algorithm: "bbr", DownMbps: 412, RTTMinMs: 24, RTTP95Ms: 31, Score: 319},
		{Algorithm: "cubic", DownMbps: 388, RTTMinMs: 24, RTTP95Ms: 58, Score: 161},
		{Algorithm: "vegas", DownMbps: 96, RTTMinMs: 24, RTTP95Ms: 25, Score: 92},
	}
	c.mu.Lock()
	c.st.KernelBest = "bbr"
	c.mu.Unlock()
	c.emitLog(proto.LevelInfo, "host", "kernel test: best for this server is bbr")
	c.emitStatus()
	return trials, nil
}

// Connections implements hostclient.Client.
func (c *Client) Connections() []proto.Connection {
	c.mu.Lock()
	connected := c.st.State == proto.LinkConnected
	outbound := c.st.Outbound
	c.mu.Unlock()
	if !connected {
		return nil
	}
	hosts := []string{
		"cp.cloudflare.com:443", "github.com:443", "cdn.jsdelivr.net:443",
		"registry.npmjs.org:443", "api.telegram.org:443", "1.1.1.1:53",
		"push.example.org:5228", "fonts.gstatic.com:443",
	}
	rules := []string{"final", "geosite:geolocation-!cn", "geoip:private", "domain-suffix:example.org"}
	network := []string{"tcp", "udp"}
	out := make([]proto.Connection, 0, len(hosts))
	for i := range hosts {
		out = append(out, proto.Connection{
			ID:       uint64(i + 1),
			Outbound: outbound,
			Rule:     rules[i%len(rules)],
			Host:     hosts[i],
			Network:  network[i%len(network)],
			Since:    time.Now().Add(-time.Duration(5+i*13) * time.Second),
			Up:       uint64(i+1) * 913,
			Down:     uint64(i+1) * 71422,
		})
	}
	return out
}

// Close implements hostclient.Client.
func (c *Client) Close() error {
	c.mu.Lock()
	if c.closed {
		c.mu.Unlock()
		return nil
	}
	c.closed = true
	subs := c.subs
	c.subs = nil
	c.mu.Unlock()

	close(c.done)
	c.wg.Wait()
	for _, ch := range subs {
		close(ch)
	}
	return nil
}
