package mock

import (
	"math/rand"
	"time"

	"github.com/mrazowner/barewire/internal/proto"
)

// drift moves a rate by a small random step and keeps it inside [lo, hi].
func drift(r *rand.Rand, cur, lo, hi float64) float64 {
	span := (hi - lo) * 0.12
	next := cur + (r.Float64()*2-1)*span
	if next < lo {
		next = lo + r.Float64()*span
	}
	if next > hi {
		next = hi - r.Float64()*span
	}
	return next
}

var logPool = []struct {
	level proto.LogLevel
	src   string
	text  string
}{
	{proto.LevelInfo, "router", "match[geosite:geolocation-!cn] => proxy[vless-de1]"},
	{proto.LevelInfo, "router", "match[geoip:private] => direct"},
	{proto.LevelInfo, "outbound/vless", "connection to cp.cloudflare.com:443"},
	{proto.LevelInfo, "outbound/vless", "connection to github.com:443"},
	{proto.LevelInfo, "dns", "fakeip: example.org -> 198.18.0.7"},
	{proto.LevelWarn, "outbound/vless", "connection reset by peer, retrying"},
	{proto.LevelDebug, "tun", "gvisor: gso disabled, mtu 1420"},
	{proto.LevelError, "dns", "lookup telemetry.invalid: no such host"},
}

func (c *Client) ticker() {
	defer c.wg.Done()
	t := time.NewTicker(time.Second)
	defer t.Stop()
	for {
		select {
		case <-c.done:
			return
		case now := <-t.C:
			st, sample, connected := c.step(now)
			c.emit(proto.Event{Type: proto.EventStatus, Status: &st})
			if connected {
				c.emit(proto.Event{Type: proto.EventSample, Sample: &sample})
				if c.rnd.Intn(3) == 0 {
					c.randomLog()
				}
			}
		}
	}
}

func (c *Client) step(now time.Time) (proto.Status, proto.Sample, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	connected := c.st.State == proto.LinkConnected
	if connected {
		c.up = drift(c.rnd, c.up, 120e3, 900e3)
		c.down = drift(c.rnd, c.down, 1.2e6, 12e6)
		c.st.UpBps = uint64(c.up)
		c.st.DownBps = uint64(c.down)
		c.st.BytesUp += uint64(c.up)
		c.st.BytesDown += uint64(c.down)
		c.st.Connections = 18 + c.rnd.Intn(40)
	}
	sample := proto.Sample{
		Time:        now,
		UpBps:       c.st.UpBps,
		DownBps:     c.st.DownBps,
		BytesUp:     c.st.BytesUp,
		BytesDown:   c.st.BytesDown,
		Connections: c.st.Connections,
	}
	return cloneStatus(c.st), sample, connected
}

func (c *Client) backlog() {
	defer c.wg.Done()
	select {
	case <-c.done:
		return
	case <-time.After(120 * time.Millisecond):
	}
	lines := []struct {
		src  string
		text string
	}{
		{"host", "barewire-host 0.1.0-mock started"},
		{"host", "sing-box 1.12.0-mock loaded"},
		{"sysctl", "net.ipv4.tcp_congestion_control = cubic"},
		{"tun", "device barewire0 reserved, no stack started"},
		{"nftables", "kill switch ruleset absent"},
		{"router", "rule set loaded: 4 rules, final => proxy"},
	}
	for _, l := range lines {
		select {
		case <-c.done:
			return
		case <-time.After(35 * time.Millisecond):
		}
		c.emitLog(proto.LevelInfo, l.src, l.text)
	}
}

func (c *Client) randomLog() {
	e := logPool[c.rnd.Intn(len(logPool))]
	c.emitLog(e.level, e.src, e.text)
}

func (c *Client) emitStatus() {
	st := c.Snapshot()
	c.emit(proto.Event{Type: proto.EventStatus, Status: &st})
}

func (c *Client) emitLog(level proto.LogLevel, src, text string) {
	e := proto.LogEntry{Time: time.Now(), Level: level, Source: src, Text: text}
	c.emit(proto.Event{Type: proto.EventLog, Log: &e})
}

// emit fans an event out to every subscriber. A slow subscriber loses events
// rather than blocking the link: a frozen interface must never stall traffic.
func (c *Client) emit(ev proto.Event) {
	c.mu.Lock()
	if c.closed {
		c.mu.Unlock()
		return
	}
	subs := append([]chan proto.Event(nil), c.subs...)
	c.mu.Unlock()
	for _, ch := range subs {
		select {
		case ch <- ev:
		default:
		}
	}
}

func cloneStatus(s proto.Status) proto.Status {
	s.DNS.Servers = append([]string(nil), s.DNS.Servers...)
	s.CCOptions = append([]string(nil), s.CCOptions...)
	return s
}

func mtuSource(mtu int) string {
	if mtu == 0 {
		return "auto"
	}
	return "manual"
}
