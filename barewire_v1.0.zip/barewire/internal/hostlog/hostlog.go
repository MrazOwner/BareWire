// Package hostlog keeps a line-per-fact record of a host session on disk.
//
// The interface shows the events of the moment in its log panel, and they are
// gone when it exits. The file is what is left — which is exactly the moment
// somebody needs to know why the tunnel dropped: the host is dead, the interface
// says so, and stderr was never a place anyone could look at.
package hostlog

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/mrazowner/barewire/internal/proto"
)

// maxSize is how large the file may grow before it is rotated to path.1.
const maxSize = 4 << 20

// Log appends events to a file. A failed write is not reported to the caller:
// losing a log line must never disturb the tunnel.
type Log struct {
	mu sync.Mutex
	f  *os.File
}

// Open creates or appends to path, rotating it first when it is already large.
// The file is mode 0600: it names the servers and the settings of its user.
func Open(path string) (*Log, error) {
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return nil, fmt.Errorf("hostlog: create %s: %w", filepath.Dir(path), err)
	}
	if info, err := os.Stat(path); err == nil && info.Size() > maxSize {
		_ = os.Rename(path, path+".1")
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o600)
	if err != nil {
		return nil, fmt.Errorf("hostlog: open %s: %w", path, err)
	}
	return &Log{f: f}, nil
}

// Write appends one event. Only log entries are kept: the status arrives twice a
// second and would bury the lines that matter.
func (l *Log) Write(ev proto.Event) {
	if l == nil || l.f == nil || ev.Log == nil {
		return
	}
	entry := *ev.Log
	if entry.Time.IsZero() {
		entry.Time = time.Now()
	}
	source := entry.Source
	if source == "" {
		source = "host"
	}
	line := fmt.Sprintf("%s %-5s [%s] %s\n",
		entry.Time.Format("2006-01-02 15:04:05.000"), levelName(entry.Level), source, entry.Text)

	l.mu.Lock()
	defer l.mu.Unlock()
	w := bufio.NewWriter(l.f)
	if _, err := w.WriteString(line); err != nil {
		return
	}
	_ = w.Flush()
}

// Close flushes nothing and closes the file.
func (l *Log) Close() error {
	if l == nil || l.f == nil {
		return nil
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.f.Close()
}

func levelName(l proto.LogLevel) string {
	switch l {
	case proto.LevelDebug:
		return "DEBUG"
	case proto.LevelWarn:
		return "WARN"
	case proto.LevelError:
		return "ERROR"
	default:
		return "INFO"
	}
}
