package hostlog

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/mrazowner/barewire/internal/proto"
)

// Every line the user will need after a crash has to be in the file: the level,
// the source and the text, in order, and nothing about the status stream.
func TestWriteKeepsLogLinesOnly(t *testing.T) {
	path := filepath.Join(t.TempDir(), "host.log")
	log, err := Open(path)
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	log.Write(proto.Event{Type: proto.EventLog, Log: &proto.LogEntry{
		Time:   time.Date(2026, 5, 4, 12, 0, 0, 0, time.UTC),
		Level:  proto.LevelWarn,
		Source: "clash-api",
		Text:   "stopped answering",
	}})
	log.Write(proto.Event{Type: proto.EventStatus, Status: &proto.Status{}})
	log.Write(proto.Event{Type: proto.EventLog, Log: &proto.LogEntry{
		Time:  time.Date(2026, 5, 4, 12, 0, 1, 0, time.UTC),
		Level: proto.LevelError,
		Text:  "link failed",
	}})
	if err := log.Close(); err != nil {
		t.Fatalf("close: %v", err)
	}

	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	lines := strings.Split(strings.TrimSpace(string(raw)), "\n")
	if len(lines) != 2 {
		t.Fatalf("want two lines, got %d: %q", len(lines), raw)
	}
	if !strings.Contains(lines[0], "WARN") || !strings.Contains(lines[0], "[clash-api]") ||
		!strings.Contains(lines[0], "stopped answering") {
		t.Fatalf("first line: %q", lines[0])
	}
	if !strings.Contains(lines[1], "ERROR") || !strings.Contains(lines[1], "[host]") {
		t.Fatalf("an entry without a source belongs to the host: %q", lines[1])
	}
}

// A log file nobody can open must not stop the host from serving: the tunnel is
// more important than the record of it.
func TestWriteWithoutAFileIsHarmless(t *testing.T) {
	var log *Log
	log.Write(proto.Event{Type: proto.EventLog, Log: &proto.LogEntry{Text: "x"}})
	if err := log.Close(); err != nil {
		t.Fatalf("close: %v", err)
	}
}

// A file the host cannot open is an error the caller may report, not a panic.
func TestOpenReportsAFailure(t *testing.T) {
	dir := t.TempDir()
	if _, err := Open(dir); err == nil {
		t.Fatal("opening a directory as a log file must fail")
	}
}
