package host

import (
	"errors"
	"strings"
	"testing"
)

// The multiplexing lever is the one setting that can only be confirmed by the
// server. The rule is small on purpose: an answer means it works, silence means it
// does not, and the note has to say which happened.
func TestMuxVerdict(t *testing.T) {
	if disable, note := muxVerdict(false, errors.New("boom")); disable || note != "" {
		t.Fatalf("a link without mux must not be touched: %v %q", disable, note)
	}
	disable, note := muxVerdict(true, nil)
	if disable {
		t.Fatal("an answer through the tunnel must not turn the lever off")
	}
	if !strings.Contains(note, "speaks sing-mux") {
		t.Fatalf("note = %q", note)
	}
	disable, note = muxVerdict(true, errors.New("timeout"))
	if !disable {
		t.Fatal("silence with the lever on has to turn it off")
	}
	if !strings.Contains(note, "does not speak sing-mux") || !strings.Contains(note, "timeout") {
		t.Fatalf("note = %q, want the reason and the cause", note)
	}
}
