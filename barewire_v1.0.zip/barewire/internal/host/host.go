// Package host is the privileged half of Barewire: it owns the core instance,
// the firewall, the kernel levers and the node selection, and reports every
// change as a fact.
package host

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"net"
	"sync"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/core"
	"github.com/mrazowner/barewire/internal/proto"
	"github.com/mrazowner/barewire/internal/system"
	"github.com/mrazowner/barewire/internal/version"
)

// Paths is where the host keeps its state.
type Paths struct {
	StateDir string
	TUNName  string
}

// Host is the host process state.
type Host struct {
	mu          sync.Mutex
	settings    config.Settings
	node        config.Node
	state       proto.LinkState
	since       time.Time
	lastStop    string
	lastStopAt  time.Time
	lastError   string
	lastErrorAt time.Time
	prevMetrics procMetrics
	cpuPercent  float64
	// mtuUsed is the MTU written into the running TUN. It is not always the
	// configured one: the path can carry less, and the status has to show what
	// the core actually received.
	mtuUsed    int
	reconnects int
	sample     proto.Sample

	engine *core.Engine
	fw     *system.Firewall
	kernel *system.Kernel
	probe  *system.ThroughputProbe
	// muxCheck proves that a request through the tunnel works. It is a field so a
	// test can decide the answer without a tunnel; nil means the real network.
	muxCheck func(context.Context) error
	// kernelTest is the last trial run, kept per server.
	kernelTest kernelTestFile
	// netCancel stops the default-route watcher.
	netCancel context.CancelFunc
	// wdCancel stops the core watchdog, which restarts a core that stopped
	// answering instead of leaving a dead tunnel labelled "connected".
	wdCancel context.CancelFunc
	// wdRestarts counts how many times the watchdog restarted this link.
	wdRestarts int
	// opMu serialises the operations that stop and start the core. Two of them
	// at once used to race: a second Start found the first one's instance and
	// failed with "core: already running", which looked like a broken setting.
	opMu sync.Mutex

	paths       Paths
	clashAddr   string
	clashSecret string
	publish     func(proto.Event)
}

// New builds the host. The settings are whatever was on disk; nothing starts
// until the interface asks for it.
func New(settings config.Settings, paths Paths) *Host {
	if paths.TUNName == "" {
		paths.TUNName = "barewire0"
	}
	h := &Host{
		settings:  settings,
		state:     proto.LinkDisconnected,
		fw:        system.NewFirewall(),
		kernel:    system.NewKernel(paths.StateDir),
		probe:     system.NewThroughputProbe(nil),
		paths:     paths,
		clashAddr: "127.0.0.1:0",
	}
	h.engine = core.New(h.onLog, h.onSample)
	h.engine.SetStallHandler(h.onCoreStall)
	h.pickClashPort()
	h.loadKernelTest()
	return h
}

// SetPublisher wires the host to the socket server.
func (h *Host) SetPublisher(fn func(proto.Event)) {
	h.mu.Lock()
	h.publish = fn
	h.mu.Unlock()
}

// pickClashPort asks the kernel for a free loopback port for the statistics API.
func (h *Host) pickClashPort() {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		h.clashAddr = ""
		return
	}
	h.clashAddr = ln.Addr().String()
	_ = ln.Close()
	h.clashSecret = randomToken()
}

// randomToken is the secret protecting the local statistics API.
func randomToken() string {
	buf := make([]byte, 16)
	if _, err := rand.Read(buf); err != nil {
		return fmt.Sprintf("t%d", time.Now().UnixNano())
	}
	return hex.EncodeToString(buf)
}

// Status reports the current facts. It never blocks on the core.
func (h *Host) Status() proto.Status {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.statusLocked()
}

func (h *Host) statusLocked() proto.Status {
	// The host is the core: these are its own numbers.
	cur := readProcMetrics()
	h.cpuPercent = cpuPercentBetween(h.prevMetrics, cur)
	h.prevMetrics = cur

	ksActive, ksVersion := h.fw.Active()
	congestion, _ := h.kernel.CongestionControl()
	if congestion == "" {
		congestion = "unknown"
	}
	qdisc := h.kernel.Qdisc()
	ccOptions := h.kernel.Available()
	mtuSource := "manual"
	if h.settings.MTU == 0 {
		mtuSource = "auto"
	}
	// A *configured* MTU the path cannot carry is lowered, and the status has to
	// say so: "manual" would advertise a number the core does not use. On auto
	// there is nothing to lower, and the old comparison against a zero setting
	// labelled every measured link as lowered.
	if h.settings.MTU > 0 && h.mtuUsed > 0 && h.mtuUsed != h.settings.MTU {
		mtuSource = "lowered to fit the path"
	}

	outbound := ""
	if h.node.Kind != "" {
		outbound = "proxy[" + h.node.Kind + "]"
	}
	rule := ""
	if h.state == proto.LinkConnected && h.node.Connectable() {
		rule = "final"
	}
	// What the core actually carries, not what the file asks for: mux needs an
	// outbound type with a multiplex section, and brutal needs that plus the
	// kernel's "brutal" congestion control.
	muxOn, muxProtocol, brutalOn := carriedTransport(h.settings, h.node.Kind, h.node.Flow(), brutalAvailable(ccOptions))
	st := proto.Status{
		HostRunning: true,
		HostVersion: Version,
		CoreVersion: version.Core(),
		State:       h.state,
		Since:       h.since,
		Profile:     h.settings.Profile,
		Server:      h.node.Endpoint(),
		Protocol:    h.node.Kind,
		Flow:        h.node.Flow(),
		Outbound:    outbound,
		Rule:        rule,
		TUNStack:    h.settings.TUNStack,
		MTU:         h.effectiveMTU(),
		MTUSource:   mtuSource,
		Smux: proto.Smux{
			Enabled:  muxOn,
			Protocol: muxProtocol,
			Padding:  h.settings.Smux.Padding,
		},
		Brutal: proto.Brutal{
			Enabled:  brutalOn,
			UpMbps:   h.settings.Brutal.UpMbps,
			DownMbps: h.settings.Brutal.DownMbps,
		},
		Congestion: congestion,
		Qdisc:      qdisc,
		CCOptions:  ccOptions,
		KernelBest: h.bestFor(h.node.Endpoint()),
		DNS: proto.DNS{
			Mode:    h.settings.DNS.Mode,
			Servers: append([]string(nil), h.settings.DNS.Servers...),
		},
		KillSwitch: proto.KillSwitch{
			Enabled:         h.settings.KillSwitch.Enabled,
			Active:          ksActive,
			OnCrash:         h.settings.KillSwitch.OnCrash,
			OnNetworkChange: h.settings.KillSwitch.OnNetworkChange,
			RulesetVersion:  ksVersion,
		},
		Reconnects:       h.reconnects,
		LastDisconnect:   h.lastStop,
		LastDisconnectAt: h.lastStopAt,
		LastError:        h.lastError,
		LastErrorAt:      h.lastErrorAt,
		UpBps:            h.sample.UpBps,
		DownBps:          h.sample.DownBps,
		BytesUp:          h.sample.BytesUp,
		BytesDown:        h.sample.BytesDown,
		Connections:      h.sample.Connections,
		MemRSSKB:         cur.rssKB,
		CPUPercent:       h.cpuPercent,
	}
	if h.node.Address == "" {
		st.Server = ""
		st.Protocol = ""
	}
	return st
}

func (h *Host) effectiveMTU() int {
	if h.mtuUsed > 0 {
		return h.mtuUsed
	}
	if h.settings.MTU > 0 {
		return h.settings.MTU
	}
	return config.DefaultTunnelMTU
}

// emitStatus publishes the current facts.
func (h *Host) emitStatus() {
	h.mu.Lock()
	st := h.statusLocked()
	publish := h.publish
	h.mu.Unlock()
	if publish != nil {
		publish(proto.Event{Type: proto.EventStatus, Status: &st})
	}
}

func (h *Host) logf(level proto.LogLevel, format string, args ...any) {
	h.mu.Lock()
	publish := h.publish
	h.mu.Unlock()
	if publish == nil {
		return
	}
	entry := proto.LogEntry{Time: time.Now(), Level: level, Source: "host", Text: sprintf(format, args...)}
	publish(proto.Event{Type: proto.EventLog, Log: &entry})
}

func (h *Host) onLog(entry proto.LogEntry) {
	h.mu.Lock()
	publish := h.publish
	if entry.Level == proto.LevelError {
		h.lastError = entry.Text
		h.lastErrorAt = entry.Time
	}
	h.mu.Unlock()
	if publish != nil {
		publish(proto.Event{Type: proto.EventLog, Log: &entry})
	}
}

// onCoreStall reports a core that is up but no longer answers its own API. The
// link is left as it is: the user decides whether to reconnect, and the log says
// what happened instead of leaving "connected" as a lie.
func (h *Host) onCoreStall() {
	h.mu.Lock()
	h.lastError = "core: the statistics API stopped answering"
	h.lastErrorAt = time.Now()
	h.mu.Unlock()
	h.emitStatus()
	h.logf(proto.LevelWarn, "core: has not answered for a while; the watchdog restarts it in %s unless it recovers", watchdogGrace)
}

func (h *Host) onSample(sample proto.Sample) {
	h.mu.Lock()
	h.sample = sample
	st := h.statusLocked()
	publish := h.publish
	h.mu.Unlock()
	if publish == nil {
		return
	}
	publish(proto.Event{Type: proto.EventSample, Sample: &sample})
	publish(proto.Event{Type: proto.EventStatus, Status: &st})
}

// Connections returns the live connection table.
func (h *Host) Connections() []proto.Connection {
	return h.engine.Connections()
}
