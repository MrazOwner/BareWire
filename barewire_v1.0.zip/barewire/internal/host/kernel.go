package host

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
	"github.com/mrazowner/barewire/internal/system"
)

// Trial sizes. The download has to last long enough for a congestion control to
// show its shape, and short enough that seventeen of them are not a coffee break.
const (
	kernelTrialBytes = 8 << 20
	kernelTrialRTTs  = 12
)

// kernelTestFile is the saved result. It is per server: the winner depends on the
// path, so a result for one node says nothing about another.
type kernelTestFile struct {
	Server string              `json:"server"`
	At     time.Time           `json:"at"`
	Best   string              `json:"best"`
	Trials []proto.KernelTrial `json:"trials"`
}

// TestKernel measures every congestion control this machine offers, one after
// another, on the live path, and remembers the winner. It is the only honest way
// to answer "which one is more stable for me": the answer depends on the route,
// not on the algorithm's reputation.
func (h *Host) TestKernel(ctx context.Context) ([]proto.KernelTrial, error) {
	h.mu.Lock()
	running := h.state == proto.LinkConnected
	settings := h.settings.Clone()
	server := h.node.Endpoint()
	h.mu.Unlock()
	if !running || server == "" {
		return nil, errors.New("kernel test: connect first")
	}
	algorithms := h.kernel.Available()
	if len(algorithms) < 2 {
		return nil, fmt.Errorf("kernel test: this kernel registers %d algorithm(s), nothing to compare", len(algorithms))
	}

	probe := &system.ThroughputProbe{
		Client:  &http.Client{Timeout: 60 * time.Second},
		DownURL: fmt.Sprintf("https://speed.cloudflare.com/__down?bytes=%d", kernelTrialBytes),
		UpURL:   "https://speed.cloudflare.com/__up",
		DownB:   kernelTrialBytes,
	}
	measure := func(ctx context.Context) (int, []time.Duration, error) {
		down, err := probe.Download(ctx)
		if err != nil {
			return 0, nil, err
		}
		rtts := make([]time.Duration, 0, kernelTrialRTTs)
		for i := 0; i < kernelTrialRTTs; i++ {
			rtt, err := system.PingTCP(ctx, server, 3*time.Second)
			if err != nil {
				return 0, nil, err
			}
			rtts = append(rtts, rtt)
		}
		return down, rtts, nil
	}

	h.logf(proto.LevelInfo, "kernel test: %d algorithms, %d MiB each", len(algorithms), kernelTrialBytes>>20)
	trials, err := h.kernel.Benchmark(ctx, kernelValues(settings.Kernel), algorithms, measure)
	if err != nil {
		return nil, err
	}
	out := make([]proto.KernelTrial, 0, len(trials))
	for _, tr := range trials {
		out = append(out, proto.KernelTrial{
			Algorithm: tr.Algorithm,
			DownMbps:  tr.DownMbps,
			RTTMinMs:  tr.RTTMinMs,
			RTTP95Ms:  tr.RTTP95Ms,
			Score:     tr.Score,
			Err:       tr.Err,
		})
		if tr.Err != "" {
			h.logf(proto.LevelWarn, "kernel test: %s: %s", tr.Algorithm, tr.Err)
			continue
		}
		h.logf(proto.LevelInfo, "kernel test: %-9s %4d Mbps · rtt %d/%d ms · score %.0f",
			tr.Algorithm, tr.DownMbps, tr.RTTMinMs, tr.RTTP95Ms, tr.Score)
	}
	best := system.Best(trials)
	h.rememberKernelTest(server, best, out)
	h.emitStatus()
	if best == "" {
		h.logf(proto.LevelWarn, "kernel test: no algorithm produced a measurable result")
	} else {
		h.logf(proto.LevelInfo, "kernel test: best for %s is %s", server, best)
	}
	return out, nil
}

// rememberKernelTest stores the result for the node it was measured on and puts
// it in the status. Saving is best effort: a read-only state directory must not
// turn a finished run into a failure.
func (h *Host) rememberKernelTest(server, best string, trials []proto.KernelTrial) {
	h.mu.Lock()
	h.kernelTest = kernelTestFile{Server: server, At: time.Now(), Best: best, Trials: trials}
	h.mu.Unlock()
	raw, err := json.MarshalIndent(h.kernelTest, "", "  ")
	if err != nil {
		h.logf(proto.LevelWarn, "kernel test: encode: %v", err)
		return
	}
	if err := os.MkdirAll(h.paths.StateDir, 0o700); err != nil {
		h.logf(proto.LevelWarn, "kernel test: %v", err)
		return
	}
	path := filepath.Join(h.paths.StateDir, "kernel-test.json")
	if err := os.WriteFile(path, raw, 0o600); err != nil {
		h.logf(proto.LevelWarn, "kernel test: %v", err)
	}
}

// loadKernelTest reads the saved result so that the interface can show the last
// winner before any test is run in this session.
func (h *Host) loadKernelTest() {
	raw, err := os.ReadFile(filepath.Join(h.paths.StateDir, "kernel-test.json"))
	if err != nil {
		return
	}
	var f kernelTestFile
	if err := json.Unmarshal(raw, &f); err != nil {
		return
	}
	h.kernelTest = f
}

// bestFor returns the saved winner for a server, or "" when the saved run was
// made against a different one.
func (h *Host) bestFor(server string) string {
	if h.kernelTest.Server == "" || h.kernelTest.Server != server {
		return ""
	}
	return h.kernelTest.Best
}

// applyKernel turns the lever set into sysctl writes and reports the outcome as
// a fact. A lever that cannot be applied says why in the log and in the status,
// because the failure the old bool lever had was silence: the toggle looked on,
// the kernel stayed on cubic, and nothing said so.
func (h *Host) applyKernel(ctx context.Context, k config.KernelSettings) {
	if k.Empty() {
		if err := h.kernel.Restore(ctx); err != nil {
			h.logf(proto.LevelError, "kernel: %v", err)
			h.emitStatus()
			return
		}
		h.emitStatus()
		h.logf(proto.LevelInfo, "kernel: restored to the machine's own values")
		return
	}
	if err := h.kernel.Apply(ctx, kernelValues(k)); err != nil {
		h.logf(proto.LevelError, "kernel: %v", err)
		h.emitStatus()
		return
	}
	h.emitStatus()
	h.logf(proto.LevelInfo, "kernel: %s", kernelFact(k))
}

// kernelValues maps the lever set onto the writer. The two packages stay apart
// on purpose: the host owns the policy, system owns /proc.
func kernelValues(k config.KernelSettings) system.KernelValues {
	return system.KernelValues{
		Congestion:         k.Congestion,
		Qdisc:              k.Qdisc,
		MTUProbing:         k.MTUProbing,
		SlowStartAfterIdle: k.SlowStartAfterIdle,
	}
}

// kernelFact renders what was asked for in one line, for the log.
func kernelFact(k config.KernelSettings) string {
	parts := make([]string, 0, 4)
	if k.Congestion != "" {
		parts = append(parts, k.Congestion)
	}
	if k.Qdisc != "" {
		parts = append(parts, "qdisc "+k.Qdisc)
	}
	if k.MTUProbing != "" {
		parts = append(parts, "mtu probing "+k.MTUProbing)
	}
	if k.SlowStartAfterIdle != "" {
		parts = append(parts, "slow start after idle "+k.SlowStartAfterIdle)
	}
	if len(parts) == 0 {
		return "nothing asked for"
	}
	return strings.Join(parts, " · ")
}
