package host

import (
	"context"
	"errors"
	"fmt"
	"net"
	"strings"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	coreconf "github.com/mrazowner/barewire/internal/core/config"
	"github.com/mrazowner/barewire/internal/proto"
	"github.com/mrazowner/barewire/internal/system"
	"github.com/mrazowner/barewire/internal/version"
)

// Version is the host build identity reported in the interface.
var Version = version.String()

// networkPollInterval is how often the default route is compared. Slow enough to
// cost nothing, fast enough to notice a cable being pulled.
const networkPollInterval = 5 * time.Second

func sprintf(format string, args ...any) string {
	if len(args) == 0 {
		return format
	}
	return fmt.Sprintf(format, args...)
}

// Connect brings the tunnel up: kill switch first, then the core. Nothing is
// left leaking between the two, and every failure is reported, not retried.
func (h *Host) Connect(ctx context.Context) error {
	h.opMu.Lock()
	err := h.connect(ctx)
	h.opMu.Unlock()
	if err == nil {
		h.goVerifyMux()
	}
	return err
}

// connect assumes opMu is held.
func (h *Host) connect(ctx context.Context) error {
	h.mu.Lock()
	if h.state == proto.LinkConnected {
		// "Connected" is a fact about the host, and the core can stop answering
		// without the host noticing. Asking to connect again is the user saying
		// the tunnel is not working: restart it instead of doing nothing.
		healthy := h.engine.Healthy()
		h.mu.Unlock()
		if healthy {
			return nil
		}
		h.logf(proto.LevelWarn, "link: connected but the core is not answering, restarting it")
		if err := h.restart(ctx); err != nil {
			h.fail("restart failed: " + err.Error())
			return err
		}
		return nil
	}
	if h.state == proto.LinkConnecting {
		h.mu.Unlock()
		return nil
	}
	node := h.node
	settings := h.settings.Clone()
	if !node.Connectable() {
		h.mu.Unlock()
		return errors.New("no node selected")
	}
	h.state = proto.LinkConnecting
	h.mu.Unlock()

	h.emitStatus()
	h.logf(proto.LevelInfo, "link: connecting to %s", node.Endpoint())

	if err := h.startEngine(ctx, settings, node); err != nil {
		h.fail("start failed: " + err.Error())
		return err
	}

	h.mu.Lock()
	if h.state != proto.LinkConnecting {
		// Disconnect ran while the core was starting: the engine is already
		// stopped, so claiming the link is up would be a lie the user has to
		// undo by hand.
		h.mu.Unlock()
		h.stopEngine()
		h.logf(proto.LevelWarn, "link: connect cancelled while starting")
		return errors.New("connect cancelled")
	}
	h.state = proto.LinkConnected
	h.since = time.Now()
	h.lastStop = ""
	h.mu.Unlock()

	h.emitStatus()
	h.logf(proto.LevelInfo, "link: connected")
	h.startNetworkWatch()
	h.startWatchdog()
	return nil
}

// goVerifyMux starts the multiplexing check outside the operation lock: the check
// talks to the network, and the lock is how connect, disconnect and restart stay
// serialised. Nothing is started when the lever is off.
func (h *Host) goVerifyMux() {
	h.mu.Lock()
	enabled := h.settings.Smux.Enabled
	h.mu.Unlock()
	if !enabled {
		return
	}
	go h.verifyMux(context.Background())
}

// startEngine resolves the MTU, builds the configuration, installs the kill
// switch and starts the core with it.
func (h *Host) startEngine(ctx context.Context, settings config.Settings, node config.Node) error {
	mtu := h.resolveMTU(ctx, settings, node)

	brutalOK := h.resolveMultiplex(ctx, settings, node)
	raw, err := coreconf.Build(coreconf.Input{
		Settings:        settings,
		Node:            node,
		TUNName:         h.paths.TUNName,
		MTU:             mtu,
		StateDir:        h.paths.StateDir,
		ClashAddress:    h.clashAddr,
		ClashSecret:     h.clashSecret,
		BrutalSupported: brutalOK,
	})
	if err != nil {
		return err
	}

	if settings.KillSwitch.Enabled {
		allow := resolveServerAddrs(ctx, node.Address)
		if len(allow) == 0 {
			// A ruleset with no allowed server address blocks the tunnel's own
			// connection: the link comes up and nothing passes. Refusing to
			// install it is the difference between "no kill switch" and "no
			// network".
			h.logf(proto.LevelError, "kill switch: %q has no IPv4 address to allow, so the ruleset would block the tunnel itself; not installed", node.Address)
		} else if err := h.fw.Apply(ctx, true, allow, h.paths.TUNName); err != nil {
			h.logf(proto.LevelError, "kill switch: %v", err)
		} else {
			h.logf(proto.LevelInfo, "kill switch: ruleset installed, %d allowed addresses", len(allow))
		}
	} else if err := h.fw.Flush(ctx); err != nil {
		h.logf(proto.LevelError, "kill switch: %v", err)
	}

	// The DNS guard runs whether or not the kill switch is on: with IPv6 off the
	// tunnel carries no IPv6, so a query to a v6 resolver would leave the machine
	// directly — the one DNS path the tunnel cannot cover.
	blockIPv6DNS := settings.DNS.Mode != "disabled" && !settings.DNS.UseIPv6
	if err := h.fw.ApplyGuard(ctx, blockIPv6DNS, h.paths.TUNName); err != nil {
		h.logf(proto.LevelError, "dns guard: %v", err)
	} else if blockIPv6DNS {
		h.logf(proto.LevelInfo, "dns guard: IPv6 DNS is blocked, the tunnel has no IPv6 (Include IPv6 is off)")
	}

	// A resolver stub on the loopback is the one DNS path the TUN cannot see by
	// itself: the packets never leave the host's own stack, so the daemon forwards
	// them out of the physical interface and the ISP answers them. Saying so is the
	// difference between "the test shows my ISP" and something the user can fix.
	if stub := system.LoopbackStub(system.SystemResolverNameservers()); stub != "" {
		if settings.AutoRedirect {
			h.logf(proto.LevelInfo, "dns: the system resolver is %s; auto redirect steers its queries into the tunnel", stub)
		} else {
			h.logf(proto.LevelWarn, "dns: the system resolver is %s, and its queries never enter the tunnel; turn Auto redirect on so the ISP stops answering them", stub)
		}
	}

	if !settings.Kernel.Empty() {
		h.applyKernel(ctx, settings.Kernel)
	}

	if err := h.engine.Start(ctx, raw); err != nil {
		// auto_redirect is the newest part of the configuration and the one that
		// needs tools outside the core (nft or iptables). A tunnel without it is
		// worth more than no tunnel, so one retry without it — and the reason in
		// the log, because a lever that was dropped has to say so.
		if settings.AutoRedirect {
			if _, ok := h.startWithoutRedirect(ctx, settings, node, mtu, brutalOK, err); ok {
				h.logf(proto.LevelInfo, "core: started without auto redirect, stack %s, mtu %d, %s",
					settings.TUNStack, h.effectiveMTU(), transportFact(settings, node.Kind, node.Flow(), brutalOK))
				return nil
			}
		}
		// The crash policy is a decision the user made, not a label: "keep"
		// leaves the ruleset in place so traffic stays blocked, "flush" opens the
		// machine again. Until now both flushed.
		if settings.KillSwitch.Enabled && settings.KillSwitch.OnCrash == "flush" {
			_ = h.fw.Flush(ctx)
		} else if settings.KillSwitch.Enabled {
			h.logf(proto.LevelWarn, "kill switch: ruleset kept after the core failed; traffic stays blocked")
		}
		return err
	}
	h.logf(proto.LevelInfo, "core: started, stack %s, mtu %d, %s",
		settings.TUNStack, h.effectiveMTU(), transportFact(settings, node.Kind, node.Flow(), brutalOK))
	return nil
}

// startWithoutRedirect retries the start with auto_redirect off. It reports
// whether the retry started, and logs the original failure — a lever that was
// dropped because the machine could not carry it has to say so.
func (h *Host) startWithoutRedirect(ctx context.Context, settings config.Settings, node config.Node, mtu int, brutalOK bool, cause error) (config.Settings, bool) {
	settings.AutoRedirect = false
	raw, err := coreconf.Build(coreconf.Input{
		Settings:        settings,
		Node:            node,
		TUNName:         h.paths.TUNName,
		MTU:             mtu,
		StateDir:        h.paths.StateDir,
		ClashAddress:    h.clashAddr,
		ClashSecret:     h.clashSecret,
		BrutalSupported: brutalOK,
	})
	if err != nil {
		return settings, false
	}
	if err := h.engine.Start(ctx, raw); err != nil {
		return settings, false
	}
	h.mu.Lock()
	h.settings.AutoRedirect = false
	h.mu.Unlock()
	h.logf(proto.LevelWarn, "core: auto redirect could not be installed (%v); this session runs without it, so a resolver on the loopback still answers directly", cause)
	return settings, true
}

// mtuNote is the sentence the log carries for a decision, with the level it
// deserves: a lever that could not act at its setting has to say so.
type mtuNote struct {
	level proto.LogLevel
	text  string
}

// mtuDecision turns the lever and a measurement into the value the TUN receives.
//
// Three facts meet here. A configured value wins while it fits. The ceiling is
// what the path can carry, which is the path minus one outer header and the
// transport's own overhead. And when nothing could be measured, the configured
// value is still bounded by MaxTunnelMTU: no encapsulation carries an inner
// packet that large over an Ethernet path, so keeping it is not a preference, it
// is a black hole. Until now a failed probe left a 1488-byte value untouched —
// which is exactly the shape of "it connects and then the video stalls".
func mtuDecision(configured, path int, kind string) (int, mtuNote) {
	if configured <= 0 {
		if path > 0 {
			mtu := config.TunnelMTUCeiling(path, kind)
			return mtu, mtuNote{level: proto.LevelInfo, text: sprintf(
				"mtu: path %d bytes, tunnel %d (%d bytes of overhead for %s)",
				path, mtu, config.OuterHeaderLen+config.TunnelOverhead(kind), kind)}
		}
		return config.DefaultTunnelMTU, mtuNote{level: proto.LevelWarn, text: sprintf(
			"mtu: no measurement, using %d bytes; a link that keeps stalling usually wants less",
			config.DefaultTunnelMTU)}
	}
	if path > 0 {
		if ceiling := config.TunnelMTUCeiling(path, kind); configured > ceiling {
			return ceiling, mtuNote{level: proto.LevelWarn, text: sprintf(
				"mtu: %d does not fit a %d-byte path through %s, using %d",
				configured, path, kind, ceiling)}
		}
		return configured, mtuNote{level: proto.LevelDebug, text: sprintf(
			"mtu: %d, which fits a %d-byte path through %s", configured, path, kind)}
	}
	if configured > config.MaxTunnelMTU {
		return config.MaxTunnelMTU, mtuNote{level: proto.LevelWarn, text: sprintf(
			"mtu: %d cannot fit any tunnel over an Ethernet path and the path could not be measured, using %d",
			configured, config.MaxTunnelMTU)}
	}
	return configured, mtuNote{level: proto.LevelDebug, text: sprintf(
		"mtu: %d, nothing measured; a link that keeps stalling usually wants less", configured)}
}

// resolveMTU turns the MTU lever into the number written into the TUN inbound,
// measuring the path first. "Auto" is not the path MTU: the tunnel wraps every
// inner packet in its own headers, so the TUN has to be smaller than the path by
// that much.
func (h *Host) resolveMTU(ctx context.Context, settings config.Settings, node config.Node) int {
	path, source := h.probePathMTU(ctx, node)
	if path > 0 && source != "" {
		h.logf(proto.LevelDebug, "mtu probe: %s mtu %d bytes to %s", source, path, node.Endpoint())
	}
	mtu, note := mtuDecision(settings.MTU, path, node.Kind)
	h.setMTU(mtu)
	h.logf(note.level, "%s", note.text)
	return mtu
}

// probePathMTU measures the path to the server and names where the number came
// from, because the two measurements are not the same thing: the MSS probe reads
// what the far side negotiated, the route reading is what this machine can send.
//
// The MSS probe needs a completed TCP handshake. A UDP transport's server has no
// TCP port, so that probe cannot work for hysteria2, TUIC or WireGuard at all —
// it used to burn five seconds on every connect and then report nothing, which
// is why a node of that kind always ended up with an unmeasured MTU.
func (h *Host) probePathMTU(ctx context.Context, node config.Node) (int, string) {
	if config.IsUDPTransport(node.Kind) {
		mtu, err := system.RouteMTU(ctx, node.Endpoint())
		if err != nil {
			h.logf(proto.LevelWarn, "%v", err)
			return 0, ""
		}
		return mtu, "route"
	}
	path, err := system.ProbeMTU(ctx, node.Endpoint(), 576, 9000)
	if err == nil {
		return path, "path"
	}
	// The handshake did not complete: a blocked port or a link that answers
	// nothing. The route is still readable, and it is better than no fact.
	mtu, rerr := system.RouteMTU(ctx, node.Endpoint())
	if rerr != nil {
		h.logf(proto.LevelWarn, "%v", err)
		return 0, ""
	}
	h.logf(proto.LevelDebug, "mtu probe: the mss probe failed (%v), reading the route instead", err)
	return mtu, "route"
}

// setMTU records the value the running TUN received.
func (h *Host) setMTU(mtu int) {
	h.mu.Lock()
	h.mtuUsed = mtu
	h.mu.Unlock()
}

// startNetworkWatch makes the "on network change" levers real: it watches the
// device that carries the default route and acts once per change.
func (h *Host) startNetworkWatch() {
	h.mu.Lock()
	if h.netCancel != nil {
		h.netCancel()
		h.netCancel = nil
	}
	ctx, cancel := context.WithCancel(context.Background())
	h.netCancel = cancel
	h.mu.Unlock()
	go h.watchNetwork(ctx)
}

// stopNetworkWatch ends the watcher; it is safe to call when it never started.
func (h *Host) stopNetworkWatch() {
	h.mu.Lock()
	cancel := h.netCancel
	h.netCancel = nil
	h.mu.Unlock()
	if cancel != nil {
		cancel()
	}
}

// watchNetwork compares the default route device every few seconds. A changed
// device is the event: the gateway and the metric change all the time and are not
// a new network.
//
// The tunnel is skipped, and a change has to be seen twice. Both rules exist
// because the alternative is worse than useless: with auto_route the TUN owns the
// default route, so the watcher used to see its own tunnel, and a DHCP renewal
// that briefly reordered two default routes looked like a new network and
// restarted a working core. A restart drops every connection; doing it for a
// route that never moved is the kind of bug that reads as "the client is flaky".
func (h *Host) watchNetwork(ctx context.Context) {
	device, err := system.DefaultRouteDevice(ctx, h.paths.TUNName)
	if err != nil {
		return // no iproute2: nothing to watch, and saying so every 5s is noise
	}
	ticker := time.NewTicker(networkPollInterval)
	defer ticker.Stop()
	pending := ""
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			now, err := system.DefaultRouteDevice(ctx, h.paths.TUNName)
			if err != nil {
				continue
			}
			if now == device {
				pending = ""
				continue
			}
			// One reading is a flap; two in a row is a network.
			if pending != now {
				pending = now
				continue
			}
			pending = ""
			h.logf(proto.LevelWarn, "network: default route moved from %q to %q", device, now)
			device = now
			h.networkChanged(ctx)
		}
	}
}

// networkChanged applies the two policies that were only labels before. It takes
// the operation lock only if it is free: a change that arrives in the middle of
// an apply is not worth interrupting it for.
func (h *Host) networkChanged(ctx context.Context) {
	if !h.opMu.TryLock() {
		h.logf(proto.LevelWarn, "network change: ignored, another operation is in flight")
		return
	}
	defer h.opMu.Unlock()
	settings := h.currentSettings()
	if settings.KillSwitch.Enabled {
		if settings.KillSwitch.OnNetworkChange == "flush" {
			if err := h.fw.Flush(ctx); err != nil {
				h.logf(proto.LevelError, "kill switch: flush after a network change: %v", err)
			} else {
				h.logf(proto.LevelInfo, "kill switch: ruleset flushed after a network change")
			}
		} else {
			h.logf(proto.LevelInfo, "kill switch: ruleset kept after a network change")
		}
	}
	switch settings.DNS.OnNetworkChange {
	case "disconnect":
		if err := h.disconnect(ctx); err != nil {
			h.logf(proto.LevelError, "network change: disconnect: %v", err)
		}
	case "restart":
		h.mu.Lock()
		live := h.state == proto.LinkConnected
		h.mu.Unlock()
		if !live {
			return
		}
		if err := h.restart(ctx); err != nil {
			h.fail("restart after a network change failed: " + err.Error())
			return
		}
		h.logf(proto.LevelInfo, "network change: core restarted")
	}
}

// resolveMultiplex decides what the transport levers can actually do for this
// node on this machine, and says why the rest is dropped. Both answers are facts
// the log keeps: a multiplexer that silently does nothing is what made the lever
// look broken.
//
// Two limits are real. The outbound type must carry a multiplex section at all —
// sing-box rejects the field on TUIC, Hysteria2 and WireGuard, which makes the
// whole config undecodable. And TCP Brutal is not a sing-box feature: it is a
// kernel module that registers the "brutal" congestion control, so without it
// every connection fails in setsockopt.
func (h *Host) resolveMultiplex(ctx context.Context, settings config.Settings, node config.Node) bool {
	if !config.SupportsMultiplex(node.Kind) {
		if settings.Smux.Enabled {
			h.logf(proto.LevelWarn, "multiplexing: %s carries its own streams and has no multiplex section, the lever is ignored", node.Kind)
		}
		if settings.Brutal.Enabled {
			h.logf(proto.LevelWarn, "tcp brutal: %s has no multiplex section, so there is no rate to set; ignored", node.Kind)
		}
		return false
	}
	if !settings.Brutal.Enabled {
		return false
	}
	if err := h.kernel.Ensure(ctx, "brutal"); err != nil {
		h.logf(proto.LevelError, "tcp brutal: %v", err)
		h.logf(proto.LevelWarn, "tcp brutal: disabled until the kernel offers the brutal congestion control and the server enables it")
		return false
	}
	return true
}

// transportFact renders the multiplexing state as a fact. It belongs in the
// start line because a server without mux support looks exactly like "the link
// is up but nothing loads", and because the lever can be on while the core
// carries nothing.
// carriedTransport is what the core actually carries, and it is written once
// because two places have to agree about it: the line the log keeps when the core
// starts and the status the interface shows.
//
// The rules mirror the builder. Multiplexing needs an outbound type with a
// multiplex section at all. Brutal needs that plus the kernel's "brutal"
// congestion control, and it turns multiplexing on by itself — with smux, the only
// protocol TCP Brutal rides on. The status used to require the smux lever to be on
// before it would even look at Brutal, so a working Brutal link was reported as
// off, and a Brutal link with the smux lever off was reported as running yamux.
func carriedTransport(s config.Settings, kind, flow string, brutalOK bool) (mux bool, protocol string, brutal bool) {
	if !config.SupportsMultiplex(kind) || flow != "" {
		return false, s.Smux.Protocol, false
	}
	if s.Brutal.Enabled && brutalOK {
		if s.Smux.Enabled && s.Smux.Protocol != "" {
			return true, s.Smux.Protocol, true
		}
		return true, "smux", true
	}
	if s.Smux.Enabled {
		protocol = s.Smux.Protocol
		if protocol == "" {
			protocol = "smux"
		}
		return true, protocol, false
	}
	return false, s.Smux.Protocol, false
}

// brutalAvailable reports whether this machine registers the "brutal"
// congestion control, which only the out-of-tree tcp_brutal module provides.
func brutalAvailable(options []string) bool {
	for _, opt := range options {
		if opt == "brutal" {
			return true
		}
	}
	return false
}

func transportFact(s config.Settings, kind, flow string, brutalOK bool) string {
	mux, protocol, brutal := carriedTransport(s, kind, flow, brutalOK)
	muxText := "off"
	if mux {
		muxText = protocol
	}
	brutalText := "off"
	switch {
	case brutal:
		brutalText = fmt.Sprintf("on %d/%d", s.Brutal.UpMbps, s.Brutal.DownMbps)
	case s.Brutal.Enabled && config.SupportsMultiplex(kind):
		brutalText = "off (not available)"
	}
	return fmt.Sprintf("mux %s, brutal %s", muxText, brutalText)
}

// muxEgressURL is a one-byte endpoint: the check only has to prove that a request
// through the tunnel completes at all, not how fast it is.
const muxEgressURL = "https://speed.cloudflare.com/__down?bytes=1"

// muxProbeTimeout bounds one check. Long enough for a slow mobile link, short
// enough that a broken lever does not look like a broken network for a minute.
const muxProbeTimeout = 20 * time.Second

// muxRetryDelay is the pause before the second attempt: right after connect the
// tunnel can still be installing its routes, and one failed request is not proof.
const muxRetryDelay = 4 * time.Second

// muxVerdict turns the result of one request through the tunnel into a decision.
// It is a function so the rule can be read and tested without a tunnel: an answer
// means the multiplexed session works, and silence with the lever on means the
// server does not speak sing-mux, which no client can fix from its own side.
func muxVerdict(enabled bool, err error) (disable bool, note string) {
	if !enabled {
		return false, ""
	}
	if err == nil {
		return false, "mux: a request through the tunnel came back, the server speaks sing-mux"
	}
	return true, "mux: nothing came back through the tunnel (" + err.Error() +
		"), so this server does not speak sing-mux; the lever is off for this session"
}

// verifyMux proves the multiplexed session works instead of assuming it. It runs
// once per connect, only when multiplexing is on: whether a server agrees to
// something cannot be checked any other way, and a tunnel that silently moves
// nothing has to be able to name the lever that did it.
func (h *Host) verifyMux(ctx context.Context) {
	h.mu.Lock()
	enabled := h.settings.Smux.Enabled
	check := h.muxCheck
	h.mu.Unlock()
	if !enabled {
		return
	}
	if check == nil {
		check = func(ctx context.Context) error { return system.CheckEgress(ctx, muxEgressURL) }
	}
	probeCtx, cancel := context.WithTimeout(ctx, 2*muxProbeTimeout)
	defer cancel()
	// Two attempts: a tunnel that was up for a second can still be installing its
	// routes, and turning a working lever off on that would be worse than the wait.
	var err error
	for attempt := 0; attempt < 2; attempt++ {
		if attempt > 0 {
			time.Sleep(muxRetryDelay)
		}
		if err = check(probeCtx); err == nil {
			break
		}
	}
	disable, note := muxVerdict(enabled, err)
	h.logf(proto.LevelInfo, "%s", note)
	if !disable {
		return
	}
	h.mu.Lock()
	settings := h.settings.Clone()
	settings.Smux.Enabled = false
	h.settings = settings
	h.mu.Unlock()
	if !h.opMu.TryLock() {
		return
	}
	defer h.opMu.Unlock()
	h.mu.Lock()
	stillUp := h.state == proto.LinkConnected
	h.mu.Unlock()
	if !stillUp {
		// The user disconnected while the check was running: there is no session
		// left to fix, and restarting one would be a surprise.
		return
	}
	if err := h.restart(ctx); err != nil {
		h.logf(proto.LevelError, "mux: restart without it failed: %v", err)
	}
}

// Disconnect stops the core and releases the firewall.
func (h *Host) Disconnect(ctx context.Context) error {
	h.opMu.Lock()
	defer h.opMu.Unlock()
	return h.disconnect(ctx)
}

// disconnect assumes opMu is held.
func (h *Host) disconnect(ctx context.Context) error {
	h.mu.Lock()
	if h.state == proto.LinkDisconnected || h.state == proto.LinkStopping {
		h.mu.Unlock()
		return nil
	}
	h.state = proto.LinkStopping
	h.mu.Unlock()
	h.emitStatus()
	h.stopWatchdog()
	h.stopNetworkWatch()

	h.stopEngine()
	// Both tables go, whatever the kill-switch lever says: the guard belongs to a
	// live link, and leaving it behind would drop IPv6 DNS on a machine with no
	// tunnel at all.
	if err := h.fw.Flush(ctx); err != nil {
		h.logf(proto.LevelError, "firewall: %v", err)
	}

	h.mu.Lock()
	h.state = proto.LinkDisconnected
	h.lastStop = "user request"
	h.lastStopAt = time.Now()
	h.sample = proto.Sample{}
	h.mtuUsed = 0
	h.mu.Unlock()

	h.emitStatus()
	h.logf(proto.LevelInfo, "link: disconnected")
	return nil
}

// fail ends the link with a reason. It also takes the tunnel down: a failed link
// that keeps its TUN device and a kill-switch ruleset that is still dropping
// traffic is the machine with no network that reads as "the client broke my
// computer".
func (h *Host) fail(reason string) {
	h.stopWatchdog()
	h.stopNetworkWatch()
	h.mu.Lock()
	// Only a link that was up owns a TUN and a ruleset. A start that failed
	// already applied the crash policy itself.
	wasUp := h.state == proto.LinkConnected
	h.state = proto.LinkDisconnected
	h.lastStop = reason
	h.lastStopAt = time.Now()
	h.sample = proto.Sample{}
	h.mtuUsed = 0
	h.mu.Unlock()

	if wasUp {
		// A fresh context: fail is often reached from a cancelled one, and the
		// cleanup still has to run.
		ctx := context.Background()
		h.stopEngine()
		h.mu.Lock()
		keepRules := h.settings.KillSwitch.Enabled && h.settings.KillSwitch.OnCrash == "keep"
		h.mu.Unlock()
		if keepRules {
			// The user asked for a blocked machine when the core dies; that is a
			// decision, not a leftover to clean up.
			h.logf(proto.LevelWarn, "kill switch: ruleset kept after the link failed; traffic stays blocked")
		} else if err := h.fw.Flush(ctx); err != nil {
			h.logf(proto.LevelError, "firewall: %v", err)
		}
	}

	h.emitStatus()
	h.logf(proto.LevelError, "link: %s", reason)
}

// resolveServerAddrs turns the node address into every literal the firewall may
// need, in both families. The ruleset is `inet`, so its policy drops IPv6 as
// well: a v6-addressed server would be blocked by our own rules without it.
func resolveServerAddrs(ctx context.Context, host string) []string {
	return append(resolveIPv4(ctx, host), resolveIPv6(ctx, host)...)
}

// resolveIPv6 is resolveIPv4 for the other family. An IPv4-mapped literal is
// returned by resolveIPv4 instead, because nft expects it in an `ip` rule.
func resolveIPv6(ctx context.Context, host string) []string {
	if host == "" {
		return nil
	}
	if h, _, err := net.SplitHostPort(host); err == nil {
		host = h
	}
	host = strings.Trim(host, "[]")
	if ip := net.ParseIP(host); ip != nil {
		if ip.To4() != nil || ip.To16() == nil {
			return nil
		}
		return []string{ip.String()}
	}
	lookupCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	addrs, err := net.DefaultResolver.LookupIP(lookupCtx, "ip6", host)
	if err != nil {
		return nil
	}
	out := make([]string, 0, len(addrs))
	for _, a := range addrs {
		if a.To4() == nil && a.To16() != nil {
			out = append(out, a.String())
		}
	}
	return out
}

// resolveIPv4 turns the server host into literals the firewall can use. A name
// that does not resolve yields no addresses, which the ruleset reports as such.
//
// The input is sometimes an endpoint ("203.0.113.7:443") rather than a bare host,
// because both shapes exist in the settings. Taking the port for part of a name
// made the lookup fail, the ruleset was installed with zero allowed addresses,
// and the kill switch blocked the tunnel's own server: the link looked up while
// nothing loaded. The port is stripped here, once, instead of at four call sites.
func resolveIPv4(ctx context.Context, host string) []string {
	if host == "" {
		return nil
	}
	if h, _, err := net.SplitHostPort(host); err == nil {
		host = h
	}
	host = strings.Trim(host, "[]")
	if ip := net.ParseIP(host); ip != nil {
		if v4 := ip.To4(); v4 != nil {
			return []string{v4.String()}
		}
		return nil
	}
	lookupCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	addrs, err := net.DefaultResolver.LookupIP(lookupCtx, "ip4", host)
	if err != nil {
		return nil
	}
	out := make([]string, 0, len(addrs))
	for _, a := range addrs {
		if v4 := a.To4(); v4 != nil {
			out = append(out, v4.String())
		}
	}
	return out
}
