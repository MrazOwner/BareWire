// Package-level helpers for the host's own resource use. The core runs inside
// this process, so its RSS and CPU are the host's.
package host

import (
	"os"
	"strconv"
	"strings"
	"time"
)

// clockTicksPerSecond is the Linux userspace value of USER_HZ. It has been 100
// for every mainstream configuration for decades.
const clockTicksPerSecond = 100.0

// procMetrics is one reading of the host process.
type procMetrics struct {
	rssKB    uint64
	cpuTicks uint64
	at       time.Time
}

// readProcMetrics reads the process' resident memory and CPU time.
func readProcMetrics() procMetrics {
	m := procMetrics{at: time.Now()}
	if raw, err := os.ReadFile("/proc/self/status"); err == nil {
		for _, line := range strings.Split(string(raw), "\n") {
			if strings.HasPrefix(line, "VmRSS:") {
				fields := strings.Fields(line)
				if len(fields) >= 2 {
					if kb, err := strconv.ParseUint(fields[1], 10, 64); err == nil {
						m.rssKB = kb
					}
				}
				break
			}
		}
	}
	if raw, err := os.ReadFile("/proc/self/stat"); err == nil {
		// The command name sits in parentheses and may contain spaces, so the
		// fields are counted after the closing parenthesis.
		if idx := strings.LastIndex(string(raw), ")"); idx >= 0 {
			fields := strings.Fields(string(raw)[idx+1:])
			if len(fields) > 12 {
				utime, err1 := strconv.ParseUint(fields[11], 10, 64)
				stime, err2 := strconv.ParseUint(fields[12], 10, 64)
				if err1 == nil && err2 == nil {
					m.cpuTicks = utime + stime
				}
			}
		}
	}
	return m
}

// cpuPercentBetween turns two readings into a percentage of one core.
func cpuPercentBetween(prev, cur procMetrics) float64 {
	if prev.at.IsZero() || !cur.at.After(prev.at) || cur.cpuTicks < prev.cpuTicks {
		return 0
	}
	wall := cur.at.Sub(prev.at).Seconds()
	used := float64(cur.cpuTicks-prev.cpuTicks) / clockTicksPerSecond
	return used / wall * 100
}
