package host

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
	"github.com/mrazowner/barewire/internal/system"
)

// Apply stores the lever set and, when the link is up, restarts the core with it.
// Settings never wait for a reconnect: the change is the command.
func (h *Host) Apply(ctx context.Context, settings config.Settings) error {
	h.opMu.Lock()
	defer h.opMu.Unlock()
	settings.Normalize()
	h.mu.Lock()
	previous := h.settings
	h.settings = settings
	running := h.state == proto.LinkConnected
	h.mu.Unlock()

	if settings.KillSwitch.Enabled != previous.KillSwitch.Enabled {
		if settings.KillSwitch.Enabled && running {
			// The bare host, not the endpoint: the ruleset wants an address.
			allow := resolveServerAddrs(ctx, h.nodeAddress())
			if len(allow) == 0 {
				h.logf(proto.LevelError, "kill switch: no IPv4 address for the server, the ruleset would block the tunnel itself; not installed")
			} else if err := h.fw.Apply(ctx, true, allow, h.paths.TUNName); err != nil {
				h.logf(proto.LevelError, "kill switch: %v", err)
			}
		} else if !settings.KillSwitch.Enabled {
			if err := h.fw.Flush(ctx); err != nil {
				h.logf(proto.LevelError, "kill switch: %v", err)
			}
		}
	}
	if settings.Kernel != previous.Kernel {
		h.applyKernel(ctx, settings.Kernel)
	}

	if !running {
		h.emitStatus()
		h.logf(proto.LevelInfo, "settings applied (link down)")
		return nil
	}
	// A change that never reaches the core is not a reason to drop every
	// connection of a working tunnel. The theme, the kill-switch policies and the
	// network-change behaviour are applied above or read on demand; restarting
	// for them was the most expensive no-op in the program.
	if !settings.RequiresRestart(previous) {
		h.emitStatus()
		h.logf(proto.LevelInfo, "settings applied, the core is unchanged")
		return nil
	}
	if err := h.restart(ctx); err != nil {
		h.fail("restart failed: " + err.Error())
		return err
	}
	h.logf(proto.LevelInfo, "settings applied, core restarted")
	return nil
}

// Select stores the node and restarts the link when it is up.
func (h *Host) Select(ctx context.Context, node config.Node) error {
	h.opMu.Lock()
	defer h.opMu.Unlock()
	h.mu.Lock()
	h.node = node
	running := h.state == proto.LinkConnected
	h.mu.Unlock()

	h.emitStatus()
	if !running {
		h.logf(proto.LevelInfo, "node selected: %s", node.Endpoint())
		return nil
	}
	if err := h.restart(ctx); err != nil {
		h.fail("restart failed: " + err.Error())
		return err
	}
	h.logf(proto.LevelInfo, "node selected: %s", node.Endpoint())
	return nil
}

func (h *Host) restart(ctx context.Context) error {
	h.mu.Lock()
	settings := h.settings.Clone()
	node := h.node
	h.mu.Unlock()

	h.stopEngine()
	if err := h.startEngine(ctx, settings, node); err != nil {
		return err
	}
	h.mu.Lock()
	h.since = time.Now()
	h.reconnects++
	// A restart the user asked for starts with a full watchdog budget.
	h.wdRestarts = 0
	// A new instance starts from zero: the old counters belong to the old one.
	h.sample = proto.Sample{}
	h.mu.Unlock()
	h.emitStatus()
	return nil
}

// FlushKillSwitch removes the ruleset on demand.
func (h *Host) FlushKillSwitch(ctx context.Context) error {
	if err := h.fw.Flush(ctx); err != nil {
		return err
	}
	h.emitStatus()
	h.logf(proto.LevelInfo, "kill switch: ruleset flushed")
	return nil
}

// AutoMTU probes the path and stores the result for the next start. The answer
// is the tunnel's MTU, not the path's: the tunnel adds its own headers to every
// packet, and the interface writes what it gets here into the settings file.
func (h *Host) AutoMTU(ctx context.Context) (int, error) {
	h.mu.Lock()
	node := h.node
	h.mu.Unlock()
	if !node.Connectable() {
		return 0, errors.New("no node selected")
	}
	// The same probe the connect path uses: a UDP transport's server answers no
	// TCP handshake, and reading the MSS there could only fail.
	path, source := h.probePathMTU(ctx, node)
	if path <= 0 {
		return 0, errors.New("mtu probe: the path to the server could not be measured")
	}
	mtu := config.TunnelMTUCeiling(path, node.Kind)
	h.logf(proto.LevelInfo, "mtu probe: %s %d bytes, tunnel %d (%d bytes of overhead for %s)",
		source, path, mtu, config.OuterHeaderLen+config.TunnelOverhead(node.Kind), node.Kind)
	return mtu, nil
}

// AutoBrutal runs the throughput test.
func (h *Host) AutoBrutal(ctx context.Context) (int, int, error) {
	h.mu.Lock()
	running := h.state == proto.LinkConnected
	h.mu.Unlock()
	if !running {
		return 0, 0, errors.New("speed probe: connect first, the probe measures the path through the tunnel")
	}
	h.logf(proto.LevelInfo, "speed probe: measuring through the tunnel: %s", h.probe.DownURL)
	up, down, err := h.probe.Measure(ctx)
	if err != nil {
		h.logf(proto.LevelError, "speed probe: %v", err)
		return 0, 0, err
	}
	h.logf(proto.LevelInfo, "speed probe: up %d Mbit/s, down %d Mbit/s", up, down)
	return up, down, nil
}

// CleanupStep is one fact about a cleanup run.
type CleanupStep struct {
	What string
	Err  error
}

// Reset removes what a previous host left behind: the kill-switch ruleset and the
// TUN link. A host that was killed leaves both, and the ruleset keeps blocking
// the machine with no tunnel to carry the traffic, which reads as "the internet
// broke". The fakeip cache is deliberately kept: it is a cache, not leftovers.
func (h *Host) Reset(ctx context.Context) []CleanupStep {
	steps := make([]CleanupStep, 0, 2)
	if err := h.fw.Flush(ctx); err != nil {
		steps = append(steps, CleanupStep{What: "kill switch ruleset", Err: err})
	} else {
		steps = append(steps, CleanupStep{What: "kill switch ruleset"})
	}
	if err := system.RemoveLink(ctx, h.paths.TUNName); err != nil {
		steps = append(steps, CleanupStep{What: "tun link " + h.paths.TUNName, Err: err})
	} else {
		steps = append(steps, CleanupStep{What: "tun link " + h.paths.TUNName})
	}
	return steps
}

// Cleanup removes what a crashed host leaves behind: firewall rules, the TUN
// link with its routes, and the fakeip cache. It is safe to run at any time.
func (h *Host) Cleanup(ctx context.Context) []CleanupStep {
	steps := h.Reset(ctx)

	cache := filepath.Join(h.paths.StateDir, "cache.db")
	if err := os.Remove(cache); err != nil && !errors.Is(err, os.ErrNotExist) {
		steps = append(steps, CleanupStep{What: "fakeip cache " + cache, Err: err})
	} else {
		steps = append(steps, CleanupStep{What: "fakeip cache " + cache})
	}
	return steps
}

// Close releases everything the host holds.
func (h *Host) Close(ctx context.Context) error {
	h.opMu.Lock()
	defer h.opMu.Unlock()
	h.stopWatchdog()
	h.stopNetworkWatch()
	h.stopEngine()
	return h.fw.Flush(ctx)
}

func (h *Host) nodeAddress() string {
	h.mu.Lock()
	defer h.mu.Unlock()
	if !h.node.Connectable() {
		return ""
	}
	return h.node.Endpoint()
}

func (h *Host) currentSettings() config.Settings {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.settings
}
