package host

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
)

func testNode() config.Node {
	return config.Node{
		Name:    "de1",
		Kind:    "vless",
		Address: "127.0.0.1",
		Port:    1443,
		Outbound: json.RawMessage(`{"type":"vless","server":"127.0.0.1","server_port":1443,` +
			`"uuid":"11111111-2222-3333-4444-555555555555"}`),
	}
}

func newTestHost(t *testing.T) *Host {
	t.Helper()
	settings := config.Defaults()
	settings.MTU = 1420 // skip the probe: the test must not touch the network
	h := New(settings, Paths{StateDir: t.TempDir(), TUNName: "bwtest0"})
	t.Cleanup(func() { _ = h.Close(context.Background()) })
	return h
}

// A core that stops answering is replaced by the watchdog instead of leaving a
// dead tunnel labelled "connected" for the user to notice and fix by hand. When
// even the restart cannot work, the link ends with the reason.
func TestWatchdogEndsALinkItCannotHeal(t *testing.T) {
	oldInterval, oldGrace := watchdogInterval, watchdogGrace
	watchdogInterval, watchdogGrace = time.Millisecond, time.Millisecond
	defer func() { watchdogInterval, watchdogGrace = oldInterval, oldGrace }()

	h := newTestHost(t)
	h.mu.Lock()
	h.state = proto.LinkConnected
	h.node = config.Node{} // nothing to connect through: the restart must fail
	h.mu.Unlock()

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go h.watchCore(ctx)

	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if h.Status().State == proto.LinkDisconnected {
			if st := h.Status(); st.LastDisconnect == "" {
				t.Fatal("a link the watchdog ended must say why")
			}
			return
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatalf("the watchdog left the link %s", h.Status().State)
}

func TestStatusBeforeConnect(t *testing.T) {
	h := newTestHost(t)
	st := h.Status()
	if !st.HostRunning || st.State != proto.LinkDisconnected {
		t.Fatalf("status: %+v", st)
	}
	if st.TUNStack != config.TUNStackSingTun || st.MTU != 1420 || st.MTUSource != "manual" {
		t.Fatalf("tun facts: %+v", st)
	}
	if st.DNS.Mode != "fakeip" || len(st.DNS.Servers) == 0 {
		t.Fatalf("dns facts: %+v", st.DNS)
	}
	if st.KillSwitch.Enabled || st.KillSwitch.Active {
		t.Fatalf("kill switch must start off: %+v", st.KillSwitch)
	}
	if st.Server != "" || st.Protocol != "" || st.Outbound != "" {
		t.Fatalf("no node must mean no server facts: %+v", st)
	}
}

func TestStatusAfterSelect(t *testing.T) {
	h := newTestHost(t)
	if err := h.Select(context.Background(), testNode()); err != nil {
		t.Fatalf("select: %v", err)
	}
	st := h.Status()
	if st.Server != "127.0.0.1:1443" || st.Protocol != "vless" || st.Outbound != "proxy[vless]" {
		t.Fatalf("node facts: %+v", st)
	}
	if st.State != proto.LinkDisconnected {
		t.Fatalf("select must not connect: %+v", st.State)
	}
}

func TestConnectRequiresNode(t *testing.T) {
	h := newTestHost(t)
	if err := h.Connect(context.Background()); err == nil {
		t.Fatal("connect without a node must fail")
	}
	if st := h.Status(); st.State != proto.LinkDisconnected {
		t.Fatalf("state after failure: %s", st.State)
	}
}

func TestApplyUpdatesFacts(t *testing.T) {
	h := newTestHost(t)
	if err := h.Select(context.Background(), testNode()); err != nil {
		t.Fatalf("select: %v", err)
	}
	settings := config.Defaults()
	settings.MTU = 0
	settings.TUNStack = "mixed"
	settings.Smux.Enabled = true
	settings.Brutal = config.BrutalSettings{Enabled: true, UpMbps: 20, DownMbps: 90}
	settings.DNS.Mode = "direct"
	settings.DNS.Servers = []string{"9.9.9.9"}

	if err := h.Apply(context.Background(), settings); err != nil {
		t.Fatalf("apply: %v", err)
	}
	st := h.Status()
	if st.TUNStack != "mixed" || st.MTUSource != "auto" {
		t.Fatalf("tun facts: %+v", st)
	}
	if st.MTU != 1420 {
		t.Fatalf("default mtu = %d", st.MTU)
	}
	if !st.Smux.Enabled || st.Smux.Protocol != "smux" {
		t.Fatalf("smux facts: %+v", st.Smux)
	}
	// Brutal is a fact, not a wish: it is on only when the kernel provides the
	// brutal congestion control, which the tcp_brutal module does and a stock
	// kernel does not.
	if st.Brutal.Enabled != h.kernel.Offers("brutal") {
		t.Fatalf("brutal facts: %+v (kernel offers brutal: %v)", st.Brutal, h.kernel.Offers("brutal"))
	}
	if st.DNS.Mode != "direct" || st.DNS.Servers[0] != "9.9.9.9" {
		t.Fatalf("dns facts: %+v", st.DNS)
	}
}

// TestConnectFailureIsReported drives the real core start path. Without
// CAP_NET_ADMIN the TUN device cannot be created; the host must report that as a
// disconnect with a reason instead of pretending to be connected.
func TestConnectFailureIsReported(t *testing.T) {
	if os.Geteuid() == 0 {
		t.Skip("running as root: the TUN device may actually come up")
	}
	h := newTestHost(t)
	if err := h.Select(context.Background(), testNode()); err != nil {
		t.Fatalf("select: %v", err)
	}
	err := h.Connect(context.Background())
	if err == nil {
		t.Skip("core started; the environment allows TUN creation")
	}
	st := h.Status()
	if st.State != proto.LinkDisconnected {
		t.Fatalf("state after failure: %s", st.State)
	}
	if st.LastDisconnect == "" {
		t.Fatal("failure reason must be recorded as a fact")
	}
}

func TestCleanupRemovesLeftovers(t *testing.T) {
	dir := t.TempDir()
	cache := filepath.Join(dir, "cache.db")
	if err := os.WriteFile(cache, []byte("fakeip"), 0o600); err != nil {
		t.Fatal(err)
	}
	h := New(config.Defaults(), Paths{StateDir: dir, TUNName: "bwtest-cleanup"})

	steps := h.Cleanup(context.Background())
	if len(steps) != 3 {
		t.Fatalf("got %d steps: %+v", len(steps), steps)
	}
	if _, err := os.Stat(cache); !os.IsNotExist(err) {
		t.Fatalf("fakeip cache must be removed, stat err = %v", err)
	}
	for _, step := range steps {
		t.Logf("%s: %v", step.What, step.Err)
	}
}

func TestReadProcMetrics(t *testing.T) {
	m := readProcMetrics()
	if m.rssKB == 0 {
		t.Fatal("rss must be read from /proc/self/status")
	}
	if m.at.IsZero() {
		t.Fatal("the reading must be timestamped")
	}
}

func TestCPUPercentBetween(t *testing.T) {
	start := time.Now()
	prev := procMetrics{cpuTicks: 1000, at: start}
	// 50 ticks over 0.5 s = 0.5 s of CPU over 0.5 s of wall = 100%.
	cur := procMetrics{cpuTicks: 1050, at: start.Add(500 * time.Millisecond)}
	if got := cpuPercentBetween(prev, cur); got < 99 || got > 101 {
		t.Fatalf("cpu percent = %f, want ~100", got)
	}
	if got := cpuPercentBetween(procMetrics{}, cur); got != 0 {
		t.Fatalf("first reading must be 0, got %f", got)
	}
	if got := cpuPercentBetween(prev, procMetrics{cpuTicks: 10, at: start.Add(time.Second)}); got != 0 {
		t.Fatalf("a counter reset must not produce a negative value, got %f", got)
	}
}

func TestStatusCarriesResources(t *testing.T) {
	h := newTestHost(t)
	if st := h.Status(); st.MemRSSKB == 0 {
		t.Fatal("status must report the host's memory")
	}
}

func TestTransportFact(t *testing.T) {
	s := config.Defaults()
	if got := transportFact(s, "vless", "", false); got != "mux off, brutal off" {
		t.Fatalf("defaults: %q", got)
	}
	s.Smux.Enabled = true
	s.Smux.Protocol = "yamux"
	if got := transportFact(s, "vless", "", false); got != "mux yamux, brutal off" {
		t.Fatalf("smux: %q", got)
	}
	s.Brutal.Enabled = true
	s.Brutal.UpMbps, s.Brutal.DownMbps = 20, 90
	if got := transportFact(s, "vless", "", true); got != "mux yamux, brutal on 20/90" {
		t.Fatalf("brutal: %q", got)
	}
	// The lever can be on while nothing is carried: no multiplex section in the
	// protocol, or no brutal in the kernel.
	if got := transportFact(s, "tuic", "", true); got != "mux off, brutal off" {
		t.Fatalf("quic node: %q", got)
	}
	if got := transportFact(s, "vless", "", false); got != "mux yamux, brutal off (not available)" {
		t.Fatalf("no kernel support: %q", got)
	}
}

// A v6-addressed server has to be allowed in the kill switch too: the chain is
// `inet`, and its policy would otherwise drop the very connection the tunnel
// needs.
func TestResolveServerAddrsBothFamilies(t *testing.T) {
	got := resolveServerAddrs(context.Background(), "[2001:db8::1]:443")
	if len(got) != 1 || got[0] != "2001:db8::1" {
		t.Fatalf("v6 endpoint: %v", got)
	}
	got = resolveServerAddrs(context.Background(), "203.0.113.7:443")
	if len(got) != 1 || got[0] != "203.0.113.7" {
		t.Fatalf("v4 endpoint: %v", got)
	}
	// An IPv4-mapped literal belongs to the v4 rule, not the v6 one.
	if got := resolveIPv6(context.Background(), "::ffff:203.0.113.7"); len(got) != 0 {
		t.Fatalf("mapped v4 in v6 list: %v", got)
	}
}

func TestResolveIPv4(t *testing.T) {
	if got := resolveIPv4(context.Background(), "203.0.113.7"); len(got) != 1 || got[0] != "203.0.113.7" {
		t.Fatalf("literal: %v", got)
	}
	// The kill switch used to receive "host:port", fail to parse it as an address,
	// fail to resolve it as a name, and install a ruleset with no allowed server
	// at all: the tunnel died the moment the lever was flipped while connected.
	for _, endpoint := range []string{"203.0.113.7:443", "[::ffff:203.0.113.7]:443"} {
		if got := resolveIPv4(context.Background(), endpoint); len(got) != 1 || got[0] != "203.0.113.7" {
			t.Fatalf("%q: %v", endpoint, got)
		}
	}
	if got := resolveIPv4(context.Background(), ""); len(got) != 0 {
		t.Fatalf("empty: %v", got)
	}
	if got := resolveIPv4(context.Background(), "2001:db8::1"); len(got) != 0 {
		t.Fatalf("ipv6 must be excluded from a rule that only reads ip daddr: %v", got)
	}
}
