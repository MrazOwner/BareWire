package host

import (
	"strings"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
)

// The MTU written into the TUN decides whether large inner packets ever leave the
// machine. Three cases matter: a measured path caps the value, an unmeasured path
// cannot be used as an excuse to keep a number no encapsulation can carry, and a
// value that fits is left alone.
func TestMTUDecision(t *testing.T) {
	cases := []struct {
		name       string
		configured int
		path       int
		kind       string
		want       int
		wantLevel  proto.LogLevel
	}{
		{"auto with a measured path", 0, 1500, "vless", 1500 - 40 - 70, proto.LevelInfo},
		{"auto through hysteria2", 0, 1500, "hysteria2", 1500 - 40 - 100, proto.LevelInfo},
		{"auto with nothing measured", 0, 0, "vless", config.DefaultTunnelMTU, proto.LevelWarn},
		{"a value that fits", 1380, 1500, "vless", 1380, proto.LevelDebug},
		{"a value that does not fit", 1488, 1500, "vless", 1390, proto.LevelWarn},
		{
			// The bug this replaced: the probe failed, so 1488 was written into
			// the TUN unchanged and every large packet was dropped by the path.
			"too large and nothing measured",
			1488, 0, "vless", config.MaxTunnelMTU, proto.LevelWarn,
		},
		{"the ceiling itself is fine", config.MaxTunnelMTU, 0, "vless", config.MaxTunnelMTU, proto.LevelDebug},
		{"a jumbo path is still capped", 0, 9000, "vless", config.MaxTunnelMTU, proto.LevelInfo},
		{"a tiny path floors at the minimum", 0, 1200, "vless", config.MinTunnelMTU, proto.LevelInfo},
	}
	for _, c := range cases {
		mtu, note := mtuDecision(c.configured, c.path, c.kind)
		if mtu != c.want {
			t.Errorf("%s: mtu = %d, want %d", c.name, mtu, c.want)
		}
		if note.level != c.wantLevel {
			t.Errorf("%s: level = %q, want %q (%s)", c.name, note.level, c.wantLevel, note.text)
		}
		if !strings.HasPrefix(note.text, "mtu: ") {
			t.Errorf("%s: note %q does not read like the log line it becomes", c.name, note.text)
		}
	}
}

// A note that lowers the value has to name both numbers, otherwise the reader
// cannot tell what was asked for and what the tunnel actually got.
func TestMTUDecisionExplainsALoweredValue(t *testing.T) {
	mtu, note := mtuDecision(1488, 1500, "vless")
	if mtu != 1390 {
		t.Fatalf("mtu = %d, want 1390", mtu)
	}
	if !strings.Contains(note.text, "1488") || !strings.Contains(note.text, "1390") {
		t.Fatalf("note %q has to name the value asked for and the one used", note.text)
	}
}
