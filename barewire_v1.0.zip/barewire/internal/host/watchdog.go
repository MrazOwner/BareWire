package host

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/core"
	"github.com/mrazowner/barewire/internal/proto"
)

// The watchdog is the difference between "reconnect every ten minutes" and a
// client that looks after itself. A core whose own API has stopped answering is
// wedged: the process is alive, the TUN still exists, the status still says
// "connected", and nothing loads. The only cure is a new instance, and waiting
// for the user to press the same key every time is not a feature.
var (
	// watchdogInterval is how often the core is looked at.
	watchdogInterval = 5 * time.Second
	// watchdogGrace is how long a silent core is given before it is replaced.
	// Long enough that a burst of load is not mistaken for a wedge, short enough
	// that the user notices the recovery instead of the outage.
	watchdogGrace = 30 * time.Second
)

const (
	// watchdogLimit is how many restarts one link gets before the watchdog stops
	// pretending: after that the link is reported as failed, with the reason.
	watchdogLimit = 3
	// watchdogStable is how long a restarted core has to keep answering before
	// its restart budget is refilled. A link that wedges once a day is not a link
	// that needs a different stack.
	watchdogStable = 5 * time.Minute
	// stopWait bounds how long a stop may take. A wedged core is exactly the case
	// this exists for: a Close that never returns would leave the watchdog with no
	// way to start a new instance.
	stopWait = 20 * time.Second
)

// startWatchdog makes sure exactly one watchdog is looking at the core.
func (h *Host) startWatchdog() {
	h.mu.Lock()
	if h.wdCancel != nil {
		h.wdCancel()
		h.wdCancel = nil
	}
	h.wdRestarts = 0
	ctx, cancel := context.WithCancel(context.Background())
	h.wdCancel = cancel
	h.mu.Unlock()
	go h.watchCore(ctx)
}

// stopWatchdog ends the watchdog; safe when it never started.
func (h *Host) stopWatchdog() {
	h.mu.Lock()
	cancel := h.wdCancel
	h.wdCancel = nil
	h.mu.Unlock()
	if cancel != nil {
		cancel()
	}
}

// watchCore restarts a core that stopped answering, and says what it did.
func (h *Host) watchCore(ctx context.Context) {
	ticker := time.NewTicker(watchdogInterval)
	defer ticker.Stop()

	var silentSince time.Time
	stableSince := time.Now()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			h.mu.Lock()
			live := h.state == proto.LinkConnected
			h.mu.Unlock()
			if !live {
				return
			}
			if h.engine.Healthy() {
				if !silentSince.IsZero() {
					silentSince = time.Time{}
					h.logf(proto.LevelInfo, "core: answered again before the watchdog acted")
				}
				if time.Since(stableSince) >= watchdogStable {
					h.mu.Lock()
					h.wdRestarts = 0
					h.mu.Unlock()
					stableSince = time.Now()
				}
				continue
			}
			if silentSince.IsZero() {
				silentSince = time.Now()
				h.logf(proto.LevelWarn, "core: not answering, the watchdog is giving it %s", watchdogGrace)
				continue
			}
			if time.Since(silentSince) < watchdogGrace {
				continue
			}
			h.healCore(ctx)
			silentSince = time.Time{}
			stableSince = time.Now()
		}
	}
}

// healCore replaces a wedged core. The second attempt onwards also drops the
// newest, least proven parts of the transport: the sing-box 1.15 TUN stack is an
// alpha, and a link that wedges twice on it is better served by the stack that
// has carried traffic for years — with the fact in the log, not in a support
// forum.
func (h *Host) healCore(ctx context.Context) {
	if !h.opMu.TryLock() {
		// A connect, apply or disconnect is in flight. The next tick retries, and
		// interrupting a working operation to fix an outage that may already be
		// over would be worse than waiting.
		h.logf(proto.LevelWarn, "core: not answering, but another operation is in flight; waiting")
		return
	}
	defer h.opMu.Unlock()

	h.mu.Lock()
	state := h.state
	budget := h.wdRestarts
	settings := h.settings.Clone()
	h.mu.Unlock()
	if state != proto.LinkConnected {
		return
	}
	if budget >= watchdogLimit {
		reason := fmt.Sprintf("core: stopped answering %d times; the link is not usable", budget)
		h.logf(proto.LevelError, "%s", reason)
		h.fail(reason)
		return
	}
	attempt := budget + 1
	if attempt >= 2 && settings.TUNStack == config.TUNStackSingTun {
		settings.TUNStack = "mixed"
		settings.MultiQueue = false
		h.logf(proto.LevelWarn, "core: the sing-tun stack wedged twice, retrying with the mixed stack and multi-queue off (for this session; the settings file is unchanged)")
	}
	h.logf(proto.LevelWarn, "core: not answering for %s, restarting it (%d/%d)", watchdogGrace, attempt, watchdogLimit)

	err := h.restartWith(ctx, settings)
	h.mu.Lock()
	h.wdRestarts = attempt
	h.mu.Unlock()
	if err != nil {
		h.fail("watchdog restart failed: " + err.Error())
		return
	}
	h.logf(proto.LevelInfo, "core: restarted after it stopped answering")
}

// restartWith restarts the core with a lever set that is not the stored one.
// The watchdog uses it to try a safer stack; the settings file is left alone, so
// the next Apply from the interface puts the user's choice back in charge.
func (h *Host) restartWith(ctx context.Context, settings config.Settings) error {
	h.mu.Lock()
	h.settings = settings
	h.mu.Unlock()
	return h.restart(ctx)
}

// stopEngine stops the core without waiting forever. A core that is wedged is
// exactly the case where Close can hang, and a hung Close would leave the
// watchdog unable to start a new instance — the failure it exists to fix.
func (h *Host) stopEngine() {
	done := make(chan error, 1)
	go func() { done <- h.engine.Stop() }()
	select {
	case err := <-done:
		if err != nil && !errors.Is(err, core.ErrNotRunning) {
			h.logf(proto.LevelError, "core: %v", err)
		}
	case <-time.After(stopWait):
		h.logf(proto.LevelError, "core: stopping it did not finish in %s; a new instance starts anyway", stopWait)
	}
}
