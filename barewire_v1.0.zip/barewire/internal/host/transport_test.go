package host

import (
	"context"
	"strings"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
)

// The status and the start line have to describe the same transport: what the
// core really carries. Brutal is the case that used to be wrong in both, because
// it turns multiplexing on by itself and always rides on smux.
func TestCarriedTransport(t *testing.T) {
	base := config.Defaults()
	base.Smux.Protocol = "yamux"

	cases := []struct {
		name    string
		edit    func(*config.Settings)
		kind    string
		brutalO bool
		wantMux bool
		wantPr  string
		wantBr  bool
	}{
		{
			name: "nothing on", edit: func(*config.Settings) {}, kind: "vless",
			wantMux: false, wantPr: "yamux",
		},
		{
			name: "smux on", edit: func(s *config.Settings) { s.Smux.Enabled = true }, kind: "vless",
			wantMux: true, wantPr: "yamux",
		},
		{
			// The bug: the status required the smux lever to be on before it
			// would even look at Brutal, so a working Brutal link read as off.
			name: "brutal alone turns mux on, on smux",
			edit: func(s *config.Settings) { s.Brutal.Enabled = true },
			kind: "vless", brutalO: true,
			wantMux: true, wantPr: "smux", wantBr: true,
		},
		{
			name: "brutal over the chosen protocol",
			edit: func(s *config.Settings) { s.Brutal.Enabled = true; s.Smux.Enabled = true },
			kind: "vless", brutalO: true,
			wantMux: true, wantPr: "yamux", wantBr: true,
		},
		{
			name: "brutal the kernel cannot run",
			edit: func(s *config.Settings) { s.Brutal.Enabled = true },
			kind: "vless", brutalO: false,
			wantMux: false, wantPr: "yamux",
		},
		{
			// TUIC and Hysteria2 reject a multiplex section: the config would not
			// even decode, so nothing may be claimed for them.
			name: "a transport without a multiplex section",
			edit: func(s *config.Settings) { s.Smux.Enabled = true; s.Brutal.Enabled = true },
			kind: "hysteria2", brutalO: true,
			wantMux: false, wantPr: "yamux",
		},
	}
	for _, c := range cases {
		settings := base
		c.edit(&settings)
		mux, protocol, brutal := carriedTransport(settings, c.kind, "", c.brutalO)
		if mux != c.wantMux || protocol != c.wantPr || brutal != c.wantBr {
			t.Errorf("%s: carriedTransport() = (%v, %q, %v), want (%v, %q, %v)",
				c.name, mux, protocol, brutal, c.wantMux, c.wantPr, c.wantBr)
		}
	}
}

// The line the log keeps has to name the protocol the core actually runs: with
// Brutal on and the smux lever off it is smux, not whatever the lever said.
func TestTransportFactNamesTheProtocolInUse(t *testing.T) {
	s := config.Defaults()
	s.Smux.Protocol = "yamux"
	s.Brutal = config.BrutalSettings{Enabled: true, UpMbps: 20, DownMbps: 90}
	fact := transportFact(s, "vless", "", true)
	if !strings.Contains(fact, "mux smux") {
		t.Fatalf("fact = %q, want it to say mux smux", fact)
	}
	if !strings.Contains(fact, "brutal on 20/90") {
		t.Fatalf("fact = %q, want the brutal rates", fact)
	}
	if fact := transportFact(s, "vless", "", false); !strings.Contains(fact, "brutal off (not available)") {
		t.Fatalf("fact = %q, want brutal reported as unavailable", fact)
	}
	if fact := transportFact(config.Defaults(), "hysteria2", "", true); !strings.Contains(fact, "mux off") {
		t.Fatalf("fact = %q, want no mux for hysteria2", fact)
	}
}

// A measured MTU is what the interface asked for, not a value that was lowered:
// comparing it against a zero setting labelled every auto link "lowered to fit
// the path".
func TestStatusMTUSource(t *testing.T) {
	settings := config.Defaults()
	settings.MTU = 0
	h := New(settings, Paths{StateDir: t.TempDir(), TUNName: "bwtest0"})
	t.Cleanup(func() { _ = h.Close(context.Background()) })

	h.mu.Lock()
	h.mtuUsed = 1390
	h.mu.Unlock()
	st := h.Status()
	if st.MTUSource != "auto" || st.MTU != 1390 {
		t.Fatalf("auto link: mtu %d (%s), want 1390 (auto)", st.MTU, st.MTUSource)
	}

	h.mu.Lock()
	h.settings.MTU = 1488
	h.mu.Unlock()
	st = h.Status()
	if st.MTUSource != "lowered to fit the path" || st.MTU != 1390 {
		t.Fatalf("lowered link: mtu %d (%s), want 1390 (lowered)", st.MTU, st.MTUSource)
	}

	h.mu.Lock()
	h.mtuUsed = 1488
	h.mu.Unlock()
	if st := h.Status(); st.MTUSource != "manual" || st.MTU != 1488 {
		t.Fatalf("manual link: mtu %d (%s), want 1488 (manual)", st.MTU, st.MTUSource)
	}
}
