// Package version holds the build identity of every Barewire binary. Build is
// replaced at link time with the commit hash, or stays "dev" outside a checkout.
package version

import (
	"runtime/debug"
	"strings"
)

// Version is the release number of the whole program.
const Version = "0.1.0"

// Build is the build identity, set with -ldflags.
var Build = "dev"

// String renders the identity shown by -version and in the log.
func String() string {
	return Version + " (" + Build + ")"
}

// Core is the identity of the embedded sing-box, read from the build info so
// that it cannot drift from go.mod. A hardcoded string in the host said 1.14
// while the binary carried 1.15, and the interface reported the string.
func Core() string {
	info, ok := debug.ReadBuildInfo()
	if !ok {
		return "sing-box"
	}
	for _, dep := range info.Deps {
		if dep.Path != "github.com/sagernet/sing-box" {
			continue
		}
		if dep.Replace != nil {
			dep = dep.Replace
		}
		return "sing-box " + strings.TrimPrefix(dep.Version, "v")
	}
	return "sing-box"
}
