// Package hostsock is the wire between the unprivileged interface and the
// privileged host. One unix socket, newline-delimited JSON frames, peer-uid
// checked on every connection.
package hostsock

import (
	"bufio"
	"context"
	"errors"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
)

// Handler is everything the host can be asked to do. It is deliberately equal
// to what the interface can press, no more.
type Handler interface {
	Status() proto.Status
	Connect(ctx context.Context) error
	Disconnect(ctx context.Context) error
	Apply(ctx context.Context, settings config.Settings) error
	Select(ctx context.Context, node config.Node) error
	FlushKillSwitch(ctx context.Context) error
	AutoMTU(ctx context.Context) (int, error)
	AutoBrutal(ctx context.Context) (int, int, error)
	TestKernel(ctx context.Context) ([]proto.KernelTrial, error)
	Connections() []proto.Connection
}

// Server serves the host socket.
type Server struct {
	path        string
	h           Handler
	ln          net.Listener
	mu          sync.Mutex
	clients     map[*client]struct{}
	done        chan struct{}
	closeOnce   sync.Once
	onShutdown  func()
	expectedUID int
}

type client struct {
	conn    net.Conn
	out     chan proto.Message
	done    chan struct{}
	once    sync.Once
	writeMu sync.Mutex
}

// Listen binds the socket for the current user.
func Listen(path string, h Handler) (*Server, error) {
	return ListenAs(path, h, os.Getuid(), os.Getgid())
}

// ListenAs binds the socket for a specific user. When the host runs elevated for
// another user, the socket directory and the socket itself are handed to that
// user, otherwise that user cannot traverse the directory or dial the socket.
func ListenAs(path string, h Handler, uid, gid int) (*Server, error) {
	dir := filepath.Dir(path)
	if err := config.EnsureDir(dir); err != nil {
		return nil, err
	}
	if uid != os.Getuid() {
		if err := os.Chown(dir, uid, gid); err != nil {
			return nil, fmt.Errorf("hostsock: hand %s to uid %d: %w", dir, uid, err)
		}
	}
	// A socket file that answers belongs to a live host. Removing it would hand
	// the new process the machine while the old one still holds the TUN device,
	// the firewall and the levers: both would fight and the link would drop for
	// no visible reason. A stale file, one nobody answers on, is removed below.
	if _, err := os.Stat(path); err == nil {
		if conn, dialErr := net.DialTimeout("unix", path, 250*time.Millisecond); dialErr == nil {
			_ = conn.Close()
			return nil, fmt.Errorf("hostsock: %s is already served by another host", path)
		}
	}
	if err := os.Remove(path); err != nil && !errors.Is(err, os.ErrNotExist) {
		return nil, fmt.Errorf("hostsock: remove stale socket: %w", err)
	}
	ln, err := net.Listen("unix", path)
	if err != nil {
		return nil, fmt.Errorf("hostsock: listen %s: %w", path, err)
	}
	if err := os.Chmod(path, 0o600); err != nil {
		_ = ln.Close()
		return nil, fmt.Errorf("hostsock: chmod socket: %w", err)
	}
	if uid != os.Getuid() {
		if err := os.Chown(path, uid, gid); err != nil {
			_ = ln.Close()
			return nil, fmt.Errorf("hostsock: hand socket to uid %d: %w", uid, err)
		}
	}
	return &Server{
		path:        path,
		h:           h,
		ln:          ln,
		clients:     make(map[*client]struct{}),
		done:        make(chan struct{}),
		expectedUID: uid,
	}, nil
}

// Path is the socket path.
func (s *Server) Path() string { return s.path }

// OnShutdown registers the callback for an explicit shutdown request.
func (s *Server) OnShutdown(fn func()) { s.onShutdown = fn }

// expectedPeer is the uid allowed to talk to this host, read under the lock so a
// test or a future reload can change it without racing the accept loop.
func (s *Server) expectedPeer() uint32 {
	s.mu.Lock()
	defer s.mu.Unlock()
	return uint32(s.expectedUID)
}

// Serve accepts connections until Close. Each connection runs in its own
// goroutines: a stalled client must never stall the core.
func (s *Server) Serve() error {
	for {
		conn, err := s.ln.Accept()
		if err != nil {
			select {
			case <-s.done:
				return nil
			default:
				return fmt.Errorf("hostsock: accept: %w", err)
			}
		}
		if uid, err := peerUID(conn); err != nil || uid != s.expectedPeer() {
			_ = conn.Close()
			continue
		}
		c := &client{conn: conn, out: make(chan proto.Message, 256), done: make(chan struct{})}
		if !s.addClient(c) {
			_ = conn.Close()
			continue
		}
		go c.writeLoop()
		go s.readLoop(c)
	}
}

func (s *Server) addClient(c *client) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	select {
	case <-s.done:
		return false
	default:
	}
	s.clients[c] = struct{}{}
	return true
}

func (s *Server) removeClient(c *client) {
	s.mu.Lock()
	delete(s.clients, c)
	s.mu.Unlock()
	c.close()
}

// Publish pushes an event to every connected client. A client that cannot keep
// up loses events instead of blocking the host.
func (s *Server) Publish(ev proto.Event) {
	msg, err := proto.EventMessage(ev)
	if err != nil {
		return
	}
	s.mu.Lock()
	clients := make([]*client, 0, len(s.clients))
	for c := range s.clients {
		clients = append(clients, c)
	}
	s.mu.Unlock()
	for _, c := range clients {
		select {
		case c.out <- msg:
		default:
		}
	}
}

// Close stops the server and removes the socket file.
func (s *Server) Close() error {
	var err error
	s.closeOnce.Do(func() {
		close(s.done)
		s.mu.Lock()
		clients := make([]*client, 0, len(s.clients))
		for c := range s.clients {
			clients = append(clients, c)
		}
		s.clients = map[*client]struct{}{}
		s.mu.Unlock()

		err = s.ln.Close()
		for _, c := range clients {
			c.close()
		}
		_ = os.Remove(s.path)
		if errors.Is(err, net.ErrClosed) {
			err = nil
		}
	})
	return err
}

func (c *client) close() {
	c.once.Do(func() {
		close(c.done)
		_ = c.conn.Close()
	})
}

func (c *client) write(msg proto.Message) error {
	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	w := bufio.NewWriter(c.conn)
	if err := proto.Encode(w, msg); err != nil {
		return err
	}
	return w.Flush()
}

func (c *client) writeLoop() {
	for {
		select {
		case <-c.done:
			return
		case msg := <-c.out:
			if err := c.write(msg); err != nil {
				c.close()
				return
			}
		}
	}
}

func (s *Server) readLoop(c *client) {
	defer s.removeClient(c)
	reader := bufio.NewReader(c.conn)
	for {
		msg, err := proto.Decode(reader)
		if err != nil {
			return
		}
		if msg.Method != MethodShutdown {
			// One request at a time per connection would let a two minute kernel
			// trial block the status poll, the log stream and every lever behind
			// it: the interface would freeze while the host was working. Each
			// request gets its own goroutine and its reply goes through the same
			// ordered queue as the events.
			go func(msg proto.Message) {
				reply, _ := s.dispatch(msg)
				if reply == nil {
					return
				}
				select {
				case c.out <- *reply:
				case <-c.done:
				}
			}(msg)
			continue
		}
		// Shutdown is answered inline: the connection is about to end, so the
		// reply must not wait in the queue behind anything.
		reply, stop := s.dispatch(msg)
		if reply != nil {
			_ = c.write(*reply)
		}
		if stop {
			if s.onShutdown != nil {
				s.onShutdown()
			}
			return
		}
	}
}
