package hostsock

import (
	"context"
	"fmt"
	"net"
	"sync"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/hostclient"
	"github.com/mrazowner/barewire/internal/proto"
)

// callTimeout bounds one ordinary request. A host that cannot answer in ten
// seconds is not answering.
const callTimeout = 10 * time.Second

// startTimeout bounds the calls that bring the link up. They measure the path,
// resolve the server, install the firewall and start the core, so ten seconds is
// not enough: the call used to time out while the host was still working, the
// interface reported an error, and the tunnel came up anyway. The work is the
// answer, not a sign of a dead host.
const startTimeout = 90 * time.Second

// trialTimeout bounds the calls that measure the path. They run for minutes by
// design — seventeen algorithms, or a 24 MiB throughput probe — and the ordinary
// cap made every one of them fail with "timed out" while the host was still
// working.
const trialTimeout = 15 * time.Minute

// probeTimeout bounds one throughput measurement: 16 MiB down and 8 MiB up over a
// slow link is minutes, not seconds.
const probeTimeout = 5 * time.Minute

// Client is the interface side of the socket. It implements
// hostclient.Client, so the screens stay unchanged when the mock is replaced.
type Client struct {
	conn net.Conn

	writeMu sync.Mutex
	mu      sync.Mutex
	pending map[string]chan proto.Message
	nextID  int
	status  proto.Status

	events    chan proto.Event
	done      chan struct{}
	closeOnce sync.Once
}

var _ hostclient.Client = (*Client)(nil)

// Dial connects to a running host.
func Dial(path string) (*Client, error) {
	conn, err := net.Dial("unix", path)
	if err != nil {
		return nil, fmt.Errorf("hostsock: dial %s: %w", path, err)
	}
	c := &Client{
		conn:    conn,
		pending: make(map[string]chan proto.Message),
		events:  make(chan proto.Event, 256),
		done:    make(chan struct{}),
	}
	go c.readLoop()

	ctx, cancel := context.WithTimeout(context.Background(), callTimeout)
	defer cancel()
	var st proto.Status
	if err := c.call(ctx, MethodStatus, nil, &st); err != nil {
		_ = c.Close()
		return nil, err
	}
	c.mu.Lock()
	c.status = st
	c.mu.Unlock()
	return c, nil
}

// Snapshot implements hostclient.Client.
func (c *Client) Snapshot() proto.Status {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.status
}

// Events implements hostclient.Client.
func (c *Client) Events() <-chan proto.Event { return c.events }

// Connect implements hostclient.Client.
func (c *Client) Connect() error {
	return c.callRequestTimeout(MethodConnect, nil, nil, startTimeout)
}

// Disconnect implements hostclient.Client.
func (c *Client) Disconnect() error {
	return c.callRequestTimeout(MethodDisconnect, nil, nil, startTimeout)
}

// Apply implements hostclient.Client.
func (c *Client) Apply(settings config.Settings) error {
	return c.callRequestTimeout(MethodApply, settings, nil, startTimeout)
}

// SelectNode implements hostclient.Client.
func (c *Client) SelectNode(node config.Node) error {
	return c.callRequestTimeout(MethodSelect, node, nil, startTimeout)
}

// FlushKillSwitch implements hostclient.Client.
func (c *Client) FlushKillSwitch() error { return c.callRequest(MethodFlushKill, nil, nil) }

// AutoMTU implements hostclient.Client.
func (c *Client) AutoMTU() (int, error) {
	var out struct {
		MTU int `json:"mtu"`
	}
	if err := c.callRequest(MethodAutoMTU, nil, &out); err != nil {
		return 0, err
	}
	return out.MTU, nil
}

// AutoBrutal implements hostclient.Client.
func (c *Client) AutoBrutal() (int, int, error) {
	var out struct {
		Up   int `json:"up_mbps"`
		Down int `json:"down_mbps"`
	}
	if err := c.callRequestTimeout(MethodAutoBrutal, nil, &out, probeTimeout); err != nil {
		return 0, 0, err
	}
	return out.Up, out.Down, nil
}

// TestKernel implements hostclient.Client.
func (c *Client) TestKernel() ([]proto.KernelTrial, error) {
	var out struct {
		Trials []proto.KernelTrial `json:"trials"`
	}
	if err := c.callRequestTimeout(MethodKernelTest, nil, &out, trialTimeout); err != nil {
		return nil, err
	}
	return out.Trials, nil
}

// Connections implements hostclient.Client.
func (c *Client) Connections() []proto.Connection {
	var out []proto.Connection
	if err := c.callRequest(MethodConnections, nil, &out); err != nil {
		return nil
	}
	return out
}

// Shutdown tells the host to exit. This is the only way a host process stops
// itself: nothing runs in the background waiting for a client.
func (c *Client) Shutdown() error {
	return c.callRequest(MethodShutdown, nil, nil)
}

// Close disconnects from the host. The host keeps running: it is stopped by an
// explicit shutdown, not by a closed window.
func (c *Client) Close() error {
	c.closeOnce.Do(func() {
		close(c.done)
		_ = c.conn.Close()
	})
	return nil
}

func (c *Client) callRequest(method string, payload, out any) error {
	return c.callRequestTimeout(method, payload, out, callTimeout)
}

// callRequestTimeout is callRequest with a bound that suits a long measurement.
func (c *Client) callRequestTimeout(method string, payload, out any, timeout time.Duration) error {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	return c.call(ctx, method, payload, out)
}
