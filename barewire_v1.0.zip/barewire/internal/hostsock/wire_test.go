package hostsock

import (
	"context"
	"errors"
	"net"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
)

// A live socket belongs to a running host: the second process must refuse, not
// steal it, or both fight over the TUN device and the link drops for no reason.
func TestListenRefusesALiveSocket(t *testing.T) {
	host := &fakeHost{status: proto.Status{HostRunning: true}}
	srv, path, _ := startTestServer(t, host)
	defer func() { _ = srv.Close() }()

	if _, err := ListenAs(path, host, os.Getuid(), os.Getgid()); err == nil {
		t.Fatal("a socket that answers must not be taken over")
	} else if !strings.Contains(err.Error(), "already served") {
		t.Fatalf("error = %v", err)
	}
}

// A file nobody answers on is stale and must be replaced, not reported.
func TestListenReplacesAStaleFile(t *testing.T) {
	dir := t.TempDir()
	path := dir + "/host.sock"
	if err := os.WriteFile(path, []byte("stale"), 0o600); err != nil {
		t.Fatal(err)
	}
	srv, err := ListenAs(path, &fakeHost{status: proto.Status{HostRunning: true}}, os.Getuid(), os.Getgid())
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	_ = srv.Close()
}

func TestClientServerRoundTrip(t *testing.T) {
	host := &fakeHost{
		status: proto.Status{HostRunning: true, State: proto.LinkDisconnected},
		mtu:    1400,
		up:     50,
		down:   200,
		conns:  []proto.Connection{{ID: 7, Host: "example.org:443"}},
	}
	_, path, _ := startTestServer(t, host)
	client := dialTest(t, path)

	if got := client.Snapshot(); !got.HostRunning || got.State != proto.LinkDisconnected {
		t.Fatalf("snapshot: %+v", got)
	}
	if err := client.Connect(); err != nil {
		t.Fatalf("connect: %v", err)
	}
	host.mu.Lock()
	connected := host.connected
	host.mu.Unlock()
	if !connected {
		t.Fatal("connect did not reach the host")
	}

	settings := config.Defaults()
	settings.MTU = 1280
	if err := client.Apply(settings); err != nil {
		t.Fatalf("apply: %v", err)
	}
	host.mu.Lock()
	gotMTU := host.settings.MTU
	host.mu.Unlock()
	if gotMTU != 1280 {
		t.Fatalf("applied mtu = %d", gotMTU)
	}

	if err := client.SelectNode(config.Node{Name: "de1", Address: "de1.example.net", Port: 443}); err != nil {
		t.Fatalf("select: %v", err)
	}
	host.mu.Lock()
	node := host.node
	host.mu.Unlock()
	if node.Name != "de1" {
		t.Fatalf("node = %+v", node)
	}

	if mtu, err := client.AutoMTU(); err != nil || mtu != 1400 {
		t.Fatalf("auto mtu = %d, %v", mtu, err)
	}
	if up, down, err := client.AutoBrutal(); err != nil || up != 50 || down != 200 {
		t.Fatalf("auto brutal = %d/%d, %v", up, down, err)
	}
	if conns := client.Connections(); len(conns) != 1 || conns[0].Host != "example.org:443" {
		t.Fatalf("connections: %+v", conns)
	}
	if err := client.FlushKillSwitch(); err != nil {
		t.Fatalf("flush: %v", err)
	}
	if err := client.Disconnect(); err != nil {
		t.Fatalf("disconnect: %v", err)
	}
	host.mu.Lock()
	flushed := host.flushed
	host.mu.Unlock()
	if !flushed {
		t.Fatal("flush did not reach the host")
	}
}

func TestEventsReachTheClient(t *testing.T) {
	host := &fakeHost{status: proto.Status{HostRunning: true}}
	srv, path, _ := startTestServer(t, host)
	client := dialTest(t, path)

	entry := proto.LogEntry{Level: proto.LevelWarn, Source: "tun", Text: "gso disabled"}
	srv.Publish(proto.Event{Type: proto.EventLog, Log: &entry})

	select {
	case ev := <-client.Events():
		if ev.Type != proto.EventLog || ev.Log == nil || ev.Log.Text != "gso disabled" {
			t.Fatalf("event: %+v", ev)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("event did not arrive")
	}

	status := proto.Status{HostRunning: true, State: proto.LinkConnected, Server: "de1.example.net:443"}
	srv.Publish(proto.Event{Type: proto.EventStatus, Status: &status})
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		if client.Snapshot().State == proto.LinkConnected {
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatal("status event did not update the snapshot")
}

func TestHostErrorIsReturned(t *testing.T) {
	host := &fakeHost{status: proto.Status{HostRunning: true}, err: errors.New("no node selected")}
	_, path, _ := startTestServer(t, host)
	client := dialTest(t, path)
	err := client.Connect()
	if err == nil || !strings.Contains(err.Error(), "no node selected") {
		t.Fatalf("err = %v", err)
	}
}

func TestForeignPeerIsRefused(t *testing.T) {
	host := &fakeHost{status: proto.Status{HostRunning: true}}
	srv, path, _ := startTestServer(t, host)
	// Pretend the host serves another user: every connection must be dropped
	// before a single byte is answered.
	srv.mu.Lock()
	srv.expectedUID = os.Getuid() + 1
	srv.mu.Unlock()

	conn, err := net.Dial("unix", path)
	if err != nil {
		t.Fatalf("dial: %v", err)
	}
	defer func() { _ = conn.Close() }()
	if err := conn.SetReadDeadline(time.Now().Add(2 * time.Second)); err != nil {
		t.Fatal(err)
	}
	buf := make([]byte, 1)
	if _, err := conn.Read(buf); err == nil {
		t.Fatal("a connection from another uid must be closed, not served")
	}
}

func TestShutdownCallback(t *testing.T) {
	host := &fakeHost{status: proto.Status{HostRunning: true}}
	_, path, shutdown := startTestServer(t, host)
	client := dialTest(t, path)

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	if err := client.call(ctx, MethodShutdown, nil, nil); err != nil {
		t.Fatalf("shutdown: %v", err)
	}
	select {
	case <-shutdown:
	case <-time.After(2 * time.Second):
		t.Fatal("shutdown callback not called")
	}
}

func TestUnknownMethodFails(t *testing.T) {
	host := &fakeHost{status: proto.Status{HostRunning: true}}
	_, path, _ := startTestServer(t, host)
	client := dialTest(t, path)
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	err := client.call(ctx, "self-destruct", nil, nil)
	if err == nil || !strings.Contains(err.Error(), "unknown method") {
		t.Fatalf("err = %v", err)
	}
}
