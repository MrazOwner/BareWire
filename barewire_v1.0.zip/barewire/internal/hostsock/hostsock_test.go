package hostsock

import (
	"context"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
)

// fakeHost is a Handler with no privileges, used to exercise the wire.
type fakeHost struct {
	mu        sync.Mutex
	status    proto.Status
	settings  config.Settings
	node      config.Node
	connected bool
	flushed   bool
	mtu       int
	up, down  int
	conns     []proto.Connection
	err       error
	// blockTest holds TestKernel open, so a test can prove that a long call does
	// not block the connection.
	blockTest chan struct{}
}

func (f *fakeHost) Status() proto.Status {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.status
}

func (f *fakeHost) Connect(context.Context) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.err != nil {
		return f.err
	}
	f.connected = true
	return nil
}

func (f *fakeHost) Disconnect(context.Context) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.connected = false
	return nil
}

func (f *fakeHost) Apply(_ context.Context, s config.Settings) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.err != nil {
		return f.err
	}
	f.settings = s
	return nil
}

func (f *fakeHost) Select(_ context.Context, n config.Node) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.node = n
	return nil
}

func (f *fakeHost) FlushKillSwitch(context.Context) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.flushed = true
	return nil
}

func (f *fakeHost) AutoMTU(context.Context) (int, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.mtu, nil
}

func (f *fakeHost) TestKernel(context.Context) ([]proto.KernelTrial, error) {
	f.mu.Lock()
	block := f.blockTest
	f.mu.Unlock()
	if block != nil {
		<-block
	}
	return []proto.KernelTrial{{Algorithm: "bbr", DownMbps: 100, Score: 10}}, nil
}

// A long call must not block the other requests on the same connection: the
// status poll and the levers have to keep working while a trial runs.
func TestLongCallDoesNotBlockTheConnection(t *testing.T) {
	block := make(chan struct{})
	host := &fakeHost{status: proto.Status{HostRunning: true}, blockTest: block}
	_, path, _ := startTestServer(t, host)
	client := dialTest(t, path)

	done := make(chan error, 1)
	go func() {
		_, err := client.TestKernel()
		done <- err
	}()

	// While the trial is running, an ordinary call must answer.
	shortDone := make(chan struct{})
	go func() {
		_ = client.FlushKillSwitch()
		close(shortDone)
	}()
	select {
	case <-shortDone:
	case <-time.After(3 * time.Second):
		t.Fatal("a status-sized call waited behind the long one")
	}

	close(block)
	select {
	case err := <-done:
		if err != nil {
			t.Fatalf("trial: %v", err)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("the trial never finished")
	}
}

func (f *fakeHost) AutoBrutal(context.Context) (int, int, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.up, f.down, nil
}

func (f *fakeHost) Connections() []proto.Connection {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.conns
}

func startTestServer(t *testing.T, h Handler) (*Server, string, chan struct{}) {
	t.Helper()
	dir, err := os.MkdirTemp("/tmp", "bwsock-")
	if err != nil {
		t.Fatalf("temp dir: %v", err)
	}
	t.Cleanup(func() { _ = os.RemoveAll(dir) })
	path := filepath.Join(dir, "host.sock")

	srv, err := Listen(path, h)
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	shutdown := make(chan struct{}, 1)
	srv.OnShutdown(func() { shutdown <- struct{}{} })
	go func() { _ = srv.Serve() }()
	t.Cleanup(func() { _ = srv.Close() })
	return srv, path, shutdown
}

func dialTest(t *testing.T, path string) *Client {
	t.Helper()
	var client *Client
	var err error
	for i := 0; i < 50; i++ {
		client, err = Dial(path)
		if err == nil {
			t.Cleanup(func() { _ = client.Close() })
			return client
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatalf("dial: %v", err)
	return nil
}
