package hostsock

import (
	"context"
	"fmt"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/proto"
)

// Request methods.
const (
	MethodStatus      = "status"
	MethodConnect     = "connect"
	MethodDisconnect  = "disconnect"
	MethodApply       = "apply"
	MethodSelect      = "select"
	MethodFlushKill   = "flush-killswitch"
	MethodAutoMTU     = "auto-mtu"
	MethodAutoBrutal  = "auto-brutal"
	MethodKernelTest  = "kernel-test"
	MethodConnections = "connections"
	MethodShutdown    = "shutdown"
)

// dispatch runs one request. The second return value asks the server to stop
// serving, which is how an explicit shutdown leaves no process behind.
func (s *Server) dispatch(msg proto.Message) (*proto.Message, bool) {
	if msg.Kind != proto.KindRequest {
		return nil, false
	}
	fail := func(err error) *proto.Message {
		m := proto.Failure(msg.ID, msg.Method, err)
		return &m
	}
	ok := func(payload any) *proto.Message {
		m, err := proto.Response(msg.ID, msg.Method, payload)
		if err != nil {
			return fail(err)
		}
		return &m
	}

	switch msg.Method {
	case MethodStatus:
		return ok(s.h.Status()), false
	case MethodConnect:
		if err := s.h.Connect(context.Background()); err != nil {
			return fail(err), false
		}
		return ok(nil), false
	case MethodDisconnect:
		if err := s.h.Disconnect(context.Background()); err != nil {
			return fail(err), false
		}
		return ok(nil), false
	case MethodApply:
		settings, err := proto.DecodePayload[config.Settings](msg)
		if err != nil {
			return fail(err), false
		}
		if err := s.h.Apply(context.Background(), settings); err != nil {
			return fail(err), false
		}
		return ok(nil), false
	case MethodSelect:
		node, err := proto.DecodePayload[config.Node](msg)
		if err != nil {
			return fail(err), false
		}
		if err := s.h.Select(context.Background(), node); err != nil {
			return fail(err), false
		}
		return ok(nil), false
	case MethodFlushKill:
		if err := s.h.FlushKillSwitch(context.Background()); err != nil {
			return fail(err), false
		}
		return ok(nil), false
	case MethodAutoMTU:
		mtu, err := s.h.AutoMTU(context.Background())
		if err != nil {
			return fail(err), false
		}
		return ok(map[string]int{"mtu": mtu}), false
	case MethodAutoBrutal:
		up, down, err := s.h.AutoBrutal(context.Background())
		if err != nil {
			return fail(err), false
		}
		return ok(map[string]int{"up_mbps": up, "down_mbps": down}), false
	case MethodKernelTest:
		trials, err := s.h.TestKernel(context.Background())
		if err != nil {
			return fail(err), false
		}
		return ok(map[string]any{"trials": trials}), false
	case MethodConnections:
		return ok(s.h.Connections()), false
	case MethodShutdown:
		return ok(nil), true
	default:
		return fail(fmt.Errorf("hostsock: unknown method %q", msg.Method)), false
	}
}
