package hostsock

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"fmt"

	"github.com/mrazowner/barewire/internal/proto"
)

// call sends one request and waits for the matching response. Events that
// arrive meanwhile are routed to the events channel by the reader goroutine.
func (c *Client) call(ctx context.Context, method string, payload, out any) error {
	c.mu.Lock()
	c.nextID++
	id := fmt.Sprintf("%d", c.nextID)
	ch := make(chan proto.Message, 1)
	c.pending[id] = ch
	c.mu.Unlock()

	defer func() {
		c.mu.Lock()
		delete(c.pending, id)
		c.mu.Unlock()
	}()

	msg, err := proto.Request(id, method, payload)
	if err != nil {
		return err
	}
	if err := c.write(msg); err != nil {
		return err
	}

	select {
	case reply := <-ch:
		if reply.Error != "" {
			return errors.New("host: " + reply.Error)
		}
		if out != nil {
			return proto.DecodePayloadInto(reply, out)
		}
		return nil
	case <-ctx.Done():
		return fmt.Errorf("host: %s timed out", method)
	case <-c.done:
		return errors.New("host: connection closed")
	}
}

func (c *Client) write(msg proto.Message) error {
	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	w := bufio.NewWriter(c.conn)
	if err := proto.Encode(w, msg); err != nil {
		return fmt.Errorf("hostsock: write: %w", err)
	}
	return w.Flush()
}

func (c *Client) readLoop() {
	defer func() {
		select {
		case <-c.done:
		default:
			close(c.events)
		}
	}()
	reader := bufio.NewReader(c.conn)
	for {
		msg, err := proto.Decode(reader)
		if err != nil {
			return
		}
		switch msg.Kind {
		case proto.KindEvent:
			var ev proto.Event
			if err := json.Unmarshal(msg.Payload, &ev); err != nil {
				continue
			}
			c.applyEvent(ev)
			select {
			case c.events <- ev:
			default:
			}
		case proto.KindResponse:
			c.mu.Lock()
			ch := c.pending[msg.ID]
			c.mu.Unlock()
			if ch != nil {
				select {
				case ch <- msg:
				default:
				}
			}
		}
	}
}

// applyEvent keeps the cached snapshot in sync so Snapshot never blocks.
func (c *Client) applyEvent(ev proto.Event) {
	c.mu.Lock()
	defer c.mu.Unlock()
	switch ev.Type {
	case proto.EventStatus:
		if ev.Status != nil {
			c.status = *ev.Status
		}
	case proto.EventSample:
		if s := ev.Sample; s != nil {
			c.status.UpBps = s.UpBps
			c.status.DownBps = s.DownBps
			c.status.BytesUp = s.BytesUp
			c.status.BytesDown = s.BytesDown
			c.status.Connections = s.Connections
		}
	}
}
