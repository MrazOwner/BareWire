package proto

import (
	"bufio"
	"bytes"
	"errors"
	"io"
	"strings"
	"testing"
)

func TestEncodeDecodeRoundTrip(t *testing.T) {
	var buf bytes.Buffer
	req, err := Request("7", "connect", map[string]string{"profile": "home"})
	if err != nil {
		t.Fatalf("request: %v", err)
	}
	if err := Encode(&buf, req); err != nil {
		t.Fatalf("encode: %v", err)
	}
	if !strings.HasSuffix(buf.String(), "\n") {
		t.Fatalf("frame must be newline terminated, got %q", buf.String())
	}

	got, err := Decode(bufio.NewReader(&buf))
	if err != nil {
		t.Fatalf("decode: %v", err)
	}
	if got.Kind != KindRequest || got.Method != "connect" || got.ID != "7" {
		t.Fatalf("unexpected frame: %+v", got)
	}
	if got.Version != ProtocolVersion {
		t.Fatalf("version = %d, want %d", got.Version, ProtocolVersion)
	}
	payload, err := DecodePayload[map[string]string](got)
	if err != nil {
		t.Fatalf("payload: %v", err)
	}
	if payload["profile"] != "home" {
		t.Fatalf("payload = %+v", payload)
	}
}

func TestEventRoundTrip(t *testing.T) {
	ev := Event{Type: EventLog, Log: &LogEntry{Level: LevelWarn, Text: "handshake timeout"}}
	msg, err := EventMessage(ev)
	if err != nil {
		t.Fatalf("event: %v", err)
	}
	var buf bytes.Buffer
	if err := Encode(&buf, msg); err != nil {
		t.Fatalf("encode: %v", err)
	}
	got, err := Decode(bufio.NewReader(&buf))
	if err != nil {
		t.Fatalf("decode: %v", err)
	}
	back, err := DecodePayload[Event](got)
	if err != nil {
		t.Fatalf("payload: %v", err)
	}
	if back.Type != EventLog || back.Log == nil || back.Log.Level != LevelWarn {
		t.Fatalf("unexpected event: %+v", back)
	}
}

func TestDecodeSkipsBlankLines(t *testing.T) {
	in := "\n\n   \n" + `{"kind":"response","id":"1"}` + "\n"
	got, err := Decode(bufio.NewReader(strings.NewReader(in)))
	if err != nil {
		t.Fatalf("decode: %v", err)
	}
	if got.Kind != KindResponse || got.ID != "1" {
		t.Fatalf("unexpected frame: %+v", got)
	}
}

func TestDecodeFinalFrameWithoutNewline(t *testing.T) {
	got, err := Decode(bufio.NewReader(strings.NewReader(`{"kind":"event"}`)))
	if err != nil {
		t.Fatalf("decode: %v", err)
	}
	if got.Kind != KindEvent {
		t.Fatalf("kind = %q", got.Kind)
	}
}

func TestDecodeEOF(t *testing.T) {
	_, err := Decode(bufio.NewReader(strings.NewReader("")))
	if !errors.Is(err, io.EOF) {
		t.Fatalf("err = %v, want io.EOF", err)
	}
}

func TestDecodeRejectsUnknownKind(t *testing.T) {
	_, err := Decode(bufio.NewReader(strings.NewReader(`{"kind":"telepathy"}` + "\n")))
	if !errors.Is(err, ErrUnknownKind) {
		t.Fatalf("err = %v, want ErrUnknownKind", err)
	}
}

func TestDecodeRejectsForeignVersion(t *testing.T) {
	_, err := Decode(bufio.NewReader(strings.NewReader(`{"v":999,"kind":"event"}` + "\n")))
	if !errors.Is(err, ErrVersion) {
		t.Fatalf("err = %v, want ErrVersion", err)
	}
}

func TestDecodeRejectsOversizedFrame(t *testing.T) {
	big := strings.Repeat("a", MaxFrameSize+16)
	_, err := Decode(bufio.NewReader(strings.NewReader(big + "\n")))
	if !errors.Is(err, ErrFrameTooLarge) {
		t.Fatalf("err = %v, want ErrFrameTooLarge", err)
	}
}

func TestDecodeRejectsBrokenJSON(t *testing.T) {
	if _, err := Decode(bufio.NewReader(strings.NewReader("{\"kind\":\n"))); err == nil {
		t.Fatal("expected an error for malformed JSON")
	}
}

func TestEncodeRejectsUnknownKind(t *testing.T) {
	if err := Encode(io.Discard, Message{Kind: Kind("carrier-pigeon")}); !errors.Is(err, ErrUnknownKind) {
		t.Fatalf("err = %v, want ErrUnknownKind", err)
	}
}

func TestDecodePayloadEmpty(t *testing.T) {
	if _, err := DecodePayload[Event](Message{Kind: KindEvent}); err == nil {
		t.Fatal("expected an error for an empty payload")
	}
}

func TestLogLevelRankOrdering(t *testing.T) {
	order := []LogLevel{LevelDebug, "garbage", LevelInfo, LevelWarn, LevelError}
	for i := 1; i < len(order); i++ {
		if order[i-1].Rank() > order[i].Rank() {
			t.Fatalf("rank of %q must not exceed %q", order[i-1], order[i])
		}
	}
	if LogLevel("garbage").Rank() != LevelInfo.Rank() {
		t.Fatal("unknown levels must rank as info")
	}
}
