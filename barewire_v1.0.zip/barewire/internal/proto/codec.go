package proto

import (
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
)

// MaxFrameSize bounds a single frame. A frame above this size is a protocol
// error, not something to be truncated: truncating silently would hide facts.
const MaxFrameSize = 8 << 20

var (
	// ErrFrameTooLarge is returned when a frame exceeds MaxFrameSize.
	ErrFrameTooLarge = errors.New("proto: frame exceeds maximum size")
	// ErrUnknownKind is returned for frames without a known kind.
	ErrUnknownKind = errors.New("proto: unknown frame kind")
	// ErrVersion is returned when the peer speaks another protocol version.
	ErrVersion = errors.New("proto: unsupported protocol version")
)

// Message is one frame on the wire.
type Message struct {
	Version int             `json:"v"`
	ID      string          `json:"id,omitempty"`
	Kind    Kind            `json:"kind"`
	Method  string          `json:"method,omitempty"`
	Error   string          `json:"err,omitempty"`
	Payload json.RawMessage `json:"payload,omitempty"`
}

// Valid reports whether the kind is part of the protocol.
func (k Kind) Valid() bool {
	switch k {
	case KindRequest, KindResponse, KindEvent:
		return true
	default:
		return false
	}
}

// Request builds a request frame.
func Request(id, method string, payload any) (Message, error) {
	m := Message{Version: ProtocolVersion, ID: id, Kind: KindRequest, Method: method}
	raw, err := marshalPayload(payload)
	if err != nil {
		return Message{}, err
	}
	m.Payload = raw
	return m, nil
}

// Response builds a successful response frame.
func Response(id, method string, payload any) (Message, error) {
	m, err := Request(id, method, payload)
	if err != nil {
		return Message{}, err
	}
	m.Kind = KindResponse
	return m, nil
}

// Failure builds a failed response frame.
func Failure(id, method string, cause error) Message {
	m := Message{Version: ProtocolVersion, ID: id, Kind: KindResponse, Method: method}
	if cause != nil {
		m.Error = cause.Error()
	}
	return m
}

// EventMessage wraps an event as a frame.
func EventMessage(ev Event) (Message, error) {
	raw, err := marshalPayload(ev)
	if err != nil {
		return Message{}, err
	}
	return Message{Version: ProtocolVersion, Kind: KindEvent, Payload: raw}, nil
}

func marshalPayload(v any) (json.RawMessage, error) {
	if v == nil {
		return nil, nil
	}
	raw, err := json.Marshal(v)
	if err != nil {
		return nil, fmt.Errorf("proto: encode payload: %w", err)
	}
	return raw, nil
}

// Encode writes one frame followed by a newline.
func Encode(w io.Writer, m Message) error {
	if m.Version == 0 {
		m.Version = ProtocolVersion
	}
	if !m.Kind.Valid() {
		return fmt.Errorf("%w: %q", ErrUnknownKind, string(m.Kind))
	}
	if len(m.Payload) > MaxFrameSize {
		return ErrFrameTooLarge
	}
	raw, err := json.Marshal(m)
	if err != nil {
		return fmt.Errorf("proto: encode frame: %w", err)
	}
	raw = append(raw, '\n')
	if _, err := w.Write(raw); err != nil {
		return fmt.Errorf("proto: write frame: %w", err)
	}
	return nil
}

// Decode reads one frame. Blank lines are skipped; a final frame without a
// trailing newline is accepted. The returned message always carries the
// current ProtocolVersion.
func Decode(r *bufio.Reader) (Message, error) {
	for {
		line, err := r.ReadBytes('\n')
		if len(line) > MaxFrameSize {
			return Message{}, ErrFrameTooLarge
		}
		atEOF := errors.Is(err, io.EOF)
		if err != nil && !atEOF {
			return Message{}, fmt.Errorf("proto: read frame: %w", err)
		}
		line = bytes.TrimSpace(line)
		if len(line) == 0 {
			if atEOF {
				return Message{}, io.EOF
			}
			continue
		}
		var m Message
		if uerr := json.Unmarshal(line, &m); uerr != nil {
			return Message{}, fmt.Errorf("proto: decode frame: %w", uerr)
		}
		if !m.Kind.Valid() {
			return Message{}, fmt.Errorf("%w: %q", ErrUnknownKind, string(m.Kind))
		}
		if m.Version == 0 {
			m.Version = ProtocolVersion
		}
		if m.Version != ProtocolVersion {
			return Message{}, fmt.Errorf("%w: peer speaks v%d, this build speaks v%d", ErrVersion, m.Version, ProtocolVersion)
		}
		return m, nil
	}
}

// DecodePayloadInto unmarshals a response payload into an existing value. It
// exists so callers can decode into a struct they own through an interface.
func DecodePayloadInto(m Message, out any) error {
	if len(m.Payload) == 0 {
		return errors.New("proto: empty payload")
	}
	if err := json.Unmarshal(m.Payload, out); err != nil {
		return fmt.Errorf("proto: decode payload: %w", err)
	}
	return nil
}

// DecodePayload unmarshals the frame payload into T.
func DecodePayload[T any](m Message) (T, error) {
	var v T
	if len(m.Payload) == 0 {
		return v, errors.New("proto: empty payload")
	}
	if err := json.Unmarshal(m.Payload, &v); err != nil {
		return v, fmt.Errorf("proto: decode payload: %w", err)
	}
	return v, nil
}
