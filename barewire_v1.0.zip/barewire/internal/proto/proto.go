// Package proto defines the wire types shared by the Barewire TUI and the
// privileged host process (barewire-host).
//
// The transport is a unix socket carrying newline-delimited JSON frames. The
// package intentionally contains no transport code: it is the grammar, not the
// pipe, so that both sides can be tested without a socket.
package proto

import "time"

// ProtocolVersion is bumped whenever the frame layout or payload semantics
// change in a way the other side cannot ignore.
const ProtocolVersion = 1

// Kind tells the receiver what the frame is.
type Kind string

const (
	KindRequest  Kind = "request"
	KindResponse Kind = "response"
	KindEvent    Kind = "event"
)

// EventType is the discriminator inside an event payload.
type EventType string

const (
	EventStatus EventType = "status"
	EventLog    EventType = "log"
	EventSample EventType = "sample"
)

// LinkState is the link state as reported by the host. There is no "error"
// state: a failed attempt is a disconnect with a reason.
type LinkState string

const (
	LinkDisconnected LinkState = "disconnected"
	LinkConnecting   LinkState = "connecting"
	LinkConnected    LinkState = "connected"
	LinkStopping     LinkState = "stopping"
)

// LogLevel mirrors the core log levels.
type LogLevel string

const (
	LevelDebug LogLevel = "debug"
	LevelInfo  LogLevel = "info"
	LevelWarn  LogLevel = "warn"
	LevelError LogLevel = "error"
)

// Rank orders levels for filtering: a level passes a filter when its rank is
// greater than or equal to the filter rank. Unknown levels rank as info so
// that an unrecognised core line is never silently dropped.
func (l LogLevel) Rank() int {
	switch l {
	case LevelDebug:
		return 0
	case LevelWarn:
		return 2
	case LevelError:
		return 3
	default:
		return 1
	}
}

// LogEntry is one line of the core or host log stream.
type LogEntry struct {
	Time   time.Time `json:"time"`
	Level  LogLevel  `json:"level"`
	Source string    `json:"source,omitempty"`
	Text   string    `json:"text"`
}

// Sample is a traffic snapshot, pushed once per second while connected.
type Sample struct {
	Time        time.Time `json:"time"`
	UpBps       uint64    `json:"up_bps"`
	DownBps     uint64    `json:"down_bps"`
	BytesUp     uint64    `json:"bytes_up"`
	BytesDown   uint64    `json:"bytes_down"`
	Connections int       `json:"connections"`
}

// Smux is the multiplexing configuration actually in use.
type Smux struct {
	Enabled  bool   `json:"enabled"`
	Protocol string `json:"protocol"`
	Padding  bool   `json:"padding"`
}

// Brutal is the TCP Brutal configuration actually in use.
type Brutal struct {
	Enabled  bool `json:"enabled"`
	UpMbps   int  `json:"up_mbps"`
	DownMbps int  `json:"down_mbps"`
}

// KernelTrial is one congestion control measured on the live path.
type KernelTrial struct {
	Algorithm string  `json:"algorithm"`
	DownMbps  int     `json:"down_mbps"`
	RTTMinMs  int     `json:"rtt_min_ms"`
	RTTP95Ms  int     `json:"rtt_p95_ms"`
	Score     float64 `json:"score"`
	Err       string  `json:"err,omitempty"`
}

// DNS is the resolver configuration actually in use.
type DNS struct {
	Mode    string   `json:"mode"`
	Servers []string `json:"servers"`
}

// KillSwitch is the firewall state actually in use.
type KillSwitch struct {
	Enabled         bool   `json:"enabled"`
	Active          bool   `json:"active"`
	OnCrash         string `json:"on_crash"`
	OnNetworkChange string `json:"on_network_change"`
	RulesetVersion  int    `json:"ruleset_version"`
}

// Connection is one live connection seen by the core. It exists so the user can
// see which outbound and which rule carried the traffic.
type Connection struct {
	ID       uint64    `json:"id"`
	Outbound string    `json:"outbound"`
	Rule     string    `json:"rule"`
	Host     string    `json:"host"`
	Network  string    `json:"network"`
	Since    time.Time `json:"since"`
	Up       uint64    `json:"up"`
	Down     uint64    `json:"down"`
}

// Status is the complete factual picture of the current link. Every field is a
// fact; none of them is a judgement.
type Status struct {
	HostRunning bool      `json:"host_running"`
	HostVersion string    `json:"host_version"`
	CoreVersion string    `json:"core_version"`
	State       LinkState `json:"state"`
	Since       time.Time `json:"since"`

	Profile  string `json:"profile"`
	Server   string `json:"server"`
	Protocol string `json:"protocol"`
	// Flow is the VLESS flow of the selected node, empty when it has none. A
	// non-empty flow rules multiplexing out: the flow wraps the stream itself.
	Flow     string `json:"flow,omitempty"`
	Outbound string `json:"outbound"`
	Rule     string `json:"rule"`

	TUNStack  string `json:"tun_stack"`
	MTU       int    `json:"mtu"`
	MTUSource string `json:"mtu_source"`
	Smux      Smux   `json:"smux"`
	Brutal    Brutal `json:"brutal"`
	// Congestion is the kernel congestion control in use (bbr, cubic, ...).
	Congestion string `json:"congestion"`
	// Qdisc is the kernel's default queue discipline.
	Qdisc string `json:"qdisc"`
	// CCOptions lists the congestion controls this machine registers, best
	// first. The interface offers exactly these, because offering a value the
	// kernel cannot provide is how a lever ends up doing nothing.
	CCOptions []string `json:"cc_options,omitempty"`
	// KernelBest is the algorithm the last trial run found best for the current
	// server. It is per server: a different path can have a different winner.
	KernelBest string `json:"kernel_best,omitempty"`

	DNS        DNS        `json:"dns"`
	KillSwitch KillSwitch `json:"kill_switch"`

	Reconnects       int       `json:"reconnects"`
	LastDisconnect   string    `json:"last_disconnect"`
	LastDisconnectAt time.Time `json:"last_disconnect_at"`
	// LastError is the most recent error the core reported while running. A link
	// can be up while every egress attempt fails; this is the fact that shows it.
	LastError   string    `json:"last_error"`
	LastErrorAt time.Time `json:"last_error_at"`

	UpBps       uint64 `json:"up_bps"`
	DownBps     uint64 `json:"down_bps"`
	BytesUp     uint64 `json:"bytes_up"`
	BytesDown   uint64 `json:"bytes_down"`
	Connections int    `json:"connections"`

	// Resources of the host process, which is also the core: RSS in KiB and CPU
	// as a percentage of one core since the previous status.
	MemRSSKB   uint64  `json:"mem_rss_kb"`
	CPUPercent float64 `json:"cpu_percent"`
}

// CarriesTraffic reports whether the link is in a state where traffic flows.
func (s Status) CarriesTraffic() bool {
	return s.State == LinkConnected
}

// Event is the payload of an event frame.
type Event struct {
	Type   EventType `json:"type"`
	Status *Status   `json:"status,omitempty"`
	Log    *LogEntry `json:"log,omitempty"`
	Sample *Sample   `json:"sample,omitempty"`
}
