package subscription

import (
	"context"
	"encoding/base64"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

const v2rayList = `vless://11111111-2222-3333-4444-555555555555@de1.example.net:443?security=reality#Frankfurt
trojan://secret@nl2.example.net:8443#Amsterdam
ss://YWVzLTI1Ni1nY206cGFzcw==@fi3.example.net:8388#Helsinki
vmess://eyJwcyI6IlNpbmdhcG9yZSIsImFkZCI6InNnNC5leGFtcGxlLm5ldCIsInBvcnQiOjQ0MywiaWQiOiJhYmMifQ==
hysteria2://pw@se5.example.net:443?sni=se5.example.net#Stockholm
`

const clashDoc = `port: 7890
proxies:
  - name: "Tokyo"
    type: vless
    server: jp1.example.net
    port: 443
  - name: "Osaka"
    type: trojan
    server: jp2.example.net
    port: 8443
  - name: "Direct"
    type: direct
  - name: "Auto"
    type: url-test
    server: jp3.example.net
    port: 443
proxy-groups:
  - name: proxy
    type: select
    proxies: ["Tokyo", "Osaka"]
`

func TestDetectFormat(t *testing.T) {
	if got, err := DetectFormat([]byte(clashDoc)); err != nil || got != FormatClash {
		t.Fatalf("clash: %q %v", got, err)
	}
	encoded := base64.StdEncoding.EncodeToString([]byte(v2rayList))
	if got, err := DetectFormat([]byte(encoded)); err != nil || got != FormatV2Ray {
		t.Fatalf("v2ray: %q %v", got, err)
	}
	if _, err := DetectFormat([]byte("random words")); !errors.Is(err, ErrUnknownFormat) {
		t.Fatalf("err = %v, want ErrUnknownFormat", err)
	}
	if _, err := DetectFormat(nil); !errors.Is(err, ErrUnknownFormat) {
		t.Fatalf("empty err = %v", err)
	}
}

func TestParseClashSkipsNonEndpoints(t *testing.T) {
	nodes, err := Parse(FormatClash, []byte(clashDoc))
	if err != nil {
		t.Fatalf("parse: %v", err)
	}
	if len(nodes) != 2 {
		t.Fatalf("got %d nodes, want 2: %+v", len(nodes), nodes)
	}
	if nodes[0].Name != "Tokyo" || nodes[0].Kind != "vless" || nodes[0].Address != "jp1.example.net" || nodes[0].Port != 443 {
		t.Fatalf("unexpected node: %+v", nodes[0])
	}
	if nodes[0].LatencyMS != -1 {
		t.Fatalf("latency must be unknown until measured, got %d", nodes[0].LatencyMS)
	}
}

func TestParseV2Ray(t *testing.T) {
	body := []byte(base64.StdEncoding.EncodeToString([]byte(v2rayList)))
	nodes, err := Parse(FormatV2Ray, body)
	if err != nil {
		t.Fatalf("parse: %v", err)
	}
	if len(nodes) != 5 {
		t.Fatalf("got %d nodes, want 5: %+v", len(nodes), nodes)
	}
	want := map[string]struct {
		kind string
		addr string
		port int
		name string
	}{
		"vless":     {"vless", "de1.example.net", 443, "Frankfurt"},
		"trojan":    {"trojan", "nl2.example.net", 8443, "Amsterdam"},
		"ss":        {"ss", "fi3.example.net", 8388, "Helsinki"},
		"vmess":     {"vmess", "sg4.example.net", 443, "Singapore"},
		"hysteria2": {"hysteria2", "se5.example.net", 443, "Stockholm"},
	}
	for _, n := range nodes {
		w, ok := want[n.Kind]
		if !ok {
			t.Fatalf("unexpected kind %q", n.Kind)
		}
		if n.Address != w.addr || n.Port != w.port || n.Name != w.name {
			t.Fatalf("%s node mismatch: got %+v, want %+v", n.Kind, n, w)
		}
		delete(want, n.Kind)
	}
	if len(want) != 0 {
		t.Fatalf("missing kinds: %v", want)
	}
}

func TestParseRejectsUnknownFormat(t *testing.T) {
	if _, err := Parse("singbox-json", []byte("{}")); !errors.Is(err, ErrUnknownFormat) {
		t.Fatalf("err = %v", err)
	}
}

func TestFetchV2RayOverHTTP(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.Header.Get("User-Agent"); !strings.Contains(got, "barewire") {
			t.Errorf("user agent = %q", got)
		}
		_, _ = w.Write([]byte(base64.StdEncoding.EncodeToString([]byte(v2rayList))))
	}))
	defer srv.Close()

	res, err := Fetch(context.Background(), srv.URL, "")
	if err != nil {
		t.Fatalf("fetch: %v", err)
	}
	if res.Format != FormatV2Ray || len(res.Nodes) != 5 {
		t.Fatalf("unexpected result: %+v", res)
	}
	if res.Bytes == 0 || res.Took <= 0 {
		t.Fatalf("result must record size and duration: %+v", res)
	}
}

func TestFetchSendsConfiguredUserAgent(t *testing.T) {
	var got string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = r.Header.Get("User-Agent")
		_, _ = w.Write([]byte(base64.StdEncoding.EncodeToString([]byte(v2rayList))))
	}))
	defer srv.Close()

	if _, err := Fetch(context.Background(), srv.URL, "clash.meta"); err != nil {
		t.Fatalf("fetch with custom agent: %v", err)
	}
	if got != "clash.meta" {
		t.Fatalf("user agent = %q, want clash.meta", got)
	}
	if _, err := Fetch(context.Background(), srv.URL, ""); err != nil {
		t.Fatalf("fetch with default agent: %v", err)
	}
	if !strings.Contains(got, "barewire") {
		t.Fatalf("default user agent = %q", got)
	}
}

// Providers answer a refused client with a short message; that message is the
// actual answer to the user's question and must survive into the error.
func TestFetchErrorQuotesProviderMessage(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte("device limit reached: 3 of 3 devices"))
	}))
	defer srv.Close()

	_, err := Fetch(context.Background(), srv.URL, "")
	if err == nil {
		t.Fatal("expected an error for a non-subscription body")
	}
	if !strings.Contains(err.Error(), "device limit reached") {
		t.Fatalf("provider message lost: %v", err)
	}
}

func TestFetchHTTPErrorQuotesBody(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusForbidden)
		_, _ = w.Write([]byte("application not supported"))
	}))
	defer srv.Close()

	_, err := Fetch(context.Background(), srv.URL, "")
	if err == nil || !strings.Contains(err.Error(), "application not supported") {
		t.Fatalf("err = %v", err)
	}
}

func TestFetchHTTPError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		http.Error(w, "nope", http.StatusForbidden)
	}))
	defer srv.Close()
	if _, err := Fetch(context.Background(), srv.URL, ""); err == nil {
		t.Fatal("expected an error for HTTP 403")
	}
}
