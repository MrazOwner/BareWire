package subscription

import (
	"context"
	"io"
	"net/http"
	"strings"
	"time"
)

// Probe is one raw look at a subscription URL: what the server answered, before
// any parsing. When a provider says "app not supported", this is the only honest
// way to see what it actually sent.
type Probe struct {
	URL       string
	UserAgent string
	Status    int
	Headers   http.Header
	Bytes     int
	Format    string
	Nodes     int
	Preview   string
	Took      time.Duration
	Err       error
}

// RunProbe fetches the URL and reports the raw answer.
func RunProbe(ctx context.Context, rawURL, userAgent string) Probe {
	out := Probe{URL: rawURL, UserAgent: userAgent}
	ctx, cancel := context.WithTimeout(ctx, httpTimeout)
	defer cancel()

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, rawURL, nil)
	if err != nil {
		out.Err = err
		return out
	}
	if out.UserAgent == "" {
		out.UserAgent = requestAgent
	}
	req.Header.Set("User-Agent", out.UserAgent)
	req.Header.Set("Accept", "*/*")

	start := time.Now()
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		out.Err = err
		return out
	}
	defer func() { _ = resp.Body.Close() }()

	body, readErr := io.ReadAll(io.LimitReader(resp.Body, maxBody))
	out.Status = resp.StatusCode
	out.Headers = resp.Header.Clone()
	out.Bytes = len(body)
	out.Took = time.Since(start)
	if readErr != nil {
		out.Err = readErr
		return out
	}
	out.Preview = previewText(string(body))

	if format, ferr := DetectFormat(body); ferr == nil {
		out.Format = format
		if nodes, perr := Parse(format, body); perr == nil {
			out.Nodes = len(nodes)
		} else {
			out.Err = perr
		}
		// A base64 subscription is unreadable as base64; show the decoded list,
		// which is what the user actually gets.
		if format == FormatV2Ray {
			if decoded, ok := decodeBase64(strings.TrimSpace(string(body))); ok {
				out.Preview = previewText(decoded)
			}
		}
	} else {
		out.Err = ferr
	}
	return out
}

// previewText folds a body into one quotable line.
func previewText(text string) string {
	text = strings.Join(strings.Fields(strings.ToValidUTF8(text, "")), " ")
	if text == "" {
		return ""
	}
	if runes := []rune(text); len(runes) > 160 {
		return string(runes[:160]) + "…"
	}
	return text
}
