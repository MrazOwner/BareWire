package subscription

import (
	"encoding/json"
	"testing"
)

// outboundOf decodes a node's outbound into a nested map for assertions.
func outboundOf(t *testing.T, raw json.RawMessage) map[string]any {
	t.Helper()
	if len(raw) == 0 {
		t.Fatal("node has no outbound")
	}
	var m map[string]any
	if err := json.Unmarshal(raw, &m); err != nil {
		t.Fatalf("outbound is not JSON: %v", err)
	}
	return m
}

func nested(t *testing.T, m map[string]any, path ...string) map[string]any {
	t.Helper()
	cur := m
	for _, key := range path {
		next, ok := cur[key].(map[string]any)
		if !ok {
			t.Fatalf("%v: %q is not an object (%v)", path, key, cur[key])
		}
		cur = next
	}
	return cur
}

func scalar(t *testing.T, m map[string]any, key string) any {
	t.Helper()
	v, ok := m[key]
	if !ok {
		t.Fatalf("key %q missing in %v", key, m)
	}
	return v
}

const clashRich = `proxies:
  - name: "DE reality ws"
    type: vless
    server: de1.example.net
    port: 443
    uuid: 11111111-2222-3333-4444-555555555555
    tls: true
    servername: de1.example.net
    client-fingerprint: chrome
    flow: xtls-rprx-vision
    network: ws
    ws-opts:
      path: /ray
      headers:
        Host: cdn.example.net
    reality-opts:
      public-key: PUBKEY123
      short-id: abcd
  - name: "NL trojan grpc"
    type: trojan
    server: nl2.example.net
    port: 8443
    password: secret
    sni: nl2.example.net
    skip-cert-verify: true
    network: grpc
    grpc-opts:
      grpc-service-name: tun
  - name: "FI hy2"
    type: hysteria2
    server: fi3.example.net
    port: 8443
    password: pw
    sni: fi3.example.net
    up: 100
    down: 500
    obfs: salamander
    obfs-password: ob
  - name: "JP ss"
    type: ss
    server: jp4.example.net
    port: 8388
    cipher: aes-256-gcm
    password: sspass
  - name: "Reject"
    type: reject
`

func TestClashOutbounds(t *testing.T) {
	nodes, err := Parse(FormatClash, []byte(clashRich))
	if err != nil {
		t.Fatalf("parse: %v", err)
	}
	if len(nodes) != 4 {
		t.Fatalf("got %d nodes, want 4", len(nodes))
	}
	for _, n := range nodes {
		if !n.Connectable() {
			t.Fatalf("node %q is not connectable", n.Name)
		}
	}

	vless := outboundOf(t, nodes[0].Outbound)
	if scalar(t, vless, "type") != "vless" || scalar(t, vless, "uuid") != "11111111-2222-3333-4444-555555555555" {
		t.Fatalf("vless base: %v", vless)
	}
	if scalar(t, vless, "flow") != "xtls-rprx-vision" {
		t.Fatalf("flow lost: %v", vless)
	}
	tls := nested(t, vless, "tls")
	if tls["enabled"] != true || tls["server_name"] != "de1.example.net" {
		t.Fatalf("tls: %v", tls)
	}
	if fp := nested(t, tls, "utls")["fingerprint"]; fp != "chrome" {
		t.Fatalf("utls: %v", fp)
	}
	reality := nested(t, tls, "reality")
	if reality["public_key"] != "PUBKEY123" || reality["short_id"] != "abcd" {
		t.Fatalf("reality: %v", reality)
	}
	ws := nested(t, vless, "transport")
	if ws["type"] != "ws" || ws["path"] != "/ray" {
		t.Fatalf("ws: %v", ws)
	}
	if host := nested(t, ws, "headers")["Host"]; host != "cdn.example.net" {
		t.Fatalf("ws host: %v", host)
	}

	trojan := outboundOf(t, nodes[1].Outbound)
	if scalar(t, trojan, "password") != "secret" {
		t.Fatalf("trojan: %v", trojan)
	}
	if nested(t, trojan, "tls")["insecure"] != true {
		t.Fatal("skip-cert-verify must become tls.insecure")
	}
	if grpc := nested(t, trojan, "transport"); grpc["type"] != "grpc" || grpc["service_name"] != "tun" {
		t.Fatalf("grpc: %v", grpc)
	}

	hy2 := outboundOf(t, nodes[2].Outbound)
	if scalar(t, hy2, "password") != "pw" || scalar(t, hy2, "up_mbps") != float64(100) {
		t.Fatalf("hysteria2: %v", hy2)
	}
	if obfs := nested(t, hy2, "obfs"); obfs["type"] != "salamander" || obfs["password"] != "ob" {
		t.Fatalf("obfs: %v", obfs)
	}

	ss := outboundOf(t, nodes[3].Outbound)
	if ss["method"] != "aes-256-gcm" || ss["password"] != "sspass" || ss["type"] != "shadowsocks" {
		t.Fatalf("ss: %v", ss)
	}
}
