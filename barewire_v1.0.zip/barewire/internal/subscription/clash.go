package subscription

import "strings"

// clashOutbound converts one Clash proxy entry into a sing-box outbound object.
// Unsupported proxies are rejected here, not silently half-converted.
func clashOutbound(p obj) (obj, bool) {
	kind := strings.ToLower(str(p, "type"))
	server := str(p, "server")
	port := num(p, "port")
	if server == "" || port <= 0 {
		return nil, false
	}
	out := obj{"type": clashOutboundType(kind), "server": server, "server_port": port}

	switch kind {
	case "vless":
		uuid := str(p, "uuid")
		if uuid == "" {
			return nil, false
		}
		out["uuid"] = uuid
		out.set("flow", str(p, "flow"))
		out.set("packet_encoding", str(p, "packet-encoding"))
		if tls := clashTLS(p, server, false); tls != nil {
			out["tls"] = tls
		}
		if tr := clashTransport(p); tr != nil {
			out["transport"] = tr
		}
	case "vmess":
		uuid := str(p, "uuid")
		if uuid == "" {
			return nil, false
		}
		out["uuid"] = uuid
		out.set("security", str(p, "cipher"))
		if alter := num(p, "alterId"); alter > 0 {
			out["alter_id"] = alter
		}
		if tls := clashTLS(p, server, false); tls != nil {
			out["tls"] = tls
		}
		if tr := clashTransport(p); tr != nil {
			out["transport"] = tr
		}
	case "trojan":
		password := str(p, "password")
		if password == "" {
			return nil, false
		}
		out["password"] = password
		out["tls"] = clashTLS(p, server, true)
		if tr := clashTransport(p); tr != nil {
			out["transport"] = tr
		}
	case "ss":
		method := str(p, "cipher")
		password := str(p, "password")
		if method == "" || password == "" {
			return nil, false
		}
		out["method"] = method
		out["password"] = password
	case "hysteria2":
		password := str(p, "password")
		if password == "" {
			return nil, false
		}
		out["password"] = password
		if up := num(p, "up"); up > 0 {
			out["up_mbps"] = up
		}
		if down := num(p, "down"); down > 0 {
			out["down_mbps"] = down
		}
		if obfs := str(p, "obfs"); obfs != "" {
			o := obj{"type": obfs}
			o.set("password", str(p, "obfs-password"))
			out["obfs"] = o
		}
		out["tls"] = clashTLS(p, server, true)
	case "tuic":
		uuid := str(p, "uuid")
		password := str(p, "password")
		if uuid == "" || password == "" {
			return nil, false
		}
		out["uuid"] = uuid
		out["password"] = password
		out.set("congestion_control", str(p, "congestion-controller"))
		out.set("udp_relay_mode", str(p, "udp-relay-mode"))
		out["tls"] = clashTLS(p, server, true)
	default:
		return nil, false
	}
	return out, true
}

// clashOutboundType maps a Clash proxy type onto the core's outbound type.
func clashOutboundType(kind string) string {
	if kind == "ss" {
		return "shadowsocks"
	}
	return kind
}

// clashTLS builds the TLS block. force is set for protocols that are always
// wrapped in TLS, where Clash has no "tls" switch to read.
func clashTLS(p obj, server string, force bool) obj {
	realityOpts := asObj(p["reality-opts"])
	enabled := force || flag(p, "tls") || len(realityOpts) > 0 ||
		str(p, "sni") != "" || str(p, "servername") != ""
	if !enabled {
		return nil
	}
	tls := obj{"enabled": true}
	tls.set("server_name", first(str(p, "sni"), str(p, "servername"), server))
	if flag(p, "skip-cert-verify") {
		tls["insecure"] = true
	}
	if alpn := strs(p, "alpn"); len(alpn) > 0 {
		tls["alpn"] = alpn
	}
	if fp := str(p, "client-fingerprint"); fp != "" {
		tls["utls"] = obj{"enabled": true, "fingerprint": fp}
	}
	if len(realityOpts) > 0 {
		reality := obj{"enabled": true}
		reality.set("public_key", str(realityOpts, "public-key"))
		reality.set("short_id", str(realityOpts, "short-id"))
		tls["reality"] = reality
	}
	return tls
}

// clashTransport maps the Clash "network"/"*-opts" pair onto a V2Ray transport.
func clashTransport(p obj) obj {
	switch strings.ToLower(str(p, "network")) {
	case "ws":
		opts := asObj(p["ws-opts"])
		tr := obj{"type": "ws"}
		tr.set("path", str(opts, "path"))
		if headers := asObj(opts["headers"]); len(headers) > 0 {
			tr["headers"] = headers
		}
		if early := num(opts, "max-early-data"); early > 0 {
			tr["max_early_data"] = early
			tr.set("early_data_header_name", str(opts, "early-data-header-name"))
		}
		return tr
	case "grpc":
		opts := asObj(p["grpc-opts"])
		tr := obj{"type": "grpc"}
		tr.set("service_name", str(opts, "grpc-service-name"))
		return tr
	case "h2":
		opts := asObj(p["h2-opts"])
		tr := obj{"type": "http"}
		tr.set("path", str(opts, "path"))
		if hosts := strs(opts, "host"); len(hosts) > 0 {
			tr["host"] = hosts
		}
		return tr
	default:
		return nil
	}
}
