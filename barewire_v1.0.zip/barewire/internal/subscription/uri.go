package subscription

import (
	"net/url"
	"strings"
)

// uriOutbound converts one share URI into a sing-box outbound object.
func uriOutbound(line string) (obj, bool) {
	scheme, rest, found := strings.Cut(line, "://")
	if !found {
		return nil, false
	}
	switch strings.ToLower(scheme) {
	case "vmess":
		return vmessURI(rest)
	case "vless":
		return vlessURI(line)
	case "trojan":
		return trojanURI(line)
	case "ss":
		return ssURI(line)
	case "hysteria2", "hy2":
		return hysteria2URI(line)
	case "tuic":
		return tuicURI(line)
	default:
		return nil, false
	}
}

func vlessURI(line string) (obj, bool) {
	u, ok := parseURIURL(line)
	if !ok {
		return nil, false
	}
	uuid := u.User.Username()
	if uuid == "" {
		return nil, false
	}
	port, err := parsePort(u.Port())
	if err != nil {
		return nil, false
	}
	out := obj{"type": "vless", "server": u.Hostname(), "server_port": port, "uuid": uuid}
	q := u.Query()
	out.set("flow", q.Get("flow"))
	out.set("packet_encoding", q.Get("packetEncoding"))
	if tls := uriTLS(q, false); tls != nil {
		out["tls"] = tls
	}
	if tr := uriTransport(q); tr != nil {
		out["transport"] = tr
	}
	return out, true
}

func trojanURI(line string) (obj, bool) {
	u, ok := parseURIURL(line)
	if !ok {
		return nil, false
	}
	password := u.User.Username()
	if password == "" {
		return nil, false
	}
	port, err := parsePort(u.Port())
	if err != nil {
		return nil, false
	}
	out := obj{"type": "trojan", "server": u.Hostname(), "server_port": port, "password": password}
	q := u.Query()
	out["tls"] = uriTLS(q, true)
	if tr := uriTransport(q); tr != nil {
		out["transport"] = tr
	}
	return out, true
}

func ssURI(line string) (obj, bool) {
	u, err := url.Parse(line)
	if err == nil && u.Hostname() != "" && u.User != nil {
		user := u.User.String()
		if decoded, ok := decodeBase64(user); ok {
			user = decoded
		}
		method, password, found := strings.Cut(user, ":")
		if found && method != "" {
			port, perr := parsePort(u.Port())
			if perr != nil {
				return nil, false
			}
			return obj{"type": "shadowsocks", "server": u.Hostname(), "server_port": port,
				"method": method, "password": password}, true
		}
	}
	// Legacy form: the whole "method:password@host:port" is base64 encoded.
	body := line
	if idx := strings.IndexByte(body, '#'); idx >= 0 {
		body = body[:idx]
	}
	body = strings.TrimPrefix(body, "ss://")
	decoded, ok := decodeBase64(body)
	if !ok {
		return nil, false
	}
	creds, hostPort, found := strings.Cut(decoded, "@")
	if !found {
		return nil, false
	}
	method, password, found := strings.Cut(creds, ":")
	if !found {
		return nil, false
	}
	host, portText, found := strings.Cut(hostPort, ":")
	if !found {
		return nil, false
	}
	port, err := parsePort(portText)
	if err != nil {
		return nil, false
	}
	return obj{"type": "shadowsocks", "server": host, "server_port": port,
		"method": method, "password": password}, true
}
