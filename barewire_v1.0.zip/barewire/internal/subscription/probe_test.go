package subscription

import (
	"context"
	"encoding/base64"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestRunProbeReportsRefusal(t *testing.T) {
	var gotUA string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotUA = r.Header.Get("User-Agent")
		w.Header().Set("Content-Type", "text/html")
		w.WriteHeader(http.StatusForbidden)
		_, _ = w.Write([]byte("<html><body>application not supported</body></html>"))
	}))
	defer srv.Close()

	probe := RunProbe(context.Background(), srv.URL, "FlClashX/1.0")
	if gotUA != "FlClashX/1.0" {
		t.Fatalf("user agent = %q", gotUA)
	}
	if probe.Status != http.StatusForbidden {
		t.Fatalf("status = %d", probe.Status)
	}
	if probe.Format != "" || probe.Nodes != 0 {
		t.Fatalf("a refusal must not be parsed as a subscription: %+v", probe)
	}
	if probe.Err == nil {
		t.Fatal("a refusal must be an error")
	}
	if !strings.Contains(probe.Preview, "application not supported") {
		t.Fatalf("preview = %q", probe.Preview)
	}
	if probe.Headers.Get("Content-Type") != "text/html" {
		t.Fatalf("headers lost: %v", probe.Headers)
	}
}

func TestRunProbeReadsRealSubscription(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(base64.StdEncoding.EncodeToString([]byte(v2rayList))))
	}))
	defer srv.Close()

	probe := RunProbe(context.Background(), srv.URL, "")
	if probe.Err != nil {
		t.Fatalf("probe: %v", probe.Err)
	}
	if probe.Status != http.StatusOK || probe.Format != FormatV2Ray || probe.Nodes != 5 {
		t.Fatalf("probe = %+v", probe)
	}
	if probe.Bytes == 0 || probe.Took <= 0 {
		t.Fatalf("probe must record size and duration: %+v", probe)
	}
	// The preview must show the decoded list, not base64: that is what the user
	// actually receives.
	if !strings.Contains(probe.Preview, "vless://") || strings.HasPrefix(probe.Preview, "dmxlc3M6") {
		t.Fatalf("preview = %q", probe.Preview)
	}
}
