package subscription

import (
	"encoding/json"
	"net/url"
	"strconv"
	"strings"
)

func hysteria2URI(line string) (obj, bool) {
	u, ok := parseURIURL(line)
	if !ok {
		return nil, false
	}
	password := u.User.Username()
	if password == "" {
		return nil, false
	}
	port, err := parsePort(u.Port())
	if err != nil {
		return nil, false
	}
	out := obj{"type": "hysteria2", "server": u.Hostname(), "server_port": port, "password": password}
	q := u.Query()
	if obfs := q.Get("obfs"); obfs != "" {
		o := obj{"type": obfs}
		o.set("password", first(q.Get("obfs-password"), q.Get("obfsPassword")))
		out["obfs"] = o
	}
	out["tls"] = uriTLS(q, true)
	return out, true
}

func tuicURI(line string) (obj, bool) {
	u, ok := parseURIURL(line)
	if !ok {
		return nil, false
	}
	uuid := u.User.Username()
	password, _ := u.User.Password()
	if uuid == "" || password == "" {
		return nil, false
	}
	port, err := parsePort(u.Port())
	if err != nil {
		return nil, false
	}
	out := obj{"type": "tuic", "server": u.Hostname(), "server_port": port, "uuid": uuid, "password": password}
	q := u.Query()
	out.set("congestion_control", first(q.Get("congestion_control"), q.Get("congestion_controller")))
	out.set("udp_relay_mode", q.Get("udp_relay_mode"))
	out["tls"] = uriTLS(q, true)
	return out, true
}

// vmessShare is the JSON document inside a vmess:// link.
type vmessShare struct {
	Add  string `json:"add"`
	Port any    `json:"port"`
	ID   string `json:"id"`
	Aid  any    `json:"aid"`
	Scy  string `json:"scy"`
	Net  string `json:"net"`
	Host string `json:"host"`
	Path string `json:"path"`
	Type string `json:"type"`
	TLS  string `json:"tls"`
	SNI  string `json:"sni"`
	ALPN string `json:"alpn"`
	FP   string `json:"fp"`
}

func vmessURI(rest string) (obj, bool) {
	decoded, ok := decodeBase64(rest)
	if !ok {
		return nil, false
	}
	var v vmessShare
	if err := json.Unmarshal([]byte(decoded), &v); err != nil || v.Add == "" || v.ID == "" {
		return nil, false
	}
	port, err := parsePort(scalarText(v.Port))
	if err != nil {
		return nil, false
	}
	out := obj{"type": "vmess", "server": v.Add, "server_port": port, "uuid": v.ID}
	out.set("security", v.Scy)
	if aid := num(obj{"aid": v.Aid}, "aid"); aid > 0 {
		out["alter_id"] = aid
	}
	if strings.EqualFold(v.TLS, "tls") || v.SNI != "" {
		tls := obj{"enabled": true}
		tls.set("server_name", first(v.SNI, v.Host))
		if alpn := splitComma(v.ALPN); len(alpn) > 0 {
			tls["alpn"] = alpn
		}
		if v.FP != "" {
			tls["utls"] = obj{"enabled": true, "fingerprint": v.FP}
		}
		out["tls"] = tls
	}
	switch strings.ToLower(v.Net) {
	case "ws":
		tr := obj{"type": "ws"}
		tr.set("path", v.Path)
		if v.Host != "" {
			tr["headers"] = obj{"Host": v.Host}
		}
		out["transport"] = tr
	case "grpc":
		tr := obj{"type": "grpc"}
		tr.set("service_name", first(v.Path, v.Type))
		out["transport"] = tr
	case "h2", "http":
		tr := obj{"type": "http"}
		tr.set("path", v.Path)
		if hosts := splitComma(v.Host); len(hosts) > 0 {
			tr["host"] = hosts
		}
		out["transport"] = tr
	case "httpupgrade":
		tr := obj{"type": "httpupgrade"}
		tr.set("path", v.Path)
		tr.set("host", v.Host)
		out["transport"] = tr
	}
	return out, true
}

// uriTLS builds a TLS block from share-link query parameters.
func uriTLS(q url.Values, implicit bool) obj {
	security := strings.ToLower(q.Get("security"))
	enabled := implicit || security == "tls" || security == "reality" ||
		q.Get("sni") != "" || isTrue(q.Get("tls"))
	if !enabled {
		return nil
	}
	tls := obj{"enabled": true}
	tls.set("server_name", first(q.Get("sni"), q.Get("serverName"), q.Get("peer")))
	if isTrue(q.Get("allowInsecure")) || isTrue(q.Get("insecure")) || isTrue(q.Get("skip-cert-verify")) {
		tls["insecure"] = true
	}
	if alpn := splitComma(q.Get("alpn")); len(alpn) > 0 {
		tls["alpn"] = alpn
	}
	if fp := q.Get("fp"); fp != "" {
		tls["utls"] = obj{"enabled": true, "fingerprint": fp}
	}
	if security == "reality" || q.Get("pbk") != "" {
		reality := obj{"enabled": true}
		reality.set("public_key", q.Get("pbk"))
		reality.set("short_id", q.Get("sid"))
		tls["reality"] = reality
	}
	return tls
}

// uriTransport builds a V2Ray transport block from share-link query parameters.
func uriTransport(q url.Values) obj {
	switch strings.ToLower(first(q.Get("type"), q.Get("headerType"))) {
	case "ws":
		tr := obj{"type": "ws"}
		tr.set("path", q.Get("path"))
		if host := first(q.Get("host"), q.Get("sni")); host != "" {
			tr["headers"] = obj{"Host": host}
		}
		if early := q.Get("ed"); early != "" {
			if n, err := strconv.Atoi(early); err == nil && n > 0 {
				tr["max_early_data"] = n
			}
			tr.set("early_data_header_name", q.Get("eh"))
		}
		return tr
	case "grpc":
		tr := obj{"type": "grpc"}
		tr.set("service_name", first(q.Get("serviceName"), q.Get("path")))
		return tr
	case "h2", "http":
		tr := obj{"type": "http"}
		tr.set("path", q.Get("path"))
		if hosts := splitComma(first(q.Get("host"), q.Get("sni"))); len(hosts) > 0 {
			tr["host"] = hosts
		}
		return tr
	case "httpupgrade":
		tr := obj{"type": "httpupgrade"}
		tr.set("path", q.Get("path"))
		tr.set("host", q.Get("host"))
		return tr
	default:
		return nil
	}
}

func parseURIURL(line string) (*url.URL, bool) {
	u, err := url.Parse(line)
	if err != nil || u.Hostname() == "" || u.Port() == "" {
		return nil, false
	}
	return u, true
}

// scalarText renders a JSON scalar that may be a string or a number.
func scalarText(v any) string {
	switch t := v.(type) {
	case string:
		return strings.TrimSpace(t)
	case float64:
		return strconv.Itoa(int(t))
	case json.Number:
		return t.String()
	default:
		return ""
	}
}

func isTrue(s string) bool {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "1", "true", "yes":
		return true
	default:
		return false
	}
}

func splitComma(s string) []string {
	if s == "" {
		return nil
	}
	parts := strings.Split(s, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}
