package subscription

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"strconv"
	"strings"

	"gopkg.in/yaml.v3"

	"github.com/mrazowner/barewire/internal/config"
)

// parseClash reads the proxies list. Every endpoint keeps its name, kind and
// address for the list, plus the complete outbound for the core.
func parseClash(body []byte) ([]config.Node, error) {
	var doc struct {
		Proxies []map[string]any `yaml:"proxies"`
	}
	if err := yaml.Unmarshal(body, &doc); err != nil {
		return nil, fmt.Errorf("subscription: parse clash yaml: %w", err)
	}
	nodes := make([]config.Node, 0, len(doc.Proxies))
	for _, raw := range doc.Proxies {
		p := asObj(raw)
		if p == nil {
			continue
		}
		kind := strings.ToLower(str(p, "type"))
		if !supportedKind(kind) {
			continue
		}
		server := str(p, "server")
		port := num(p, "port")
		if server == "" || port <= 0 {
			continue
		}
		name := first(str(p, "name"), server)
		node := config.Node{Name: name, Kind: kind, Address: server, Port: port, LatencyMS: -1}
		if out, ok := clashOutbound(p); ok {
			encoded, err := marshal(out)
			if err != nil {
				return nil, err
			}
			node.Outbound = encoded
		}
		nodes = append(nodes, node)
	}
	return nodes, nil
}

// parseURIs reads a decoded share-link list.
func parseURIs(body string) []config.Node {
	var nodes []config.Node
	for _, line := range strings.Split(body, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		out, ok := uriOutbound(line)
		if !ok {
			continue
		}
		encoded, err := marshal(out)
		if err != nil {
			continue
		}
		nodes = append(nodes, config.Node{
			Name:      uriName(line, out),
			Kind:      displayKind(str(out, "type")),
			Address:   str(out, "server"),
			Port:      num(out, "server_port"),
			LatencyMS: -1,
			Outbound:  encoded,
		})
	}
	return nodes
}

// uriName prefers the fragment, then the vmess remarks field, then the host.
func uriName(line string, out obj) string {
	if u, err := url.Parse(line); err == nil && u.Fragment != "" {
		return u.Fragment
	}
	if strings.HasPrefix(strings.ToLower(line), "vmess://") {
		if _, rest, ok := strings.Cut(line, "://"); ok {
			if decoded, ok := decodeBase64(rest); ok {
				var v struct {
					PS string `json:"ps"`
				}
				if json.Unmarshal([]byte(decoded), &v) == nil && v.PS != "" {
					return v.PS
				}
			}
		}
	}
	return first(str(out, "server"), "node")
}

func parsePort(s string) (int, error) {
	port, err := strconv.Atoi(strings.TrimSpace(s))
	if err != nil {
		return 0, errors.New("subscription: bad port")
	}
	if port <= 0 || port > 65535 {
		return 0, errors.New("subscription: port out of range")
	}
	return port, nil
}

// displayKind maps the core's outbound type onto the short protocol name the
// list shows.
func displayKind(outboundType string) string {
	if outboundType == "shadowsocks" {
		return "ss"
	}
	return outboundType
}

// supportedKind filters out proxies that are not endpoints (selectors, groups,
// reject rules), so the node list contains only things traffic can leave from.
func supportedKind(kind string) bool {
	switch strings.ToLower(kind) {
	case "ss", "vmess", "vless", "trojan", "hysteria2", "tuic":
		return true
	default:
		return false
	}
}
