package subscription

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
)

// obj is a sing-box configuration object on its way to JSON. Building objects
// as maps keeps the generated config readable and testable without pulling the
// core's option structs into the parser.
type obj map[string]any

func (o obj) set(key string, value any) {
	if s, ok := value.(string); ok && s == "" {
		return
	}
	if o == nil {
		return
	}
	o[key] = value
}

// asObj returns a nested object, or nil.
func asObj(v any) obj {
	switch m := v.(type) {
	case obj:
		return m
	case map[string]any:
		return m
	case map[any]any:
		out := make(obj, len(m))
		for k, val := range m {
			out[fmt.Sprint(k)] = val
		}
		return out
	default:
		return nil
	}
}

// str reads a scalar as a string. YAML models numbers and bools as their own
// types, so every scalar is accepted and rendered.
func str(m obj, key string) string {
	v, ok := m[key]
	if !ok || v == nil {
		return ""
	}
	switch t := v.(type) {
	case string:
		return strings.TrimSpace(t)
	case json.Number:
		return t.String()
	case int:
		return strconv.Itoa(t)
	case int64:
		return strconv.FormatInt(t, 10)
	case float64:
		return strconv.FormatFloat(t, 'f', -1, 64)
	case bool:
		return strconv.FormatBool(t)
	default:
		return ""
	}
}

// num reads a scalar as an int; anything unparsable yields 0.
func num(m obj, key string) int {
	raw := str(m, key)
	if raw == "" {
		return 0
	}
	if v, err := strconv.Atoi(raw); err == nil {
		return v
	}
	if f, err := strconv.ParseFloat(raw, 64); err == nil {
		return int(f)
	}
	return 0
}

// flag reads a boolean, accepting YAML bools and the "true"/"1" strings URIs use.
func flag(m obj, key string) bool {
	v, ok := m[key]
	if !ok || v == nil {
		return false
	}
	switch t := v.(type) {
	case bool:
		return t
	case string:
		switch strings.ToLower(strings.TrimSpace(t)) {
		case "1", "true", "yes", "on":
			return true
		}
		return false
	case int:
		return t != 0
	case float64:
		return t != 0
	default:
		return false
	}
}

// strs reads a list of scalars; a bare scalar becomes a one-element list.
func strs(m obj, key string) []string {
	v, ok := m[key]
	if !ok || v == nil {
		return nil
	}
	switch t := v.(type) {
	case string:
		if t = strings.TrimSpace(t); t == "" {
			return nil
		}
		return []string{t}
	case []any:
		out := make([]string, 0, len(t))
		for _, item := range t {
			if s, ok := item.(string); ok && strings.TrimSpace(s) != "" {
				out = append(out, strings.TrimSpace(s))
			}
		}
		return out
	case []string:
		return t
	default:
		return nil
	}
}

// first returns the first non-empty value.
func first(values ...string) string {
	for _, v := range values {
		if v != "" {
			return v
		}
	}
	return ""
}

// marshal turns the object into a RawMessage for config.Node.
func marshal(o obj) (json.RawMessage, error) {
	raw, err := json.Marshal(o)
	if err != nil {
		return nil, fmt.Errorf("subscription: encode outbound: %w", err)
	}
	return raw, nil
}
