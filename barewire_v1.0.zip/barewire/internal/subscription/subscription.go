// Package subscription fetches and parses the two formats commercial services
// actually return: Clash YAML and V2Ray base64 URI lists.
package subscription

import (
	"context"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/mrazowner/barewire/internal/config"
)

// Formats understood by this package.
const (
	FormatClash = "clash"
	FormatV2Ray = "v2ray"
)

// ErrUnknownFormat is returned when the body is neither format.
var ErrUnknownFormat = errors.New("subscription: unknown format")

// Result is what one fetch produced.
type Result struct {
	Format string
	Nodes  []config.Node
	Bytes  int
	Took   time.Duration
}

const (
	maxBody      = 8 << 20
	httpTimeout  = 20 * time.Second
	requestAgent = "barewire/0.1"
)

// Fetch downloads a subscription and parses it. There is no caching and no
// background refresh: the caller decides when this runs. An empty userAgent
// means the Barewire default; providers that gate by client need a real one.
func Fetch(ctx context.Context, rawURL, userAgent string) (Result, error) {
	ctx, cancel := context.WithTimeout(ctx, httpTimeout)
	defer cancel()

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, rawURL, nil)
	if err != nil {
		return Result{}, fmt.Errorf("subscription: request: %w", err)
	}
	if userAgent == "" {
		userAgent = requestAgent
	}
	req.Header.Set("User-Agent", userAgent)
	req.Header.Set("Accept", "*/*")

	start := time.Now()
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return Result{}, fmt.Errorf("subscription: fetch: %w", err)
	}
	defer func() { _ = resp.Body.Close() }()

	body, err := io.ReadAll(io.LimitReader(resp.Body, maxBody))
	if err != nil {
		return Result{}, fmt.Errorf("subscription: read body: %w", err)
	}
	if resp.StatusCode != http.StatusOK {
		return Result{Bytes: len(body), Took: time.Since(start)},
			fmt.Errorf("subscription: %s returned HTTP %d%s", rawURL, resp.StatusCode, bodyHint(body))
	}

	format, err := DetectFormat(body)
	if err != nil {
		return Result{}, fmt.Errorf("subscription: %s returned neither Clash YAML nor a V2Ray list (%d bytes)%s",
			rawURL, len(body), bodyHint(body))
	}
	nodes, err := Parse(format, body)
	if err != nil {
		return Result{}, err
	}
	return Result{Format: format, Nodes: nodes, Bytes: len(body), Took: time.Since(start)}, nil
}

// bodyHint quotes the beginning of a response that was not a subscription. A
// provider's "device limit reached" or "app not supported" is the actual answer
// to the user's question, so it belongs in the error, not in a byte count.
func bodyHint(body []byte) string {
	text := strings.Join(strings.Fields(strings.ToValidUTF8(string(body), "")), " ")
	if text == "" {
		return ""
	}
	if len([]rune(text)) > 160 {
		text = string([]rune(text)[:160]) + "…"
	}
	return ": " + strconv.Quote(text)
}

// DetectFormat decides which parser applies. Clash documents start with YAML,
// V2Ray subscriptions are base64 blobs that decode to a URI list.
func DetectFormat(body []byte) (string, error) {
	trimmed := strings.TrimSpace(string(body))
	if trimmed == "" {
		return "", fmt.Errorf("%w: empty body", ErrUnknownFormat)
	}
	if strings.Contains(trimmed, "proxies:") {
		return FormatClash, nil
	}
	if decoded, ok := decodeBase64(trimmed); ok && strings.Contains(decoded, "://") {
		return FormatV2Ray, nil
	}
	return "", fmt.Errorf("%w: %d bytes", ErrUnknownFormat, len(body))
}

// Parse decodes body using the named format.
func Parse(format string, body []byte) ([]config.Node, error) {
	switch format {
	case FormatClash:
		return parseClash(body)
	case FormatV2Ray:
		decoded, ok := decodeBase64(strings.TrimSpace(string(body)))
		if !ok {
			return nil, fmt.Errorf("%w: body is not base64", ErrUnknownFormat)
		}
		return parseURIs(decoded), nil
	default:
		return nil, fmt.Errorf("%w: %q", ErrUnknownFormat, format)
	}
}

func decodeBase64(s string) (string, bool) {
	s = strings.Map(func(r rune) rune {
		if r == '\n' || r == '\r' || r == ' ' || r == '\t' {
			return -1
		}
		return r
	}, s)
	encodings := []*base64.Encoding{
		base64.StdEncoding, base64.RawStdEncoding,
		base64.URLEncoding, base64.RawURLEncoding,
	}
	for _, enc := range encodings {
		if out, err := enc.DecodeString(s); err == nil {
			return string(out), true
		}
	}
	return "", false
}
