package subscription

import (
	"strings"

	"github.com/mrazowner/barewire/internal/config"
)

// IsShareLink reports whether the text is a single share link (or a list of
// them, one per line) for a protocol this client can dial.
func IsShareLink(text string) bool {
	lower := strings.ToLower(strings.TrimSpace(text))
	for _, scheme := range []string{
		"vless://", "vmess://", "trojan://", "ss://",
		"hysteria2://", "hy2://", "tuic://",
	} {
		if strings.HasPrefix(lower, scheme) {
			return true
		}
	}
	return false
}

// ParseLinks turns one or more share links (one per line) into nodes. Links that
// cannot be parsed are skipped: a pasted list usually contains a few.
func ParseLinks(text string) []config.Node {
	return parseURIs(text)
}
