package subscription

import "testing"

func TestURIVlessRealityWS(t *testing.T) {
	line := "vless://11111111-2222-3333-4444-555555555555@de1.example.net:443" +
		"?encryption=none&security=reality&sni=de1.example.net&fp=chrome&pbk=PUB&sid=ab" +
		"&flow=xtls-rprx-vision&type=ws&path=%2Fray&host=cdn.example.net#Frankfurt"
	out, ok := uriOutbound(line)
	if !ok {
		t.Fatal("uri not parsed")
	}
	if out["server"] != "de1.example.net" || out["server_port"] != 443 {
		t.Fatalf("endpoint: %v", out)
	}
	tls := asObj(out["tls"])
	if tls["server_name"] != "de1.example.net" {
		t.Fatalf("tls: %v", tls)
	}
	reality := asObj(tls["reality"])
	if reality["public_key"] != "PUB" || reality["short_id"] != "ab" {
		t.Fatalf("reality: %v", reality)
	}
	if fp := asObj(tls["utls"])["fingerprint"]; fp != "chrome" {
		t.Fatalf("utls: %v", fp)
	}
	ws := asObj(out["transport"])
	if ws["path"] != "/ray" || asObj(ws["headers"])["Host"] != "cdn.example.net" {
		t.Fatalf("ws: %v", ws)
	}
	if out["flow"] != "xtls-rprx-vision" {
		t.Fatalf("flow: %v", out["flow"])
	}
}

func TestURIVmessWS(t *testing.T) {
	// {"ps":"SG","add":"sg.example.net","port":"443","id":"abc","aid":"0","net":"ws",
	//  "host":"cdn.example.net","path":"/v","tls":"tls","sni":"sg.example.net"}
	encoded := "eyJwcyI6IlNHIiwiYWRkIjoic2cuZXhhbXBsZS5uZXQiLCJwb3J0IjoiNDQzIiwiaWQiOiJhYmMiLCJhaWQiOiIwIiwibmV0Ijoid3MiLCJob3N0IjoiY2RuLmV4YW1wbGUubmV0IiwicGF0aCI6Ii92IiwidGxzIjoidGxzIiwic25pIjoic2cuZXhhbXBsZS5uZXQifQ=="
	nodes := parseURIs("vmess://" + encoded)
	if len(nodes) != 1 {
		t.Fatalf("got %d nodes", len(nodes))
	}
	if nodes[0].Name != "SG" {
		t.Fatalf("name = %q", nodes[0].Name)
	}
	out := outboundOf(t, nodes[0].Outbound)
	if out["type"] != "vmess" || out["uuid"] != "abc" || out["server_port"] != float64(443) {
		t.Fatalf("vmess: %v", out)
	}
	if nested(t, out, "transport")["path"] != "/v" {
		t.Fatalf("ws: %v", out["transport"])
	}
	if nested(t, out, "tls")["server_name"] != "sg.example.net" {
		t.Fatalf("tls: %v", out["tls"])
	}
}

func TestURIShadowsocksSIP002(t *testing.T) {
	// base64("aes-256-gcm:pass")
	line := "ss://YWVzLTI1Ni1nY206cGFzcw==@fi3.example.net:8388#Helsinki"
	out, ok := uriOutbound(line)
	if !ok {
		t.Fatal("uri not parsed")
	}
	if out["method"] != "aes-256-gcm" || out["password"] != "pass" || out["server"] != "fi3.example.net" {
		t.Fatalf("ss: %v", out)
	}
}

func TestURIHysteria2Obfs(t *testing.T) {
	line := "hysteria2://pw@se5.example.net:443?sni=se5.example.net&obfs=salamander&obfs-password=ob&insecure=1#Stockholm"
	out, ok := uriOutbound(line)
	if !ok {
		t.Fatal("uri not parsed")
	}
	if out["password"] != "pw" {
		t.Fatalf("password: %v", out)
	}
	if obfs := asObj(out["obfs"]); obfs["type"] != "salamander" || obfs["password"] != "ob" {
		t.Fatalf("obfs: %v", obfs)
	}
	if asObj(out["tls"])["insecure"] != true {
		t.Fatal("insecure flag lost")
	}
}

func TestURITuic(t *testing.T) {
	line := "tuic://uuid-1:pw@tu1.example.net:8443?congestion_control=bbr&alpn=h3&sni=tu1.example.net#Tuic"
	out, ok := uriOutbound(line)
	if !ok {
		t.Fatal("uri not parsed")
	}
	if out["uuid"] != "uuid-1" || out["password"] != "pw" || out["congestion_control"] != "bbr" {
		t.Fatalf("tuic: %v", out)
	}
	if asObj(out["tls"])["enabled"] != true {
		t.Fatal("tuic must always use TLS")
	}
}

func TestUnparsableURIIsSkipped(t *testing.T) {
	nodes := parseURIs("ss://not-base64@host:1#x\nvless://missing-port@host#y\nrandom text")
	if len(nodes) != 0 {
		t.Fatalf("expected no nodes, got %+v", nodes)
	}
}
