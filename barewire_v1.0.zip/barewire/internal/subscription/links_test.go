package subscription

import "testing"

// The exact link a user pasted: REALITY, vk.com SNI, non-standard port.
const userRealityLink = `vless://ada8a202-5356-448d-8dec-8193a6b05f1c@2.26.72.167:55023` +
	`?type=tcp&encryption=none&security=reality&pbk=FvBYKIEvdEU4q3STfph7oK2cQJrY3poTYCQ-26ucCU8` +
	`&fp=chrome&sni=vk.com&sid=fce552&spx=%2F#udj-puamcb9bs1`

func TestIsShareLink(t *testing.T) {
	for _, link := range []string{
		userRealityLink,
		"vmess://abc",
		"trojan://pw@host:443#x",
		"ss://YWVzLTI1Ni1nY206cGFzcw==@host:8388#x",
		"hysteria2://pw@host:443#x",
		"hy2://pw@host:443#x",
		"tuic://u:p@host:443#x",
	} {
		if !IsShareLink(link) {
			t.Errorf("IsShareLink(%q) = false", link)
		}
	}
	for _, text := range []string{"https://example.com/sub", "", "hello", "vless:/broken"} {
		if IsShareLink(text) {
			t.Errorf("IsShareLink(%q) = true", text)
		}
	}
}

func TestParseUserRealityLink(t *testing.T) {
	nodes := ParseLinks(userRealityLink)
	if len(nodes) != 1 {
		t.Fatalf("got %d nodes", len(nodes))
	}
	n := nodes[0]
	if n.Name != "udj-puamcb9bs1" || n.Kind != "vless" || n.Address != "2.26.72.167" || n.Port != 55023 {
		t.Fatalf("node = %+v", n)
	}
	if !n.Connectable() {
		t.Fatal("the node must carry a complete outbound")
	}

	out := outboundOf(t, n.Outbound)
	if out["type"] != "vless" || out["uuid"] != "ada8a202-5356-448d-8dec-8193a6b05f1c" {
		t.Fatalf("outbound = %v", out)
	}
	if _, hasFlow := out["flow"]; hasFlow {
		t.Fatalf("a link without flow must not invent one: %v", out["flow"])
	}
	if _, hasTransport := out["transport"]; hasTransport {
		t.Fatalf("type=tcp must not add a transport: %v", out["transport"])
	}
	tls := nested(t, out, "tls")
	if tls["enabled"] != true || tls["server_name"] != "vk.com" {
		t.Fatalf("tls = %v", tls)
	}
	reality := nested(t, tls, "reality")
	if reality["public_key"] != "FvBYKIEvdEU4q3STfph7oK2cQJrY3poTYCQ-26ucCU8" || reality["short_id"] != "fce552" {
		t.Fatalf("reality = %v", reality)
	}
	if fp := nested(t, tls, "utls")["fingerprint"]; fp != "chrome" {
		t.Fatalf("utls = %v", fp)
	}
}

func TestParseLinksHandlesAList(t *testing.T) {
	body := userRealityLink + "\n\nnot a link\n" +
		"trojan://pw@example.net:443#second\n"
	nodes := ParseLinks(body)
	if len(nodes) != 2 {
		t.Fatalf("got %d nodes: %+v", len(nodes), nodes)
	}
	if nodes[0].Name != "udj-puamcb9bs1" || nodes[1].Name != "second" {
		t.Fatalf("order lost: %+v", nodes)
	}
}
