package core

import (
	"strings"
	"testing"

	"github.com/mrazowner/barewire/internal/version"
)

// The interface shows this string, and the host binary is the one that links the
// core. A hardcoded constant said 1.14 while the binary embedded 1.15, so the
// check is that the value comes from the build info and carries a real version.
func TestCoreVersionIsReported(t *testing.T) {
	got := version.Core()
	ver, ok := strings.CutPrefix(got, "sing-box ")
	if !ok {
		t.Fatalf("Core() = %q, want the sing-box prefix", got)
	}
	if ver == "" || !strings.HasPrefix(ver, "1.") {
		t.Fatalf("Core() = %q, want a version read from the build info", got)
	}
	if strings.HasPrefix(ver, "v") {
		t.Fatalf("Core() = %q keeps the module's v prefix", got)
	}
}
