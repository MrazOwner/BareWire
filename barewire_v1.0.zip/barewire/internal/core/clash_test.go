package core

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

const connectionsFixture = `{
	"uploadTotal": 4096,
	"downloadTotal": 65536,
	"connections": [
		{
			"id": "1a2b3c",
			"metadata": {"network": "tcp", "host": "example.org", "destinationPort": "443"},
			"chains": ["proxy", "direct"],
			"rule": "geosite",
			"rulePayload": "geolocation-!cn",
			"start": "2026-11-07T15:00:00.123456789Z",
			"upload": 100,
			"download": 2000
		},
		{
			"id": "4d5e6f",
			"metadata": {"network": "udp", "destinationIP": "1.1.1.1", "destinationPort": "53"},
			"chains": ["proxy"],
			"rule": ""
		}
	]
}`

func TestFetchConnections(t *testing.T) {
	var sawAuth string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/connections" {
			t.Errorf("path = %s", r.URL.Path)
		}
		sawAuth = r.Header.Get("Authorization")
		_, _ = w.Write([]byte(connectionsFixture))
	}))
	defer srv.Close()

	stats, err := fetchConnections(context.Background(), srv.Client(),
		strings.TrimPrefix(srv.URL, "http://"), "secret-token")
	if err != nil {
		t.Fatalf("fetch: %v", err)
	}
	if sawAuth != "Bearer secret-token" {
		t.Fatalf("authorization header = %q", sawAuth)
	}
	if stats.UploadTotal != 4096 || stats.DownloadTotal != 65536 {
		t.Fatalf("totals: %+v", stats)
	}
	if len(stats.Items) != 2 {
		t.Fatalf("items: %+v", stats.Items)
	}
	first := stats.Items[0]
	if first.Host != "example.org:443" || first.Network != "tcp" {
		t.Fatalf("host/network: %+v", first)
	}
	if first.Rule != "geosite:geolocation-!cn" {
		t.Fatalf("rule = %q", first.Rule)
	}
	if first.Outbound != "proxy → direct" {
		t.Fatalf("chains = %q", first.Outbound)
	}
	if first.Since.IsZero() {
		t.Fatal("start time not parsed")
	}
	if second := stats.Items[1]; second.Host != "1.1.1.1:53" || second.Rule != "" {
		t.Fatalf("second item: %+v", second)
	}
}

func TestFetchConnectionsHTTPError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusUnauthorized)
	}))
	defer srv.Close()
	if _, err := fetchConnections(context.Background(), srv.Client(),
		strings.TrimPrefix(srv.URL, "http://"), ""); err == nil {
		t.Fatal("expected an error for HTTP 401")
	}
}

func TestRuleText(t *testing.T) {
	cases := []struct{ rule, payload, want string }{
		{"", "", ""},
		{"final", "", "final"},
		{"", "payload", "payload"},
		{"domain", "example.org", "domain:example.org"},
	}
	for _, c := range cases {
		if got := ruleText(c.rule, c.payload); got != c.want {
			t.Errorf("ruleText(%q, %q) = %q, want %q", c.rule, c.payload, got, c.want)
		}
	}
}

func TestParseStart(t *testing.T) {
	if parseStart("2026-11-07T15:00:00Z").IsZero() {
		t.Fatal("RFC3339 start time not parsed")
	}
	if !parseStart("garbage").IsZero() {
		t.Fatal("garbage must yield the zero time")
	}
}

func TestClashAddressFromOptions(t *testing.T) {
	raw := []byte(`{
		"outbounds": [{"type": "direct", "tag": "direct"}],
		"experimental": {"clash_api": {"external_controller": "127.0.0.1:9090", "secret": "s"}}
	}`)
	opts, err := Decode(context.Background(), raw)
	if err != nil {
		t.Fatalf("decode: %v", err)
	}
	if got := clashAddress(opts); got != "127.0.0.1:9090" {
		t.Fatalf("address = %q", got)
	}
	if got := clashSecret(opts); got != "s" {
		t.Fatalf("secret = %q", got)
	}
	empty, err := Decode(context.Background(), []byte(`{"outbounds":[{"type":"direct"}]}`))
	if err != nil {
		t.Fatalf("decode minimal: %v", err)
	}
	if clashAddress(empty) != "" {
		t.Fatal("address must be empty without the section")
	}
}
