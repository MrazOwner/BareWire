// Package core runs sing-box inside the host process. It owns the instance
// lifecycle, turns core logs into events and polls the local statistics API.
package core

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/sagernet/sing-box"
	"github.com/sagernet/sing-box/include"
	boxlog "github.com/sagernet/sing-box/log"
	"github.com/sagernet/sing-box/option"
	singjson "github.com/sagernet/sing/common/json"

	"github.com/charmbracelet/x/ansi"

	"github.com/mrazowner/barewire/internal/proto"
)

// ErrNotRunning is returned when the core is asked to stop twice.
var ErrNotRunning = errors.New("core: not running")

// Engine is one sing-box instance at a time. Restart is Stop then Start: the
// host decides when that happens, the engine never retries on its own.
type Engine struct {
	mu      sync.Mutex
	box     *box.Box
	cancel  context.CancelFunc
	done    chan struct{}
	running bool
	conns   []proto.Connection
	// lastOK is when the statistics API last answered. The host's watchdog uses
	// it to tell "busy" from "wedged": a core that is up as far as the process
	// knows but silent on its own API is the failure the user cannot see.
	lastOK time.Time

	onLog    func(proto.LogEntry)
	onSample func(proto.Sample)
	// onStall is called once when the statistics API stops answering: the
	// instance is up as far as the host knows, and something inside it is not.
	onStall func()
}

// statsStallThreshold is how many consecutive polls must fail before the core is
// reported as not answering. The poll interval apart, so a brief hiccup stays
// quiet; a core whose own API has been silent for half a minute is wedged.
const statsStallThreshold = 20

// healthyWindow is how recent the last successful poll must be for the core to
// count as answering. It is wider than the poll interval so that one slow poll
// never looks like a dead core.
const healthyWindow = 15 * time.Second

// New creates an engine. The callbacks are called from the core goroutines and
// must not block.
func New(onLog func(proto.LogEntry), onSample func(proto.Sample)) *Engine {
	if onLog == nil {
		onLog = func(proto.LogEntry) {}
	}
	if onSample == nil {
		onSample = func(proto.Sample) {}
	}
	return &Engine{onLog: onLog, onSample: onSample}
}

// Decode validates a configuration document with the real sing-box decoder. A
// configuration that fails here never reaches Start, so a bad apply leaves the
// previous instance untouched.
func Decode(ctx context.Context, raw []byte) (option.Options, error) {
	var opts option.Options
	if err := singjson.UnmarshalContext(include.Context(ctx), raw, &opts); err != nil {
		return option.Options{}, fmt.Errorf("core: invalid config: %w", err)
	}
	return opts, nil
}

// Start brings the core up with the given configuration document.
func (e *Engine) Start(ctx context.Context, raw []byte) error {
	if _, err := Decode(ctx, raw); err != nil {
		return err
	}

	var opts option.Options
	if err := singjson.UnmarshalContext(include.Context(ctx), raw, &opts); err != nil {
		return fmt.Errorf("core: invalid config: %w", err)
	}
	// The interface renders these lines itself: no colour escapes, no clock.
	if opts.Log == nil {
		opts.Log = &option.LogOptions{Level: "info"}
	}
	opts.Log.DisableColor = true

	e.mu.Lock()
	if e.running {
		e.mu.Unlock()
		return errors.New("core: already running")
	}
	e.mu.Unlock()

	wctx, cancel := context.WithCancel(ctx)
	instance, err := box.New(box.Options{
		Context:           include.Context(wctx),
		Options:           opts,
		PlatformLogWriter: platformWriter{fn: e.logLine},
	})
	if err != nil {
		cancel()
		return fmt.Errorf("core: build instance: %w", err)
	}
	if err := instance.Start(); err != nil {
		_ = instance.Close()
		cancel()
		return fmt.Errorf("core: start: %w", err)
	}

	done := make(chan struct{})
	e.mu.Lock()
	e.box = instance
	e.cancel = cancel
	e.done = done
	e.running = true
	e.lastOK = time.Now()
	e.mu.Unlock()

	if address := clashAddress(opts); address != "" {
		go e.pollStats(wctx, done, address, clashSecret(opts))
	} else {
		close(done)
	}
	return nil
}

// Stop tears the instance down. The TUN device and firewall marks go away with
// it; the host's kill-switch ruleset is managed outside this package.
func (e *Engine) Stop() error {
	e.mu.Lock()
	if !e.running {
		e.mu.Unlock()
		return ErrNotRunning
	}
	instance := e.box
	cancel := e.cancel
	done := e.done
	e.box = nil
	e.cancel = nil
	e.done = nil
	e.running = false
	e.mu.Unlock()

	cancel()
	<-done
	if instance != nil {
		if err := instance.Close(); err != nil {
			return fmt.Errorf("core: close: %w", err)
		}
	}
	return nil
}

// Running reports whether an instance is up.
func (e *Engine) Running() bool {
	e.mu.Lock()
	defer e.mu.Unlock()
	return e.running
}

// Healthy reports whether the core is up and its own statistics API answered
// recently. The host's watchdog restarts a core that stops answering, which is
// the one failure mode a user reads as "the VPN stopped working".
func (e *Engine) Healthy() bool {
	e.mu.Lock()
	defer e.mu.Unlock()
	if !e.running {
		return false
	}
	return !e.lastOK.IsZero() && time.Since(e.lastOK) < healthyWindow
}

// markHealthy records that the API answered.
func (e *Engine) markHealthy() {
	e.mu.Lock()
	e.lastOK = time.Now()
	e.mu.Unlock()
}

// SetStallHandler registers a callback for a core that stopped answering. It must
// be called before Start.
func (e *Engine) SetStallHandler(fn func()) {
	e.mu.Lock()
	e.onStall = fn
	e.mu.Unlock()
}

// logLine records one core line.
func (e *Engine) logLine(entry proto.LogEntry) {
	e.onLog(entry)
}

func clashAddress(opts option.Options) string {
	if opts.Experimental == nil || opts.Experimental.ClashAPI == nil {
		return ""
	}
	return opts.Experimental.ClashAPI.ExternalController
}

func clashSecret(opts option.Options) string {
	if opts.Experimental == nil || opts.Experimental.ClashAPI == nil {
		return ""
	}
	return opts.Experimental.ClashAPI.Secret
}

// platformWriter receives every core log line. It exists so the core never
// writes to the terminal the user is looking at.
type platformWriter struct {
	fn func(proto.LogEntry)
}

func (w platformWriter) WriteMessage(level boxlog.Level, message string) {
	w.fn(proto.LogEntry{
		Time:   time.Now(),
		Level:  mapLevel(level),
		Source: logSource(message),
		// Defence in depth: even with colours disabled, nothing that looks like
		// an escape sequence may reach the interface.
		Text: ansi.Strip(message),
	})
}

func mapLevel(level boxlog.Level) proto.LogLevel {
	switch level {
	case boxlog.LevelTrace, boxlog.LevelDebug:
		return proto.LevelDebug
	case boxlog.LevelWarn:
		return proto.LevelWarn
	case boxlog.LevelError, boxlog.LevelFatal, boxlog.LevelPanic:
		return proto.LevelError
	default:
		return proto.LevelInfo
	}
}

// logSource pulls the logger name out of messages such as
// "outbound/vless[proxy]: connected" or "router: match[0] => proxy".
func logSource(message string) string {
	idx := strings.Index(message, ": ")
	if idx <= 0 || idx > 48 {
		return "core"
	}
	head := message[:idx]
	if strings.ContainsAny(head, " \t") {
		return "core"
	}
	return head
}
