package core

import (
	"context"
	"testing"
	"time"
)

// A core that stops answering its own API must be reported: otherwise the link
// says "connected" while nothing loads, and the user reconnects by hand with no
// idea what happened.
func TestPollStatsReportsAStall(t *testing.T) {
	old := statsPollInterval
	statsPollInterval = time.Millisecond
	defer func() { statsPollInterval = old }()

	e := New(nil, nil)
	stalled := make(chan struct{}, 1)
	e.SetStallHandler(func() {
		select {
		case stalled <- struct{}{}:
		default:
		}
	})

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go e.pollStats(ctx, done, "127.0.0.1:1", "")

	select {
	case <-stalled:
	case <-time.After(5 * time.Second):
		t.Fatal("a core that never answers was not reported")
	}
	cancel()
	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("pollStats did not stop with its context")
	}
}
