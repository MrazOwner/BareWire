package core

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
	coreconf "github.com/mrazowner/barewire/internal/core/config"
)

// The direct lists must survive the real decoder: a bare address in ip_cidr, a
// keyword in the domain rule and a quoted process pattern are the parts most
// likely to drift from what sing-box accepts.
func TestGeneratedConfigBypass(t *testing.T) {
	node := config.Node{
		Name:    "de1",
		Kind:    "vless",
		Address: "de1.example.net",
		Port:    443,
		Outbound: json.RawMessage(`{"type":"vless","server":"de1.example.net","server_port":443,` +
			`"uuid":"11111111-2222-3333-4444-555555555555"}`),
	}
	for _, mode := range []string{"fakeip", "direct", "disabled"} {
		s := config.Defaults()
		s.DNS.Mode = mode
		s.Bypass = config.BypassSettings{
			IPs:       []string{"10.0.0.0/8", "192.168.1.1", "fdfe::/16"},
			Domains:   []string{"example.com", "*steam*"},
			Processes: []string{"steam", "a+b", "msedge web"},
		}
		raw, err := coreconf.Build(coreconf.Input{
			Settings: s,
			Node:     node,
			TUNName:  "bw0",
			MTU:      1420,
			StateDir: t.TempDir(),
		})
		if err != nil {
			t.Fatalf("build (%s): %v", mode, err)
		}
		var doc map[string]any
		if err := json.Unmarshal(raw, &doc); err != nil {
			t.Fatalf("unmarshal (%s): %v", mode, err)
		}
		route, _ := doc["route"].(map[string]any)
		rules, _ := route["rules"].([]any)
		if len(rules) != 4 {
			t.Fatalf("%s: want a sniff rule plus one per kind, got %v", mode, route["rules"])
		}
		if first, _ := rules[0].(map[string]any); first["action"] != "sniff" {
			t.Fatalf("%s: first rule = %v", mode, rules[0])
		}
		if _, err := Decode(context.Background(), raw); err != nil {
			t.Fatalf("decode (%s): %v", mode, err)
		}
	}
}

// Every stack in the list must be one the core accepts. sing-tun is the library
// behind all three, so there is no fourth value to add: "sing-tun" as a stack
// name would be rejected by the core at start.
func TestGeneratedConfigStacks(t *testing.T) {
	node := config.Node{
		Name:    "de1",
		Kind:    "vless",
		Address: "de1.example.net",
		Port:    443,
		Outbound: json.RawMessage(`{"type":"vless","server":"de1.example.net","server_port":443,` +
			`"uuid":"11111111-2222-3333-4444-555555555555"}`),
	}
	for _, stack := range config.TUNStacks {
		s := config.Defaults()
		s.TUNStack = stack
		// Multi-queue is only meaningful on sing-tun's own stack; the config must
		// drop it for the others instead of failing in the core.
		s.MultiQueue = true
		raw, err := coreconf.Build(coreconf.Input{
			Settings: s,
			Node:     node,
			TUNName:  "bw0",
			MTU:      1420,
			StateDir: t.TempDir(),
		})
		if err != nil {
			t.Fatalf("build (%s): %v", stack, err)
		}
		var cfg map[string]any
		if err := json.Unmarshal(raw, &cfg); err != nil {
			t.Fatalf("unmarshal (%s): %v", stack, err)
		}
		inbounds, _ := cfg["inbounds"].([]any)
		if len(inbounds) == 0 {
			t.Fatalf("no inbounds (%s)", stack)
		}
		tun, _ := inbounds[0].(map[string]any)
		if stack == config.TUNStackSingTun {
			// sing-tun's own stack is selected by leaving the field out.
			if got, ok := tun["stack"]; ok {
				t.Fatalf("sing-tun written as stack = %v", got)
			}
			if tun["multi_queue"] != true {
				t.Fatalf("multi_queue missing on sing-tun's own stack")
			}
		} else {
			if tun["stack"] != stack {
				t.Fatalf("%s: stack = %v", stack, tun["stack"])
			}
			// The core rejects multi_queue on any other stack, so it must not be sent.
			if got, ok := tun["multi_queue"]; ok {
				t.Fatalf("%s: multi_queue sent as %v", stack, got)
			}
		}
		if _, err := Decode(context.Background(), raw); err != nil {
			t.Fatalf("decode (%s): %v", stack, err)
		}
	}
}

// A generated config must parse with the real core, with and without IPv6: the
// AAAA rule and the family-dependent DNS section are the parts most likely to
// drift from what sing-box accepts.
func TestGeneratedConfigDecodes(t *testing.T) {
	node := config.Node{
		Name:    "de1",
		Kind:    "vless",
		Address: "de1.example.net",
		Port:    443,
		Outbound: json.RawMessage(`{"type":"vless","server":"de1.example.net","server_port":443,` +
			`"uuid":"11111111-2222-3333-4444-555555555555"}`),
	}
	for _, mode := range []string{"fakeip", "direct"} {
		for _, v6 := range []bool{true, false} {
			s := config.Defaults()
			s.DNS.Mode = mode
			s.DNS.UseIPv6 = v6
			raw, err := coreconf.Build(coreconf.Input{
				Settings: s,
				Node:     node,
				TUNName:  "bw0",
				MTU:      1420,
				StateDir: t.TempDir(),
			})
			if err != nil {
				t.Fatalf("build (%s, ipv6=%v): %v", mode, v6, err)
			}
			if _, err := Decode(context.Background(), raw); err != nil {
				t.Fatalf("decode (%s, ipv6=%v): %v", mode, v6, err)
			}
		}
	}
}
