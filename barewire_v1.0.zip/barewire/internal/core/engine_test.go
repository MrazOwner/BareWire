package core

import (
	"context"
	"strings"
	"testing"

	boxlog "github.com/sagernet/sing-box/log"

	"github.com/mrazowner/barewire/internal/proto"
)

func TestDecodeAcceptsValidConfig(t *testing.T) {
	raw := []byte(`{
		"log": {"level": "info", "disabled": true},
		"outbounds": [{"type": "direct", "tag": "direct"}],
		"route": {"final": "direct"}
	}`)
	if _, err := Decode(context.Background(), raw); err != nil {
		t.Fatalf("decode: %v", err)
	}
}

func TestDecodeRejectsBrokenConfig(t *testing.T) {
	cases := []string{
		`{`,
		`{"outbounds": [{"type": "telepathy", "tag": "x"}]}`,
		`{"inbounds": [{"type": "tun", "mtu": "big"}]}`,
	}
	for _, raw := range cases {
		if _, err := Decode(context.Background(), []byte(raw)); err == nil {
			t.Fatalf("expected an error for %s", raw)
		}
	}
}

func TestMapLevel(t *testing.T) {
	cases := map[boxlog.Level]proto.LogLevel{
		boxlog.LevelTrace: proto.LevelDebug,
		boxlog.LevelDebug: proto.LevelDebug,
		boxlog.LevelInfo:  proto.LevelInfo,
		boxlog.LevelWarn:  proto.LevelWarn,
		boxlog.LevelError: proto.LevelError,
		boxlog.LevelFatal: proto.LevelError,
	}
	for in, want := range cases {
		if got := mapLevel(in); got != want {
			t.Errorf("mapLevel(%d) = %q, want %q", in, got, want)
		}
	}
}

func TestLogSource(t *testing.T) {
	cases := map[string]string{
		"outbound/vless[proxy]: connected to de1.example.net:443": "outbound/vless[proxy]",
		"router: match[0] => proxy":                               "router",
		"adapter: DNS query example.org":                          "adapter",
		"no separator here":                                       "core",
		"":                                                        "core",
		"this is a long sentence without logger prefix: value": "core",
	}
	for in, want := range cases {
		if got := logSource(in); got != want {
			t.Errorf("logSource(%q) = %q, want %q", in, got, want)
		}
	}
}

func TestPlatformWriterKeepsLevelAndSource(t *testing.T) {
	var got []proto.LogEntry
	writer := platformWriter{fn: func(e proto.LogEntry) { got = append(got, e) }}
	writer.WriteMessage(boxlog.LevelWarn, "dns: lookup failed")
	if len(got) != 1 || got[0].Level != proto.LevelWarn || got[0].Source != "dns" {
		t.Fatalf("unexpected entry: %+v", got)
	}
}

func TestConnectionsSnapshotIsCopy(t *testing.T) {
	e := New(nil, nil)
	e.mu.Lock()
	e.conns = []proto.Connection{{ID: 1, Host: "a"}}
	e.mu.Unlock()
	got := e.Connections()
	got[0].Host = "b"
	if e.Connections()[0].Host != "a" {
		t.Fatal("Connections must return a copy")
	}
}

func TestPlatformWriterStripsANSI(t *testing.T) {
	var got []proto.LogEntry
	writer := platformWriter{fn: func(e proto.LogEntry) { got = append(got, e) }}
	writer.WriteMessage(boxlog.LevelError,
		"\x1b[31mERROR\x1b[0m[0034] [\x1b[38;5;46m42\x1b[0m 1.2s] connection: dial tcp: operation was canceled")
	if len(got) != 1 {
		t.Fatalf("got %d entries", len(got))
	}
	if strings.Contains(got[0].Text, "\x1b") {
		t.Fatalf("escape sequences reached the interface: %q", got[0].Text)
	}
	if !strings.Contains(got[0].Text, "connection: dial tcp: operation was canceled") {
		t.Fatalf("message body lost: %q", got[0].Text)
	}
	if got[0].Source != "core" {
		t.Fatalf("source = %q, want core", got[0].Source)
	}
}

func TestEngineStopWhenIdle(t *testing.T) {
	e := New(nil, nil)
	if err := e.Stop(); err != ErrNotRunning {
		t.Fatalf("err = %v, want ErrNotRunning", err)
	}
	if e.Running() {
		t.Fatal("engine must not report running")
	}
}
