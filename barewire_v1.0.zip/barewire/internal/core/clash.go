package core

import (
	"context"
	"encoding/json"
	"fmt"
	"hash/fnv"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/mrazowner/barewire/internal/proto"
)

// pollStats reads the local statistics API once per second. Polling is used
// instead of the websocket stream because one request already returns both the
// counters and the connection table.
// statsPollInterval is how often the statistics API is polled. It is a variable
// so that a test can prove the stall detector without waiting fifteen seconds.
var statsPollInterval = time.Second

func (e *Engine) pollStats(ctx context.Context, done chan struct{}, address, secret string) {
	defer close(done)

	client := &http.Client{Timeout: 5 * time.Second}
	ticker := time.NewTicker(statsPollInterval)
	defer ticker.Stop()

	var lastUp, lastDown uint64
	var lastAt time.Time
	first := true
	failures := 0

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}

		stats, err := fetchConnections(ctx, client, address, secret)
		if err != nil {
			e.onLog(proto.LogEntry{Time: time.Now(), Level: proto.LevelDebug, Source: "clash-api", Text: err.Error()})
			failures++
			if failures == 1 {
				// The first failure is worth a line of its own: everything after
				// it is the same story, and twenty identical lines hide the fact
				// that the link is about to be reported as dead.
				e.onLog(proto.LogEntry{Time: time.Now(), Level: proto.LevelWarn, Source: "clash-api", Text: "the statistics API stopped answering, watching it closely"})
			}
			if failures == statsStallThreshold {
				// The instance says it is running, yet its own API has not
				// answered: that is a core that is wedged, not a busy one, and
				// the user needs to know before wondering why nothing loads.
				// The watchdog decides what to do about it.
				e.mu.Lock()
				stall := e.onStall
				e.mu.Unlock()
				if stall != nil {
					stall()
				}
			}
			continue
		}
		if failures > 0 {
			e.onLog(proto.LogEntry{Time: time.Now(), Level: proto.LevelInfo, Source: "clash-api", Text: fmt.Sprintf("the statistics API is answering again after %d failed polls", failures)})
		}
		failures = 0
		e.markHealthy()

		now := time.Now()
		up, down := stats.UploadTotal, stats.DownloadTotal
		sample := proto.Sample{
			Time:        now,
			BytesUp:     up,
			BytesDown:   down,
			Connections: len(stats.Items),
		}
		if !first && !lastAt.IsZero() {
			elapsed := now.Sub(lastAt).Seconds()
			if elapsed > 0 && up >= lastUp {
				sample.UpBps = uint64(float64(up-lastUp) / elapsed)
			}
			if elapsed > 0 && down >= lastDown {
				sample.DownBps = uint64(float64(down-lastDown) / elapsed)
			}
		}
		first = false
		lastUp, lastDown, lastAt = up, down, now

		e.mu.Lock()
		e.conns = stats.Items
		e.mu.Unlock()

		e.onSample(sample)
	}
}

type clashStats struct {
	UploadTotal   uint64
	DownloadTotal uint64
	Items         []proto.Connection
}

type clashConnectionsResponse struct {
	UploadTotal   uint64 `json:"uploadTotal"`
	DownloadTotal uint64 `json:"downloadTotal"`
	Connections   []struct {
		ID          string         `json:"id"`
		Metadata    map[string]any `json:"metadata"`
		Chains      []string       `json:"chains"`
		Rule        string         `json:"rule"`
		RulePayload string         `json:"rulePayload"`
		Start       string         `json:"start"`
		Upload      uint64         `json:"upload"`
		Download    uint64         `json:"download"`
	} `json:"connections"`
}

// fetchConnections queries /connections on the local API.
func fetchConnections(ctx context.Context, client *http.Client, address, secret string) (clashStats, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, "http://"+address+"/connections", nil)
	if err != nil {
		return clashStats{}, err
	}
	if secret != "" {
		req.Header.Set("Authorization", "Bearer "+secret)
	}
	resp, err := client.Do(req)
	if err != nil {
		return clashStats{}, fmt.Errorf("clash-api: %w", err)
	}
	defer func() { _ = resp.Body.Close() }()
	if resp.StatusCode != http.StatusOK {
		return clashStats{}, fmt.Errorf("clash-api: HTTP %d", resp.StatusCode)
	}

	var body clashConnectionsResponse
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return clashStats{}, fmt.Errorf("clash-api: decode: %w", err)
	}

	stats := clashStats{UploadTotal: body.UploadTotal, DownloadTotal: body.DownloadTotal}
	stats.Items = make([]proto.Connection, 0, len(body.Connections))
	for _, c := range body.Connections {
		stats.Items = append(stats.Items, proto.Connection{
			ID:       connectionID(c.ID),
			Outbound: firstNonEmpty(c.Chains),
			Rule:     ruleText(c.Rule, c.RulePayload),
			Host:     hostText(c.Metadata),
			Network:  stringField(c.Metadata, "network"),
			Since:    parseStart(c.Start),
			Up:       c.Upload,
			Down:     c.Download,
		})
	}
	return stats, nil
}

// Connections is the connection table as the interface shows it.
func (e *Engine) Connections() []proto.Connection {
	e.mu.Lock()
	defer e.mu.Unlock()
	out := make([]proto.Connection, len(e.conns))
	copy(out, e.conns)
	return out
}

func connectionID(id string) uint64 {
	h := fnv.New64a()
	_, _ = h.Write([]byte(id))
	return h.Sum64()
}

// firstNonEmpty renders the outbound chain from the innermost outbound outward.
func firstNonEmpty(chains []string) string {
	if len(chains) == 0 {
		return ""
	}
	return strings.Join(chains, " → ")
}

func ruleText(rule, payload string) string {
	switch {
	case rule == "" && payload == "":
		return ""
	case payload == "":
		return rule
	case rule == "":
		return payload
	default:
		return rule + ":" + payload
	}
}

func hostText(metadata map[string]any) string {
	host := stringField(metadata, "host")
	port := stringField(metadata, "destinationPort")
	ip := stringField(metadata, "destinationIP")
	if host == "" {
		host = ip
	}
	if host == "" {
		return ""
	}
	if port == "" || strings.Contains(host, ":") {
		return host
	}
	return host + ":" + port
}

func stringField(m map[string]any, key string) string {
	v, ok := m[key]
	if !ok {
		return ""
	}
	switch t := v.(type) {
	case string:
		return t
	case float64:
		return strconv.FormatFloat(t, 'f', -1, 64)
	default:
		return ""
	}
}

func parseStart(raw string) time.Time {
	if raw == "" {
		return time.Time{}
	}
	if t, err := time.Parse(time.RFC3339Nano, raw); err == nil {
		return t
	}
	if t, err := time.Parse("2006-01-02T15:04:05.999999999-07:00", raw); err == nil {
		return t
	}
	return time.Time{}
}
