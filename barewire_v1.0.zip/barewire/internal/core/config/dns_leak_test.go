package coreconf

import (
	"testing"

	"github.com/mrazowner/barewire/internal/config"
)

// Resolver queries leave through the tunnel, always. Sending them out of the
// physical interface whenever the server was addressed by a name is what let the
// ISP answer lookups on providers that hand out domain endpoints.
func TestResolversAlwaysTraverseTheTunnel(t *testing.T) {
	s := config.Defaults()
	s.DNS.Mode = "direct"
	s.DNS.Servers = []string{"1.1.1.1", "9.9.9.9"}
	for _, node := range []config.Node{
		nodeOf("vless", "1.2.3.4", 443, `{"type":"vless","server":"1.2.3.4","server_port":443,"uuid":"u"}`),
		nodeOf("hysteria2", "de1.example.net", 443, `{"type":"hysteria2","server":"de1.example.net","server_port":443,"password":"p"}`),
	} {
		doc := buildDocFull(t, s, node, 0, false)
		dns, _ := doc["dns"].(map[string]any)
		servers, _ := dns["servers"].([]any)
		remote := 0
		for _, raw := range servers {
			srv, _ := raw.(map[string]any)
			if srv["type"] != "udp" {
				continue
			}
			remote++
			if srv["detour"] != "proxy" {
				t.Fatalf("%s: resolver %v does not go through the tunnel", node.Name, srv)
			}
		}
		if remote == 0 {
			t.Fatalf("%s: no remote resolver in the config", node.Name)
		}
	}
}

// The server's own name is the one lookup the tunnel cannot carry, so it is
// resolved locally by a bootstrap rule — and only that name.
func TestDomainServerGetsABootstrapRule(t *testing.T) {
	s := config.Defaults()
	s.DNS.Mode = "direct"
	node := nodeOf("hysteria2", "de1.example.net", 443,
		`{"type":"hysteria2","server":"de1.example.net","server_port":443,"password":"p"}`)
	doc := buildDocFull(t, s, node, 0, false)
	dns, _ := doc["dns"].(map[string]any)
	rules, _ := dns["rules"].([]any)
	// The rule that covers the server's own name points at the local resolver.
	if dnsRuleFor(t, dns, "local") == nil {
		t.Fatalf("no local rule at all: %v", rules)
	}
	route, _ := doc["route"].(map[string]any)
	if route["default_domain_resolver"] != "local" {
		t.Fatalf("default_domain_resolver = %v, want local", route["default_domain_resolver"])
	}

	// An IP-addressed server has no bootstrap and keeps the tunnelled resolver.
	ipNode := nodeOf("vless", "1.2.3.4", 443, `{"type":"vless","server":"1.2.3.4","server_port":443,"uuid":"u"}`)
	doc = buildDocFull(t, s, ipNode, 0, false)
	route, _ = doc["route"].(map[string]any)
	if route["default_domain_resolver"] == "local" {
		t.Fatal("an IP server must not use the local resolver")
	}
}

// Auto redirect is what steers the queries of a loopback stub resolver into the
// tunnel; without the field in the config the lever does nothing.
func TestAutoRedirectReachesTheTun(t *testing.T) {
	s := config.Defaults()
	s.AutoRedirect = true
	doc := buildDocFull(t, s, testNode(), 0, false)
	inbound := at(t, doc["inbounds"], 0)
	if inbound["auto_redirect"] != true {
		t.Fatalf("auto_redirect missing: %v", inbound)
	}
	s.AutoRedirect = false
	if inbound := at(t, buildDocFull(t, s, testNode(), 0, false)["inbounds"], 0); inbound["auto_redirect"] != nil {
		t.Fatalf("auto_redirect written while off: %v", inbound)
	}
}
