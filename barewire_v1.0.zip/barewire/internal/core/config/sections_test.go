package coreconf

import (
	"encoding/json"
	"errors"
	"strings"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
)

// The direct list is one list with three kinds of entry; each kind becomes one
// rule that points at the direct outbound, and order is preserved: IPs, sites,
// processes.
func TestBuildBypass(t *testing.T) {
	s := config.Defaults()
	s.Bypass = config.BypassSettings{
		IPs:       []string{"10.0.0.0/8", "192.168.1.1"},
		Domains:   []string{"example.com", ".internal.lan", "*steam*"},
		Processes: []string{"steam", "Telegram"},
	}
	doc := buildDoc(t, s, 0)
	route := doc["route"].(map[string]any)
	rules, ok := route["rules"].([]any)
	if !ok || len(rules) != 4 {
		t.Fatalf("want a sniff rule plus one rule per kind, got %v", route["rules"])
	}
	if at(t, route["rules"], 0)["action"] != "sniff" {
		t.Fatalf("a site rule needs a sniff rule in front of it: %v", at(t, route["rules"], 0))
	}

	ip := at(t, route["rules"], 1)
	cidrs, _ := ip["ip_cidr"].([]any)
	if len(cidrs) != 2 || cidrs[0] != "10.0.0.0/8" || ip["outbound"] != "direct" || ip["action"] != "route" {
		t.Fatalf("ip rule: %v", ip)
	}

	sites := at(t, route["rules"], 2)
	suffixes, _ := sites["domain_suffix"].([]any)
	keywords, _ := sites["domain_keyword"].([]any)
	if len(suffixes) != 2 || suffixes[0] != "example.com" || suffixes[1] != "internal.lan" {
		t.Fatalf("suffixes: %v", suffixes)
	}
	if len(keywords) != 1 || keywords[0] != "steam" {
		t.Fatalf("keywords: %v", keywords)
	}

	procs := at(t, route["rules"], 3)
	regexes, _ := procs["process_path_regex"].([]any)
	if len(regexes) != 2 || regexes[0] != "(?i)steam" || regexes[1] != "(?i)Telegram" {
		t.Fatalf("process regexes: %v", regexes)
	}
	if procs["outbound"] != "direct" {
		t.Fatalf("process rule: %v", procs)
	}
}

// An empty direct list must leave the route untouched: no rules, no empty
// matchers that would make the core do work for nothing.
func TestBuildBypassEmpty(t *testing.T) {
	doc := buildDoc(t, config.Defaults(), 0)
	route := doc["route"].(map[string]any)
	if rules, ok := route["rules"]; ok {
		t.Fatalf("no lists means no rules, got %v", rules)
	}
	if route["final"] != "proxy" {
		t.Fatalf("final: %v", route["final"])
	}
}

// Lists without a site entry need no sniffer: an address rule and a process rule
// both work on what the core already has.
func TestBuildBypassWithoutDomains(t *testing.T) {
	s := config.Defaults()
	s.Bypass = config.BypassSettings{
		IPs:       []string{"10.0.0.0/8"},
		Processes: []string{"steam"},
	}
	route := buildDoc(t, s, 0)["route"].(map[string]any)
	rules, _ := route["rules"].([]any)
	if len(rules) != 2 {
		t.Fatalf("want two rules, got %v", route["rules"])
	}
	for _, rule := range rules {
		if rule.(map[string]any)["action"] == "sniff" {
			t.Fatalf("no site rule, so no sniffer: %v", route["rules"])
		}
	}
}

// Regex metacharacters in a process name are literal, not a pattern: the user
// typed a name, not an expression.
func TestProcessRegexes(t *testing.T) {
	got := ProcessRegexes([]string{"steam", "msedge web", "a+b"})
	want := []string{"(?i)steam", "(?i)msedge web", `(?i)a\+b`}
	if len(got) != len(want) {
		t.Fatalf("got %v", got)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("entry %d: got %q, want %q", i, got[i], want[i])
		}
	}
}

func TestSplitDomains(t *testing.T) {
	suffixes, keywords := SplitDomains([]string{"example.com", ".foo.bar", "*steam*", "  ", "*"})
	if len(suffixes) != 2 || suffixes[0] != "example.com" || suffixes[1] != "foo.bar" {
		t.Fatalf("suffixes: %v", suffixes)
	}
	if len(keywords) != 1 || keywords[0] != "steam" {
		t.Fatalf("keywords: %v", keywords)
	}
}

func TestBuildDNSDirect(t *testing.T) {
	s := config.Defaults()
	s.DNS.Mode = "direct"
	s.DNS.Servers = []string{"9.9.9.9:5353", "149.112.112.112"}
	doc := buildDoc(t, s, 0)
	dns := doc["dns"].(map[string]any)
	first := at(t, dns["servers"], 0)
	if first["type"] != "udp" || first["server"] != "9.9.9.9" || first["server_port"] != float64(5353) {
		t.Fatalf("first server: %v", first)
	}
	if dns["final"] != "dns0" {
		t.Fatalf("final: %v", dns["final"])
	}
	for _, srv := range dns["servers"].([]any) {
		if srv.(map[string]any)["type"] == "fakeip" {
			t.Fatal("direct mode must not contain a fakeip server")
		}
	}
}

func TestBuildDNSDirectIPv4Only(t *testing.T) {
	s := config.Defaults()
	s.DNS.Mode = "direct"
	s.DNS.UseIPv6 = false
	s.DNS.Servers = []string{"9.9.9.9", "2620:fe::fe"}
	doc := buildDoc(t, s, 0)
	dns := doc["dns"].(map[string]any)
	rules, ok := dns["rules"].([]any)
	if !ok {
		t.Fatalf("direct DNS with IPv6 off needs rules: %v", dns["rules"])
	}
	// The server is addressed by a name, so one bootstrap rule comes first; the
	// AAAA answer is the rule this test is about.
	var rule map[string]any
	for _, raw := range rules {
		candidate, _ := raw.(map[string]any)
		if candidate["action"] == "predefined" {
			rule = candidate
		}
	}
	if rule == nil {
		t.Fatalf("no empty-AAAA rule: %v", rules)
	}
	if rule["rcode"] != "NOERROR" {
		t.Fatalf("AAAA must be answered with an empty reply, got %v", rule)
	}
	if types, _ := rule["query_type"].([]any); len(types) != 1 || types[0] != "AAAA" {
		t.Fatalf("query types: %v", rule["query_type"])
	}
	for _, srv := range dns["servers"].([]any) {
		m := srv.(map[string]any)
		if m["type"] != "udp" {
			continue
		}
		if addr, _ := m["server"].(string); strings.Contains(addr, ":") {
			t.Fatalf("IPv6 resolver kept while IPv6 is off: %v", m)
		}
	}
}

func TestBuildMTUResolution(t *testing.T) {
	s := config.Defaults()
	s.MTU = 0
	if got := at(t, buildDoc(t, s, 1400)["inbounds"], 0)["mtu"]; got != float64(1400) {
		t.Fatalf("resolved mtu not used: %v", got)
	}
	if got := at(t, buildDoc(t, s, 0)["inbounds"], 0)["mtu"]; got != float64(DefaultMTU) {
		t.Fatalf("default mtu not used: %v", got)
	}
	// The host lowers a configured value the path cannot carry; sending the
	// configured number anyway would undo the one fix that makes such a link work.
	s.MTU = 1488
	if got := at(t, buildDoc(t, s, 1390)["inbounds"], 0)["mtu"]; got != float64(1390) {
		t.Fatalf("the host's resolved mtu must win over the lever: %v", got)
	}
	// Without a resolved value the lever is all there is.
	s.MTU = 1280
	if got := at(t, buildDoc(t, s, 0)["inbounds"], 0)["mtu"]; got != float64(1280) {
		t.Fatalf("the lever must be the fallback: %v", got)
	}
}

func TestBuildBrutalEnablesMultiplex(t *testing.T) {
	s := config.Defaults()
	s.Smux.Enabled = false
	s.Brutal.Enabled = true
	s.Brutal.UpMbps = 10
	s.Brutal.DownMbps = 20
	proxy := at(t, buildDocFull(t, s, testNode(), 0, true)["outbounds"], 0)
	mux := proxy["multiplex"].(map[string]any)
	if mux["enabled"] != true || mux["protocol"] != "smux" {
		t.Fatalf("brutal must turn multiplexing on: %v", mux)
	}
}

func TestBuildWithoutNode(t *testing.T) {
	if _, err := Build(Input{Settings: config.Defaults()}); !errors.Is(err, ErrNoNode) {
		t.Fatalf("err = %v, want ErrNoNode", err)
	}
}

func TestBuildRejectsBrokenOutbound(t *testing.T) {
	node := testNode()
	node.Outbound = json.RawMessage(`{"type":"vless"}`)
	if _, err := Build(Input{Settings: config.Defaults(), Node: node}); err == nil {
		t.Fatal("expected an error for an outbound without a server")
	}
	node.Outbound = json.RawMessage(`{`)
	if _, err := Build(Input{Settings: config.Defaults(), Node: node}); err == nil {
		t.Fatal("expected an error for malformed JSON")
	}
}

func TestSplitServer(t *testing.T) {
	cases := []struct {
		in   string
		host string
		port int
	}{
		{"1.1.1.1", "1.1.1.1", 0},
		{"1.1.1.1:5353", "1.1.1.1", 5353},
		{"[2606:4700::1111]:53", "2606:4700::1111", 53},
		{"[2606:4700::1111]", "2606:4700::1111", 0},
		{"2606:4700::1111", "2606:4700::1111", 0},
		{"dns.example.net:443", "dns.example.net", 443},
	}
	for _, c := range cases {
		host, port := splitServer(c.in)
		if host != c.host || port != c.port {
			t.Errorf("splitServer(%q) = %q, %d; want %q, %d", c.in, host, port, c.host, c.port)
		}
	}
}
