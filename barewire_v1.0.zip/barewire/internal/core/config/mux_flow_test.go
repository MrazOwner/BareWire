package coreconf

import (
	"testing"

	"github.com/mrazowner/barewire/internal/config"
)

// A VLESS link issued with a flow cannot be multiplexed: xtls-rprx-vision wraps
// the stream itself. Asking for both produced a config the server would never
// accept, and the tunnel came up moving nothing.
func TestMultiplexIsNotWrittenForAFlow(t *testing.T) {
	s := config.Defaults()
	s.Smux.Enabled = true
	node := nodeOf("vless", "1.2.3.4", 443,
		`{"type":"vless","server":"1.2.3.4","server_port":443,`+
			`"uuid":"11111111-2222-3333-4444-555555555555","flow":"xtls-rprx-vision"}`)
	proxy := at(t, buildDocFull(t, s, node, 0, true)["outbounds"], 0)
	if _, ok := proxy["multiplex"]; ok {
		t.Fatalf("a flow link must not carry a multiplex section: %v", proxy["multiplex"])
	}
	if got := node.Flow(); got != "xtls-rprx-vision" {
		t.Fatalf("node flow = %q", got)
	}

	// The same link without a flow keeps it, so the rule is about the flow and not
	// about dropping multiplexing altogether.
	node = nodeOf("vless", "1.2.3.4", 443,
		`{"type":"vless","server":"1.2.3.4","server_port":443,`+
			`"uuid":"11111111-2222-3333-4444-555555555555"}`)
	proxy = at(t, buildDocFull(t, s, node, 0, true)["outbounds"], 0)
	mux, ok := proxy["multiplex"].(map[string]any)
	if !ok || mux["enabled"] != true {
		t.Fatalf("a plain vless link has to keep multiplexing: %v", proxy["multiplex"])
	}
	if got := node.Flow(); got != "" {
		t.Fatalf("flow = %q, want none", got)
	}
}
