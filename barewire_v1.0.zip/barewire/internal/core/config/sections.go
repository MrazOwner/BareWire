package coreconf

import (
	"fmt"
	"net"
	"regexp"
	"strconv"
	"strings"

	"github.com/mrazowner/barewire/internal/config"
)

// obj is a configuration object on its way to JSON.
type obj = map[string]any

// tunInbound builds the TUN inbound. strict_route is on because a VPN client
// that leaks around its own tunnel is not a VPN client.
func tunInbound(s config.Settings, name string, mtu int) obj {
	if name == "" {
		name = "barewire0"
	}
	addresses := []string{"172.19.0.1/30"}
	if s.DNS.UseIPv6 {
		addresses = append(addresses, "fdfe:dcba:9876::1/126")
	}
	in := obj{
		"type":           "tun",
		"tag":            "tun-in",
		"interface_name": name,
		"address":        addresses,
		"mtu":            mtu,
		"auto_route":     true,
		"strict_route":   true,
		"dns_mode":       tunDNSMode(s),
	}
	// sing-tun's own stack is chosen by leaving the field out; the other three
	// are deprecated since sing-box 1.15 and go away in 1.17, so a config never
	// carries a name the core did not have.
	if s.TUNStack != config.TUNStackSingTun {
		in["stack"] = s.TUNStack
	}
	// multi_queue scales the link with the core count and only exists on
	// sing-tun's own stack: sending it with the others fails in the core.
	if s.TUNStack == config.TUNStackSingTun && s.MultiQueue {
		in["multi_queue"] = true
	}
	// auto_redirect adds nftables rules that steer traffic the TUN would otherwise
	// never see — the queries of a stub resolver on 127.0.0.53 are the case that
	// matters — into the tunnel. Without it those queries leave the machine
	// directly and the ISP answers them.
	if s.AutoRedirect {
		in["auto_redirect"] = true
	}
	return in
}

// tunDNSMode decides whether the TUN device intercepts port 53.
func tunDNSMode(s config.Settings) string {
	if s.DNS.Mode == "disabled" {
		return "native"
	}
	return "hijack"
}

// routeSection builds the routing table. bootstrap is the server's own name when
// the endpoint is a domain: it cannot be resolved through the tunnel, because the
// tunnel does not exist yet.
func routeSection(s config.Settings, bootstrap string) obj {
	route := obj{
		"auto_detect_interface": true,
		"final":                 "proxy",
	}
	// A destination that is a name has to be resolved by the resolver the user
	// chose. Without this the core falls back to the system resolver, which the
	// TUN intercepts, and a bypassed site resolves to a fake address and never
	// connects; sing-box 1.15 also refuses outright to dial a server addressed by
	// name ("missing domain resolver for domain server address").
	if s.DNS.Mode != "disabled" {
		// The server's own name is the one lookup that cannot travel through the
		// tunnel, so it is resolved by the system. Everything else is resolved by
		// the tunnelled resolvers, which is what keeps the ISP out of the picture.
		if bootstrap != "" {
			route["default_domain_resolver"] = "local"
		} else {
			route["default_domain_resolver"] = remoteTag(s.DNS.Servers)
		}
	}
	// The direct list comes before the final outbound: everything it matches
	// goes around the tunnel, everything else does not.
	if rules := bypassRules(s); len(rules) > 0 {
		route["rules"] = rules
	}
	return route
}

// bypassRules turns the direct list into route rules — one rule per kind, so a
// user who only listed processes does not pay for an empty domain lookup.
func bypassRules(s config.Settings) []any {
	rules := make([]any, 0, 4)
	suffixes, keywords := SplitDomains(s.Bypass.Domains)
	if len(suffixes) > 0 || len(keywords) > 0 {
		// A site rule only matches a name, and in direct DNS mode the connection
		// arrives as an address: sniffing the first bytes is what turns it back
		// into one. FakeIP does not need it, but it costs nothing there.
		rules = append(rules, obj{"action": "sniff"})
	}
	if len(s.Bypass.IPs) > 0 {
		rules = append(rules, obj{
			"ip_cidr":  s.Bypass.IPs,
			"action":   "route",
			"outbound": "direct",
		})
	}
	if len(suffixes) > 0 || len(keywords) > 0 {
		rule := obj{"action": "route", "outbound": "direct"}
		if len(suffixes) > 0 {
			rule["domain_suffix"] = suffixes
		}
		if len(keywords) > 0 {
			rule["domain_keyword"] = keywords
		}
		rules = append(rules, rule)
	}
	if regexes := ProcessRegexes(s.Bypass.Processes); len(regexes) > 0 {
		rules = append(rules, obj{
			"process_path_regex": regexes,
			"action":             "route",
			"outbound":           "direct",
		})
	}
	return rules
}

// SplitDomains reads the domain list. A plain name and a dot-prefixed one are
// the same thing here — a suffix, so example.com covers the name and every
// subdomain — while "*steam*" is a keyword that matches anywhere in the name.
func SplitDomains(in []string) (suffixes, keywords []string) {
	for _, entry := range in {
		entry = strings.TrimSpace(entry)
		if entry == "" {
			continue
		}
		if strings.HasPrefix(entry, "*") || strings.HasSuffix(entry, "*") {
			keyword := strings.Trim(entry, "*")
			if keyword != "" {
				keywords = append(keywords, keyword)
			}
			continue
		}
		suffixes = append(suffixes, strings.TrimPrefix(entry, "."))
	}
	return suffixes, keywords
}

// ProcessRegexes turns process names into case-insensitive substring patterns.
// The core matches them against the executable path, which is why "steam" also
// covers steamwebhelper and steamwebhelper's friends.
func ProcessRegexes(in []string) []string {
	out := make([]string, 0, len(in))
	for _, name := range in {
		name = strings.TrimSpace(name)
		if name == "" {
			continue
		}
		out = append(out, "(?i)"+regexp.QuoteMeta(name))
	}
	return out
}

// dnsSection builds the resolver. FakeIP is a server plus one rule; nothing
// outside the core is touched.
//
// bootstrap is the server's own name when the endpoint is a domain. That one name
// is answered by the local resolver — it has to be, the tunnel cannot carry the
// lookup that creates it — and every other query goes through the proxy.
func dnsSection(s config.Settings, bootstrap string) obj {
	switch s.DNS.Mode {
	case "disabled":
		return nil
	case "fakeip":
		fakeip := obj{
			"type":        "fakeip",
			"tag":         "fakeip",
			"inet4_range": "198.18.0.0/15",
		}
		queryTypes := []string{"A"}
		if s.DNS.UseIPv6 {
			fakeip["inet6_range"] = "fc00::/18"
			queryTypes = append(queryTypes, "AAAA")
		}
		servers := []any{fakeip}
		for i := range s.DNS.Servers {
			servers = append(servers, remoteServer(s.DNS.Servers, i))
		}
		servers = append(servers, obj{"type": "local", "tag": "local"})
		rules := []any{
			obj{
				"domain_suffix": []string{".lan", ".local", ".home.arpa", ".internal"},
				"server":        "local",
			},
		}
		if bootstrap != "" {
			rules = append(rules, obj{"domain": []string{bootstrap}, "server": "local"})
		}
		if !s.DNS.UseIPv6 {
			// No IPv6 on the link, so hand out no AAAA at all: an empty answer is
			// the shortest path to IPv4 instead of a connection that cannot work.
			rules = append(rules, obj{
				"query_type": []string{"AAAA"},
				"action":     "predefined",
				"rcode":      "NOERROR",
			})
		}
		rules = append(rules, obj{
			"query_type": queryTypes,
			"server":     "fakeip",
		})
		return obj{
			"servers":         servers,
			"rules":           rules,
			"final":           remoteTag(s.DNS.Servers),
			"reverse_mapping": true,
		}
	default: // direct
		servers := make([]any, 0, len(s.DNS.Servers)+1)
		for i := range s.DNS.Servers {
			servers = append(servers, remoteServer(s.DNS.Servers, i))
		}
		servers = append(servers, obj{"type": "local", "tag": "local"})
		out := obj{
			"servers": servers,
			"final":   remoteTag(s.DNS.Servers),
		}
		rules := make([]any, 0, 3)
		if bootstrap != "" {
			rules = append(rules, obj{"domain": []string{bootstrap}, "server": "local"})
		}
		if !s.DNS.UseIPv6 {
			rules = append(rules, obj{
				"query_type": []string{"AAAA"},
				"action":     "predefined",
				"rcode":      "NOERROR",
			})
		}
		if len(rules) > 0 {
			out["rules"] = rules
		}
		return out
	}
}

// remoteServer renders one configured resolver. An empty slot becomes a
// duplicate of the first one, which the core accepts and never queries twice.
//
// The query always travels through the tunnel. DNS that leaves the machine
// directly is a leak and a dependency at once: on a network that blocks port 53
// nothing resolves, and every resolver sees the real address. It used to be sent
// directly whenever the server was addressed by a name, so a provider that hands
// out domain endpoints had every lookup answered by the ISP.
func remoteServer(servers []string, index int) obj {
	addr := ""
	if index < len(servers) {
		addr = servers[index]
	} else if len(servers) > 0 {
		addr = servers[0]
	}
	if addr == "" {
		addr = "1.1.1.1"
	}
	host, port := splitServer(addr)
	server := obj{"type": "udp", "tag": tagFor(index), "server": host, "detour": "proxy"}
	if port != 0 {
		server["server_port"] = port
	}
	return server
}

func remoteTag(servers []string) string {
	if len(servers) == 0 {
		return "local"
	}
	return tagFor(0)
}

func tagFor(index int) string {
	return fmt.Sprintf("dns%d", index)
}

// splitServer handles "1.1.1.1", "1.1.1.1:5353" and "[2606:4700::1111]:53".
func splitServer(addr string) (string, int) {
	host, portText, err := net.SplitHostPort(addr)
	if err == nil {
		port, perr := strconv.Atoi(portText)
		if perr == nil && port > 0 && port <= 65535 {
			return host, port
		}
		return host, 0
	}
	if strings.HasPrefix(addr, "[") && strings.HasSuffix(addr, "]") {
		return strings.TrimSuffix(strings.TrimPrefix(addr, "["), "]"), 0
	}
	return addr, 0
}
