package coreconf

import (
	"encoding/json"
	"strings"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
)

func testNode() config.Node {
	return config.Node{
		Name:    "de1",
		Kind:    "vless",
		Address: "de1.example.net",
		Port:    443,
		Outbound: json.RawMessage(`{"type":"vless","server":"de1.example.net","server_port":443,` +
			`"uuid":"11111111-2222-3333-4444-555555555555"}`),
	}
}

// dnsRuleFor finds the DNS rule that sends queries to a given server. The rule
// list has a bootstrap entry in front whenever the server is addressed by a name,
// so counting positions is not a stable way to find anything.
func dnsRuleFor(t *testing.T, dns map[string]any, server string) map[string]any {
	t.Helper()
	rules, _ := dns["rules"].([]any)
	for _, raw := range rules {
		rule, _ := raw.(map[string]any)
		if rule["server"] == server {
			return rule
		}
	}
	t.Fatalf("no rule points at %s: %v", server, rules)
	return nil
}

// dnsRuleWithAction finds the first rule carrying an action such as predefined.
func dnsRuleWithAction(t *testing.T, dns map[string]any, action string) map[string]any {
	t.Helper()
	rules, _ := dns["rules"].([]any)
	for _, raw := range rules {
		rule, _ := raw.(map[string]any)
		if rule["action"] == action {
			return rule
		}
	}
	t.Fatalf("no rule with action %s: %v", action, rules)
	return nil
}

func buildDoc(t *testing.T, s config.Settings, mtu int) map[string]any {
	t.Helper()
	return buildDocFull(t, s, testNode(), mtu, false)
}

// buildDocFull builds with a chosen node and the kernel's brutal answer, which is
// what the host passes in.
func buildDocFull(t *testing.T, s config.Settings, node config.Node, mtu int, brutalOK bool) map[string]any {
	t.Helper()
	raw, err := Build(Input{
		Settings: s, Node: node, TUNName: "bw0", MTU: mtu, StateDir: "/tmp/bw",
		BrutalSupported: brutalOK,
	})
	if err != nil {
		t.Fatalf("build: %v", err)
	}
	var doc map[string]any
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatalf("config is not JSON: %v", err)
	}
	return doc
}

func at(t *testing.T, v any, i int) map[string]any {
	t.Helper()
	list, ok := v.([]any)
	if !ok || i >= len(list) {
		t.Fatalf("not a list with index %d: %v", i, v)
	}
	m, ok := list[i].(map[string]any)
	if !ok {
		t.Fatalf("element %d is not an object: %v", i, list[i])
	}
	return m
}

func TestBuildFakeIPGvisorBrutal(t *testing.T) {
	s := config.Defaults()
	s.TUNStack = "gvisor"
	s.MTU = 1380
	s.Smux = config.SmuxSettings{Enabled: true, Protocol: "smux", Padding: true}
	s.Brutal = config.BrutalSettings{Enabled: true, UpMbps: 50, DownMbps: 200}

	doc := buildDocFull(t, s, testNode(), 0, true)

	inbound := at(t, doc["inbounds"], 0)
	if inbound["stack"] != "gvisor" || inbound["mtu"] != float64(1380) || inbound["dns_mode"] != "hijack" {
		t.Fatalf("tun inbound: %v", inbound)
	}
	if inbound["interface_name"] != "bw0" || inbound["strict_route"] != true || inbound["auto_route"] != true {
		t.Fatalf("tun inbound routing: %v", inbound)
	}

	dns, ok := doc["dns"].(map[string]any)
	if !ok {
		t.Fatal("dns section missing in fakeip mode")
	}
	if at(t, dns["servers"], 0)["type"] != "fakeip" {
		t.Fatalf("fakeip server missing: %v", dns["servers"])
	}
	if at(t, dns["servers"], 1)["type"] != "udp" {
		t.Fatalf("remote server missing: %v", dns["servers"])
	}
	if dns["final"] != "dns0" || dns["reverse_mapping"] != true {
		t.Fatalf("dns final/reverse: %v", dns)
	}
	rule := dnsRuleFor(t, dns, "fakeip")
	if types, _ := rule["query_type"].([]any); len(types) != 2 {
		t.Fatalf("query_type: %v", rule["query_type"])
	}

	proxy := at(t, doc["outbounds"], 0)
	if proxy["tag"] != "proxy" || proxy["type"] != "vless" {
		t.Fatalf("proxy outbound: %v", proxy)
	}
	mux, ok := proxy["multiplex"].(map[string]any)
	if !ok || mux["enabled"] != true || mux["protocol"] != "smux" || mux["padding"] != true {
		t.Fatalf("multiplex: %v", proxy["multiplex"])
	}
	brutal, ok := mux["brutal"].(map[string]any)
	if !ok || brutal["up_mbps"] != float64(50) || brutal["down_mbps"] != float64(200) {
		t.Fatalf("brutal: %v", mux["brutal"])
	}

	route, ok := doc["route"].(map[string]any)
	if !ok || route["final"] != "proxy" || route["auto_detect_interface"] != true {
		t.Fatalf("route: %v", doc["route"])
	}
	exp, ok := doc["experimental"].(map[string]any)
	if !ok {
		t.Fatal("cache file section missing")
	}
	cache, _ := exp["cache_file"].(map[string]any)
	if cache["path"] != "/tmp/bw/cache.db" || cache["store_fakeip"] != true {
		t.Fatalf("cache file: %v", cache)
	}
}

func TestBuildIPv6Disabled(t *testing.T) {
	s := config.Defaults()
	s.DNS.UseIPv6 = false
	doc := buildDoc(t, s, 0)

	addresses, _ := at(t, doc["inbounds"], 0)["address"].([]any)
	if len(addresses) != 1 || addresses[0] != "172.19.0.1/30" {
		t.Fatalf("tun addresses with IPv6 off: %v", addresses)
	}

	dns, ok := doc["dns"].(map[string]any)
	if !ok {
		t.Fatal("dns section missing")
	}
	fakeip := at(t, dns["servers"], 0)
	if _, has := fakeip["inet6_range"]; has {
		t.Fatalf("fakeip must not carry an IPv6 range: %v", fakeip)
	}
	types, _ := dnsRuleFor(t, dns, "fakeip")["query_type"].([]any)
	if len(types) != 1 || types[0] != "A" {
		t.Fatalf("query types with IPv6 off: %v", types)
	}
	if rule := dnsRuleWithAction(t, dns, "predefined"); rule["rcode"] != "NOERROR" {
		t.Fatalf("AAAA must be answered with an empty reply, got %v", rule)
	}
	servers, _ := dns["servers"].([]any)
	udp := 0
	for i, srv := range servers {
		m, ok := srv.(map[string]any)
		if !ok || m["type"] != "udp" {
			continue
		}
		udp++
		if addr, _ := m["server"].(string); strings.Contains(addr, ":") {
			t.Fatalf("leased an IPv6 resolver while IPv6 is off: %d %v", i, m)
		}
	}
	if udp != 2 {
		t.Fatalf("udp resolvers with IPv6 off: %d", udp)
	}
}

func TestBuildIPv6Enabled(t *testing.T) {
	s := config.Defaults()
	doc := buildDoc(t, s, 0)

	addresses, _ := at(t, doc["inbounds"], 0)["address"].([]any)
	if len(addresses) != 2 || addresses[1] != "fdfe:dcba:9876::1/126" {
		t.Fatalf("tun addresses with IPv6 on: %v", addresses)
	}
	dns, _ := doc["dns"].(map[string]any)
	if _, has := at(t, dns["servers"], 0)["inet6_range"]; !has {
		t.Fatalf("fakeip needs an IPv6 range: %v", at(t, dns["servers"], 0))
	}
	types, _ := dnsRuleFor(t, dns, "fakeip")["query_type"].([]any)
	if len(types) != 2 || types[0] != "A" || types[1] != "AAAA" {
		t.Fatalf("query types with IPv6 on: %v", types)
	}

	// All four addresses of the default preset reach the core, two of them IPv6.
	udp, v6 := 0, 0
	for _, srv := range dns["servers"].([]any) {
		m, _ := srv.(map[string]any)
		if m["type"] != "udp" {
			continue
		}
		udp++
		if addr, _ := m["server"].(string); strings.Contains(addr, ":") {
			v6++
		}
	}
	if udp != 4 || v6 != 2 {
		t.Fatalf("udp=%d v6=%d, want 4 and 2", udp, v6)
	}
}

func TestBuildLogSectionHasNoTimestampAndNoColors(t *testing.T) {
	doc := buildDoc(t, config.Defaults(), 0)
	logSection, ok := doc["log"].(map[string]any)
	if !ok {
		t.Fatal("log section missing")
	}
	if _, has := logSection["timestamp"]; has {
		t.Fatalf("the core must not stamp its own clock: %v", logSection)
	}
	if logSection["level"] != "info" {
		t.Fatalf("level = %v", logSection["level"])
	}
}

func TestBuildDNSDisabled(t *testing.T) {
	s := config.Defaults()
	s.DNS.Mode = "disabled"
	doc := buildDoc(t, s, 0)
	if _, ok := doc["dns"]; ok {
		t.Fatalf("dns section must be absent when disabled: %v", doc["dns"])
	}
	if at(t, doc["inbounds"], 0)["dns_mode"] != "native" {
		t.Fatal("disabled DNS must not hijack port 53")
	}
}
