// Package coreconf builds the sing-box configuration from the Barewire lever
// set. It produces JSON: the same document the core is started from, readable by
// a human and diffable in tests, with no option structs leaking in here.
package coreconf

import (
	"encoding/json"
	"errors"
	"fmt"
	"path/filepath"

	"github.com/mrazowner/barewire/internal/config"
)

// ErrNoNode is returned when there is nothing to connect through.
var ErrNoNode = errors.New("coreconf: no node with a complete outbound")

// DefaultMTU is what the core uses when neither the host nor the settings
// resolved a value. It is the same number the config package defaults to, so the
// two can never disagree about what "auto" means.
const DefaultMTU = config.DefaultTunnelMTU

// Input is everything the builder needs.
type Input struct {
	Settings config.Settings
	Node     config.Node
	// TUNName is the interface name, for example barewire0.
	TUNName string
	// MTU is the resolved MTU; 0 means DefaultMTU. The host resolves "auto"
	// with a probe and passes the measured value here.
	MTU int
	// StateDir holds the cache file (fakeip store lives there).
	StateDir string
	// ClashAddress is the loopback address of the statistics API
	// (127.0.0.1:port); empty disables it.
	ClashAddress string
	// ClashSecret protects the statistics API.
	ClashSecret string
	// BrutalSupported says the machine can actually run TCP Brutal: the kernel
	// offers the "brutal" congestion control, which only the out-of-tree
	// tcp_brutal module provides. The host checks it before building; a config
	// built without the check never asks for a rate the kernel cannot keep.
	BrutalSupported bool
}

// Build renders the complete configuration.
func Build(in Input) ([]byte, error) {
	if !in.Node.Connectable() {
		return nil, ErrNoNode
	}
	settings := in.Settings
	settings.Normalize()

	proxy, err := proxyOutbound(in.Node)
	if err != nil {
		return nil, err
	}
	applyMultiplex(proxy, settings, in.BrutalSupported)
	applyQuicCongestion(proxy, settings)

	// A server addressed by a name cannot have that name resolved through the
	// tunnel it creates: the lookup has to happen first. It is the single query
	// that travels directly, and the config says so in one place.
	bootstrap := ""
	if !in.Node.LiteralAddress() {
		bootstrap = in.Node.Address
	}

	doc := obj{
		"log": obj{
			"level": "info",
			// The interface stamps every line with its own clock; the core must
			// not add one, and it must not colourise: these lines are rendered
			// inside a TUI, not on a raw terminal.
			"output": "stderr",
		},
		"inbounds": []any{tunInbound(settings, in.TUNName, resolveMTU(settings, in.MTU))},
		"outbounds": []any{
			proxy,
			obj{"type": "direct", "tag": "direct"},
		},
		"route": routeSection(settings, bootstrap),
	}
	if dns := dnsSection(settings, bootstrap); dns != nil {
		doc["dns"] = dns
	}
	if exp := experimentalSection(in); exp != nil {
		doc["experimental"] = exp
	}

	raw, err := json.MarshalIndent(doc, "", "  ")
	if err != nil {
		return nil, fmt.Errorf("coreconf: encode config: %w", err)
	}
	return append(raw, '\n'), nil
}

// resolveMTU picks the number the TUN receives. The host resolves the lever —
// it measures the path, subtracts the tunnel's overhead and lowers a value the
// path cannot carry — so its answer wins when present. settings.MTU is the
// fallback for callers that do not resolve anything, such as a preview.
func resolveMTU(settings config.Settings, resolved int) int {
	if resolved > 0 {
		return resolved
	}
	if settings.MTU > 0 {
		return settings.MTU
	}
	return DefaultMTU
}

// proxyOutbound takes the node's outbound object and gives it the tag the route
// points at.
func proxyOutbound(node config.Node) (obj, error) {
	var out obj
	if err := json.Unmarshal(node.Outbound, &out); err != nil {
		return nil, fmt.Errorf("coreconf: node %q outbound: %w", node.Name, err)
	}
	if out["type"] == nil || out["server"] == nil {
		return nil, fmt.Errorf("coreconf: node %q outbound is incomplete", node.Name)
	}
	out["tag"] = "proxy"
	return out, nil
}

// applyMultiplex attaches smux and TCP Brutal. Brutal lives inside multiplexing,
// so enabling it turns multiplexing on as well.
//
// Two things decide whether anything is written. The outbound type must have a
// multiplex section at all: TUIC, Hysteria2, WireGuard and the rest reject the
// field, which makes the whole config invalid rather than ignored. And Brutal
// needs the kernel to provide the "brutal" congestion control, which only the
// tcp_brutal module does — otherwise the rate is a promise the kernel cannot
// keep and every connection dies in setsockopt.
func applyMultiplex(out obj, s config.Settings, brutalOK bool) {
	kind, _ := out["type"].(string)
	if !config.SupportsMultiplex(kind) {
		return
	}
	// A link with a flow cannot be multiplexed: xtls-rprx-vision wraps the stream
	// itself, and the server refuses mux on top of it. Writing the section anyway
	// is how "mux does not work at all" happened — the tunnel came up on a config
	// the server would never accept.
	if flow, ok := out["flow"].(string); ok && flow != "" {
		return
	}
	brutal := s.Brutal.Enabled && brutalOK
	if !s.Smux.Enabled && !brutal {
		return
	}
	mux := obj{"enabled": true}
	if s.Smux.Enabled {
		mux["protocol"] = s.Smux.Protocol
		mux["padding"] = s.Smux.Padding
	} else {
		mux["protocol"] = "smux"
	}
	if brutal {
		mux["brutal"] = obj{
			"enabled":   true,
			"up_mbps":   s.Brutal.UpMbps,
			"down_mbps": s.Brutal.DownMbps,
		}
	}
	out["multiplex"] = mux
}

// applyQuicCongestion overrides the congestion control inside the QUIC
// transport of a TUIC node. There is no kernel TCP in that path, so this is the
// only lever that reaches it. Only TUIC exposes the field; every other protocol
// keeps whatever its link asked for.
func applyQuicCongestion(out obj, s config.Settings) {
	if s.Kernel.QuicCongestion == "" || out["type"] != "tuic" {
		return
	}
	out["congestion_control"] = s.Kernel.QuicCongestion
}

func experimentalSection(in Input) obj {
	exp := obj{}
	if in.StateDir != "" {
		exp["cache_file"] = obj{
			"enabled":      true,
			"path":         filepath.Join(in.StateDir, "cache.db"),
			"store_fakeip": true,
		}
	}
	if in.ClashAddress != "" {
		api := obj{"external_controller": in.ClashAddress}
		if in.ClashSecret != "" {
			api["secret"] = in.ClashSecret
		}
		exp["clash_api"] = api
	}
	if len(exp) == 0 {
		return nil
	}
	return exp
}
