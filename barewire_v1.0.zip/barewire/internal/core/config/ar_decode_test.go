package coreconf

import (
	"context"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/core"
)

func TestAutoRedirectDecodesWithTheRealCore(t *testing.T) {
	s := config.Defaults()
	s.AutoRedirect = true
	s.DNS.Mode = "direct"
	raw, err := Build(Input{Settings: s, Node: testNode(), TUNName: "bw0", MTU: 1420, StateDir: t.TempDir(), ClashAddress: "127.0.0.1:9090"})
	if err != nil {
		t.Fatalf("build: %v", err)
	}
	if _, err := core.Decode(context.Background(), raw); err != nil {
		t.Fatalf("decode: %v\n%s", err, raw)
	}
}
