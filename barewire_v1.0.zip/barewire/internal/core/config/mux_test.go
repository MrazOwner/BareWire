package coreconf

import (
	"encoding/json"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
)

// node builds a node of any protocol for the transport tests.
func nodeOf(kind, addr string, port int, raw string) config.Node {
	return config.Node{
		Name: kind, Kind: kind, Address: addr, Port: port,
		Outbound: json.RawMessage(raw),
	}
}

// The multiplex section only exists on four outbound types. Writing it anywhere
// else is not "ignored": sing-box rejects the whole document with "unknown
// field", the core never starts, and the lever looks broken.
func TestMultiplexOnlyWhereTheProtocolHasIt(t *testing.T) {
	s := config.Defaults()
	s.Smux = config.SmuxSettings{Enabled: true, Protocol: "smux", Padding: true}

	cases := map[string]config.Node{
		"vless":       testNode(),
		"vmess":       nodeOf("vmess", "n.example.net", 443, `{"type":"vmess","server":"n.example.net","server_port":443,"uuid":"11111111-2222-3333-4444-555555555555"}`),
		"trojan":      nodeOf("trojan", "n.example.net", 443, `{"type":"trojan","server":"n.example.net","server_port":443,"password":"pw"}`),
		"shadowsocks": nodeOf("shadowsocks", "n.example.net", 8388, `{"type":"shadowsocks","server":"n.example.net","server_port":8388,"method":"aes-128-gcm","password":"pw"}`),
		"tuic":        nodeOf("tuic", "n.example.net", 443, `{"type":"tuic","server":"n.example.net","server_port":443,"uuid":"11111111-2222-3333-4444-555555555555","password":"pw"}`),
		"hysteria2":   nodeOf("hysteria2", "n.example.net", 443, `{"type":"hysteria2","server":"n.example.net","server_port":443,"password":"pw"}`),
	}
	for kind, node := range cases {
		out := at(t, buildDocFull(t, s, node, 0, false)["outbounds"], 0)
		_, has := out["multiplex"]
		want := config.SupportsMultiplex(kind)
		if has != want {
			t.Fatalf("%s: multiplex present = %v, want %v (%v)", kind, has, want, out)
		}
	}
}

// Brutal is written only when the kernel can keep the rate. Without the answer
// the builder never guesses: an honest config with no brutal beats a link that
// dies in setsockopt.
func TestBrutalNeedsTheKernel(t *testing.T) {
	s := config.Defaults()
	s.Smux.Enabled = false
	s.Brutal = config.BrutalSettings{Enabled: true, UpMbps: 50, DownMbps: 200}

	without := at(t, buildDocFull(t, s, testNode(), 0, false)["outbounds"], 0)
	if _, ok := without["multiplex"]; ok {
		t.Fatalf("brutal without kernel support must not be written: %v", without)
	}

	with := at(t, buildDocFull(t, s, testNode(), 0, true)["outbounds"], 0)
	mux, ok := with["multiplex"].(map[string]any)
	if !ok {
		t.Fatalf("brutal with kernel support must turn multiplexing on: %v", with)
	}
	if brutal, _ := mux["brutal"].(map[string]any); brutal["enabled"] != true {
		t.Fatalf("brutal block: %v", mux["brutal"])
	}

	// Multiplexing alone is unaffected by the kernel answer.
	s2 := config.Defaults()
	s2.Smux = config.SmuxSettings{Enabled: true, Protocol: "h2mux", Padding: false}
	if out := at(t, buildDocFull(t, s2, testNode(), 0, false)["outbounds"], 0); out["multiplex"] == nil {
		t.Fatal("multiplexing must not depend on the brutal module")
	}
}
