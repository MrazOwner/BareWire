package coreconf

import (
	"encoding/json"
	"strings"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
)

// A destination that is a name has to be resolved by a resolver the core knows.
// Without this the core falls back to the system resolver, which the TUN
// intercepts, and sing-box 1.15 refuses to dial a server addressed by name at all
// ("missing domain resolver for domain server address").
//
// Which resolver that is depends on the endpoint: an IP-addressed server can have
// everything, including its own names, resolved through the tunnel. A server
// addressed by a name has to be resolved before the tunnel exists, so the default
// resolver is the local one and a single bootstrap rule in the DNS section covers
// that name.
func TestRouteNamesTheDomainResolver(t *testing.T) {
	ipNode := nodeOf("vless", "203.0.113.7", 443,
		`{"type":"vless","server":"203.0.113.7","server_port":443,"uuid":"11111111-2222-3333-4444-555555555555"}`)
	for _, mode := range []string{"fakeip", "direct"} {
		s := config.Defaults()
		s.DNS.Mode = mode
		route := buildDocFull(t, s, ipNode, 0, false)["route"].(map[string]any)
		if route["default_domain_resolver"] != "dns0" {
			t.Fatalf("%s: an IP server resolves through the tunnel, got %v", mode, route["default_domain_resolver"])
		}
		s = config.Defaults()
		s.DNS.Mode = mode
		route = buildDocFull(t, s, testNode(), 0, false)["route"].(map[string]any)
		if route["default_domain_resolver"] != "local" {
			t.Fatalf("%s: a name server resolves locally, got %v", mode, route["default_domain_resolver"])
		}
	}
	s := config.Defaults()
	s.DNS.Mode = "disabled"
	route := buildDoc(t, s, 0)["route"].(map[string]any)
	if _, has := route["default_domain_resolver"]; has {
		t.Fatalf("without DNS there is no resolver to name: %v", route)
	}
}

// Resolver queries always travel inside the tunnel, and the server's own name is
// the single exception: it is answered by the local resolver through a bootstrap
// rule, because the tunnel cannot carry the lookup that creates it. DNS that
// leaves the machine directly is both a leak and a dependency — on a network that
// blocks port 53 nothing resolves at all.
func TestDNSDetourFollowsTheServerAddress(t *testing.T) {
	ipNode := testNode()
	ipNode.Address = "203.0.113.7"
	ipNode.Outbound = json.RawMessage(`{"type":"vless","server":"203.0.113.7","server_port":443,` +
		`"uuid":"11111111-2222-3333-4444-555555555555"}`)

	dns := buildDocFull(t, config.Defaults(), ipNode, 0, false)["dns"].(map[string]any)
	if at(t, dns["servers"], 1)["detour"] != "proxy" {
		t.Fatalf("an IP-addressed server lets DNS travel inside the tunnel: %v", at(t, dns["servers"], 1))
	}

	// A name-addressed server keeps the same tunnel for every ordinary query, and
	// gains one rule that resolves its own name locally.
	named := buildDoc(t, config.Defaults(), 0)["dns"].(map[string]any)
	if at(t, named["servers"], 1)["detour"] != "proxy" {
		t.Fatalf("a name-addressed server still sends its queries through the tunnel: %v", at(t, named["servers"], 1))
	}
	bootstrap := false
	rules, _ := named["rules"].([]any)
	for _, raw := range rules {
		rule, _ := raw.(map[string]any)
		if rule["server"] != "local" {
			continue
		}
		if domains, ok := rule["domain"].([]any); ok {
			for _, d := range domains {
				if d == testNode().Address {
					bootstrap = true
				}
			}
		}
	}
	if !bootstrap {
		t.Fatalf("the server's own name needs a local rule: %v", rules)
	}
	// The local resolver is never sent anywhere: it is the system's, and a detour
	// on it would be a loop.
	servers, _ := named["servers"].([]any)
	for _, srv := range servers {
		m, ok := srv.(map[string]any)
		if ok && m["type"] == "local" && m["detour"] != nil {
			t.Fatalf("the local resolver must stay local: %v", m)
		}
	}
}

// Both switches have to survive the real decoder: a field the core does not know
// makes the whole document invalid, and the tunnel never starts.
func TestNewRouteFieldsDecode(t *testing.T) {
	raw, err := Build(Input{Settings: config.Defaults(), Node: testNode(), TUNName: "bw0", MTU: 1420})
	if err != nil {
		t.Fatalf("build: %v", err)
	}
	if !strings.Contains(string(raw), `"default_domain_resolver"`) {
		t.Fatalf("the resolver is not in the document:\n%s", raw)
	}
}
