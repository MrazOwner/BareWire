package coreconf

import (
	"encoding/json"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
)

func tuicNode() config.Node {
	return config.Node{
		Name: "tu1", Kind: "tuic", Address: "tu1.example.net", Port: 8443,
		Outbound: json.RawMessage(`{"type":"tuic","server":"tu1.example.net","server_port":8443,` +
			`"uuid":"11111111-2222-3333-4444-555555555555","password":"pw","congestion_control":"cubic"}`),
	}
}

// There is no kernel TCP inside QUIC, so the TUIC outbound is the only place the
// QUIC transport can be reached from a lever.
func TestBuildQuicCongestionOverridesTuic(t *testing.T) {
	s := config.Defaults()
	s.Kernel.QuicCongestion = "bbr"
	raw, err := Build(Input{Settings: s, Node: tuicNode(), TUNName: "bw0", MTU: 1400})
	if err != nil {
		t.Fatalf("build: %v", err)
	}
	var doc map[string]any
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatal(err)
	}
	out := at(t, doc["outbounds"], 0)
	if out["congestion_control"] != "bbr" {
		t.Fatalf("tuic congestion_control = %v", out["congestion_control"])
	}
	if out["tag"] != "proxy" {
		t.Fatalf("tag = %v", out["tag"])
	}
}

// Every other protocol keeps whatever its link asked for.
func TestBuildQuicCongestionLeavesOtherProtocolsAlone(t *testing.T) {
	s := config.Defaults()
	s.Kernel.QuicCongestion = "bbr"
	doc := buildDoc(t, s, 0)
	if out := at(t, doc["outbounds"], 0); out["congestion_control"] != nil {
		t.Fatalf("vless outbound was touched: %v", out)
	}
}

// Keeping is the default: no key is added when the lever is not used.
func TestBuildQuicCongestionKeepsTheLinkValue(t *testing.T) {
	raw, err := Build(Input{Settings: config.Defaults(), Node: tuicNode(), TUNName: "bw0", MTU: 1400})
	if err != nil {
		t.Fatalf("build: %v", err)
	}
	var doc map[string]any
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatal(err)
	}
	if out := at(t, doc["outbounds"], 0); out["congestion_control"] != "cubic" {
		t.Fatalf("the link's own value was lost: %v", out["congestion_control"])
	}
}
