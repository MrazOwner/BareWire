package core

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/mrazowner/barewire/internal/config"
	coreconf "github.com/mrazowner/barewire/internal/core/config"
)

// Every protocol must decode with every transport lever on. This is the test
// that was missing when multiplexing was written into outbounds that have no
// multiplex section: the document was rejected whole, so the core never started
// and the lever looked like "nothing loads".
func TestGeneratedConfigTransportPerProtocol(t *testing.T) {
	nodes := map[string]config.Node{
		"vless": {Name: "n", Kind: "vless", Address: "n.example.net", Port: 443,
			Outbound: json.RawMessage(`{"type":"vless","server":"n.example.net","server_port":443,` +
				`"uuid":"11111111-2222-3333-4444-555555555555"}`)},
		"vmess": {Name: "n", Kind: "vmess", Address: "n.example.net", Port: 443,
			Outbound: json.RawMessage(`{"type":"vmess","server":"n.example.net","server_port":443,` +
				`"uuid":"11111111-2222-3333-4444-555555555555"}`)},
		"trojan": {Name: "n", Kind: "trojan", Address: "n.example.net", Port: 443,
			Outbound: json.RawMessage(`{"type":"trojan","server":"n.example.net","server_port":443,"password":"pw"}`)},
		"shadowsocks": {Name: "n", Kind: "shadowsocks", Address: "n.example.net", Port: 8388,
			Outbound: json.RawMessage(`{"type":"shadowsocks","server":"n.example.net","server_port":8388,` +
				`"method":"aes-128-gcm","password":"pw"}`)},
		"tuic": {Name: "n", Kind: "tuic", Address: "n.example.net", Port: 443,
			Outbound: json.RawMessage(`{"type":"tuic","server":"n.example.net","server_port":443,` +
				`"uuid":"11111111-2222-3333-4444-555555555555","password":"pw"}`)},
		"hysteria2": {Name: "n", Kind: "hysteria2", Address: "n.example.net", Port: 443,
			Outbound: json.RawMessage(`{"type":"hysteria2","server":"n.example.net","server_port":443,"password":"pw"}`)},
	}
	for kind, node := range nodes {
		for _, protocol := range config.SmuxProtocols {
			s := config.Defaults()
			s.Smux = config.SmuxSettings{Enabled: true, Protocol: protocol, Padding: true}
			s.Brutal = config.BrutalSettings{Enabled: true, UpMbps: 50, DownMbps: 200}
			s.Kernel.QuicCongestion = "bbr"
			for _, brutalOK := range []bool{false, true} {
				raw, err := coreconf.Build(coreconf.Input{
					Settings: s, Node: node, TUNName: "bw0", MTU: 1400,
					StateDir: t.TempDir(), BrutalSupported: brutalOK,
				})
				if err != nil {
					t.Fatalf("%s/%s: build: %v", kind, protocol, err)
				}
				if _, err := Decode(context.Background(), raw); err != nil {
					t.Fatalf("%s/%s (brutal %v): decode: %v\n%s", kind, protocol, brutalOK, err, raw)
				}
			}
		}
	}
}
