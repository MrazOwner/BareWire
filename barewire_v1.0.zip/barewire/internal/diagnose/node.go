// Package diagnose checks a single node from the machine without starting the
// tunnel or the core. It answers the question "is this endpoint alive at all".
package diagnose

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"net"
	"strconv"
	"time"
)

// NodeReport is what the checks found, step by step.
type NodeReport struct {
	Name       string
	Endpoint   string
	Addresses  []string
	ResolveErr error
	TCP        time.Duration
	TCPErr     error
	SNI        string
	TLSVersion string
	TLSErr     error
}

// nodeOutbound is the part of the outbound object these checks need.
type nodeOutbound struct {
	Server     string `json:"server"`
	ServerPort int    `json:"server_port"`
	TLS        *struct {
		Enabled    bool   `json:"enabled"`
		ServerName string `json:"server_name"`
	} `json:"tls"`
}

// Node measures resolve, TCP and TLS in that order, stopping at the first step
// that fails: the last successful step and the failing one are the answer.
func Node(ctx context.Context, name string, outbound json.RawMessage, timeout time.Duration) NodeReport {
	report := NodeReport{Name: name}
	var out nodeOutbound
	if err := json.Unmarshal(outbound, &out); err != nil || out.Server == "" || out.ServerPort == 0 {
		report.TCPErr = fmt.Errorf("node has no usable outbound")
		return report
	}
	report.Endpoint = net.JoinHostPort(out.Server, strconv.Itoa(out.ServerPort))

	if ip := net.ParseIP(out.Server); ip != nil {
		report.Addresses = []string{ip.String()}
	} else {
		lookupCtx, cancel := context.WithTimeout(ctx, timeout)
		defer cancel()
		addrs, err := net.DefaultResolver.LookupHost(lookupCtx, out.Server)
		if err != nil {
			report.ResolveErr = err
			return report
		}
		report.Addresses = addrs
	}

	dialer := net.Dialer{Timeout: timeout}
	start := time.Now()
	conn, err := dialer.DialContext(ctx, "tcp", report.Endpoint)
	report.TCP = time.Since(start)
	if err != nil {
		report.TCPErr = err
		return report
	}
	_ = conn.Close()

	if out.TLS == nil || !out.TLS.Enabled {
		return report
	}
	report.SNI = out.TLS.ServerName
	if report.SNI == "" {
		report.SNI = out.Server
	}
	// Verification is deliberately skipped: the point here is whether the
	// endpoint speaks TLS at all, not whether a certificate chains to a CA.
	tlsDialer := &tls.Dialer{
		NetDialer: &dialer,
		Config:    &tls.Config{ServerName: report.SNI, InsecureSkipVerify: true, MinVersion: tls.VersionTLS12},
	}
	tlsCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	tlsConn, err := tlsDialer.DialContext(tlsCtx, "tcp", report.Endpoint)
	if err != nil {
		report.TLSErr = err
		return report
	}
	defer func() { _ = tlsConn.Close() }()
	state := tlsConn.(*tls.Conn).ConnectionState()
	report.TLSVersion = tls.VersionName(state.Version)
	return report
}

// OK reports whether every performed step succeeded.
func (r NodeReport) OK() bool {
	return r.ResolveErr == nil && r.TCPErr == nil && r.TLSErr == nil
}
