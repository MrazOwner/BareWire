package diagnose

import (
	"context"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestNodeReportReachesTLSServer(t *testing.T) {
	srv := httptest.NewTLSServer(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {}))
	defer srv.Close()
	out := fmt.Sprintf(`{"server":%q,"server_port":%d,"tls":{"enabled":true,"server_name":"example.net"}}`,
		"127.0.0.1", srv.Listener.Addr().(*net.TCPAddr).Port)

	report := Node(context.Background(), "test", json.RawMessage(out), 2*time.Second)
	if report.TCPErr != nil {
		t.Fatalf("tcp: %v", report.TCPErr)
	}
	if report.TLSErr != nil {
		t.Fatalf("tls: %v", report.TLSErr)
	}
	if report.TLSVersion == "" {
		t.Fatal("tls version not reported")
	}
	if report.TCP <= 0 {
		t.Fatalf("tcp latency = %v", report.TCP)
	}
}

func TestNodeReportPlainTCPServerFailsTLS(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	defer func() { _ = ln.Close() }()
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				return
			}
			_, _ = conn.Write([]byte("HTTP/1.1 400 Bad Request\r\n\r\n"))
			_ = conn.Close()
		}
	}()
	port := ln.Addr().(*net.TCPAddr).Port
	out := fmt.Sprintf(`{"server":"127.0.0.1","server_port":%d,"tls":{"enabled":true,"server_name":"example.net"}}`, port)

	report := Node(context.Background(), "test", json.RawMessage(out), 2*time.Second)
	if report.TCPErr != nil {
		t.Fatalf("tcp: %v", report.TCPErr)
	}
	if report.TLSErr == nil {
		t.Fatal("a plain TCP server must fail the TLS step")
	}
	if report.OK() {
		t.Fatal("OK must be false when TLS failed")
	}
}

func TestNodeReportClosedPort(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	port := ln.Addr().(*net.TCPAddr).Port
	_ = ln.Close()
	out := fmt.Sprintf(`{"server":"127.0.0.1","server_port":%d}`, port)

	report := Node(context.Background(), "test", json.RawMessage(out), 2*time.Second)
	if report.TCPErr == nil {
		t.Fatal("closed port must fail the TCP step")
	}
}

func TestNodeReportBrokenOutbound(t *testing.T) {
	report := Node(context.Background(), "test", json.RawMessage(`{"type":"vless"}`), time.Second)
	if report.TCPErr == nil {
		t.Fatal("expected an error for an outbound without a server")
	}
}
