// Command tuipreview renders one Barewire screen to stdout without needing a
// terminal. It exists so that the layout can be inspected in a pipe, a diff or a
// bug report, and so that a screen can be checked without a TUN device.
package main

import (
	"flag"
	"fmt"
	"os"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/mock"
	"github.com/mrazowner/barewire/internal/tui"
)

func main() {
	tab := flag.Int("tab", 1, "tab to render, 1..5")
	width := flag.Int("w", 120, "terminal width in cells")
	height := flag.Int("h", 40, "terminal height in lines")
	state := flag.String("state", "connected", "link state to preview: connected|disconnected")
	wait := flag.Duration("wait", 2200*time.Millisecond, "how long to fold host events in before rendering")
	flag.Parse()

	dir, err := os.MkdirTemp("", "barewire-preview-")
	if err != nil {
		fmt.Fprintf(os.Stderr, "tuipreview: %v\n", err)
		os.Exit(1)
	}
	defer func() { _ = os.RemoveAll(dir) }()

	client := mock.New()
	defer func() { _ = client.Close() }()

	model := tui.New(tui.Options{
		Client:            client,
		Settings:          config.Defaults(),
		SettingsPath:      dir + "/settings.json",
		ProfilesPath:      dir + "/profiles.json",
		SubscriptionsPath: dir + "/subscriptions.json",
	})
	model.Update(tea.WindowSizeMsg{Width: *width, Height: *height})

	// The mock brings the link up asynchronously, exactly like the real host
	// will. The preview subscribes before asking for it, then folds the events
	// in for a moment so the screens show real data instead of empty columns.
	events := client.Events()
	if *state == "connected" {
		if err := client.Connect(); err != nil {
			fmt.Fprintf(os.Stderr, "tuipreview: %v\n", err)
			os.Exit(1)
		}
	}
	deadline := time.After(*wait)
	for running := true; running; {
		select {
		case ev := <-events:
			model.ApplyEvent(ev)
		case <-deadline:
			running = false
		}
	}

	if *tab > 1 {
		model.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{rune('0' + *tab)}})
	}
	fmt.Println(model.View())
}
