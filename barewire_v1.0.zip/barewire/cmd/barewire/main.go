package main

import (
	"context"
	"flag"
	"fmt"
	"os"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/hostclient"
	"github.com/mrazowner/barewire/internal/hostclient/offline"
	"github.com/mrazowner/barewire/internal/hostsock"
	"github.com/mrazowner/barewire/internal/hostspawn"
	"github.com/mrazowner/barewire/internal/mock"
	"github.com/mrazowner/barewire/internal/tui"
	"github.com/mrazowner/barewire/internal/version"
)

func main() {
	mockHost := flag.Bool("mock", false, "drive the interface with a simulated host")
	showVersion := flag.Bool("version", false, "print the build identity and exit")
	flag.Parse()
	if *showVersion {
		fmt.Println("barewire " + version.String())
		return
	}

	settingsPath := config.SettingsPath()
	settings, err := config.LoadSettings(settingsPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "barewire: %v\n", err)
		os.Exit(1)
	}

	var client hostclient.Client
	notice := ""
	switch {
	case *mockHost:
		client = mock.New()
	default:
		socketPath := config.HostSocketPath()
		if live, err := hostsock.Dial(socketPath); err == nil {
			client = live
		} else {
			// No host: the interface still starts and shows that fact, together
			// with the exact path and reason, so a path mismatch is visible.
			client = offline.New()
			notice = fmt.Sprintf("%s: %v", socketPath, err)
		}
	}
	defer func() { _ = client.Close() }()

	starter := hostspawn.New()
	model := tui.New(tui.Options{
		Client:            client,
		Settings:          settings,
		SettingsPath:      settingsPath,
		ProfilesPath:      config.ProfilesPath(),
		SubscriptionsPath: config.SubscriptionsPath(),
		HostNotice:        notice,
		SocketPath:        config.HostSocketPath(),
		HostStarter: func() (hostclient.Client, error) {
			return starter.Start(context.Background())
		},
		HostLogTail: func() []string {
			return hostspawn.Tail(starter.LogPath, 8)
		},
	})

	program := tea.NewProgram(model, tea.WithAltScreen())
	model.SetProgram(program)
	if _, err := program.Run(); err != nil {
		fmt.Fprintf(os.Stderr, "barewire: %v\n", err)
		os.Exit(1)
	}
	// If this interface started the host, it also stops it. Nothing is left
	// running in the background.
	model.ShutdownHost()
}
