package main

import (
	"testing"

	"github.com/mrazowner/barewire/internal/config"
)

// The measurement the user could not make with curl has to read like an answer:
// a figure with its unit, and a different string for "nothing arrived".
func TestSpeedText(t *testing.T) {
	cases := []struct {
		mbps float64
		want string
	}{
		{0, "0 Mbit/s (nothing arrived)"},
		{-1, "0 Mbit/s (nothing arrived)"},
		{0.4, "0.4 Mbit/s (0.1 MiB/s)"},
		{42.5, "42.5 Mbit/s (5.3 MiB/s)"},
		{940, "940.0 Mbit/s (117.5 MiB/s)"},
	}
	for _, c := range cases {
		if got := speedText(c.mbps); got != c.want {
			t.Errorf("speedText(%v) = %q, want %q", c.mbps, got, c.want)
		}
	}
}

func TestFindNode(t *testing.T) {
	st := config.SubscriptionStore{Items: []config.Subscription{
		{Name: "a", Nodes: []config.Node{
			{Name: "first", Address: "1.1.1.1"},
			{Name: "second", Address: "2.2.2.2"},
		}},
		{Name: "b", Nodes: []config.Node{{Name: "third", Address: "3.3.3.3"}}},
	}}

	if node, ok := findNode(st, "2"); !ok || node.Name != "third" {
		t.Fatalf("index lookup: %+v, %v", node, ok)
	}
	if node, ok := findNode(st, "SECOND"); !ok || node.Name != "second" {
		t.Fatalf("name lookup: %+v, %v", node, ok)
	}
	if node, ok := findNode(st, "3.3.3"); !ok || node.Name != "third" {
		t.Fatalf("address lookup: %+v, %v", node, ok)
	}
	if _, ok := findNode(st, "nope"); ok {
		t.Fatal("unknown name must not match")
	}
	if _, ok := findNode(st, "99"); ok {
		t.Fatal("out of range index must not match")
	}
}

// Both orders are natural: people type either "subfetch URL -ua X" or
// "subfetch -ua X URL". Go's flag package only handles the second.
func TestParseSubfetchArgs(t *testing.T) {
	cases := []struct {
		name    string
		args    []string
		url     string
		ua      string
		self    bool
		wantErr bool
	}{
		{"url then ua", []string{"https://x", "-ua", "FlClash"}, "https://x", "FlClash", false, false},
		{"ua then url", []string{"-ua", "FlClash", "https://x"}, "https://x", "FlClash", false, false},
		{"equals form", []string{"https://x", "-ua=clash.meta"}, "https://x", "clash.meta", false, false},
		{"long equals", []string{"https://x", "--ua=sing-box"}, "https://x", "sing-box", false, false},
		{"self test", []string{"-self-test"}, "", "", true, false},
		{"ua without value", []string{"https://x", "-ua"}, "", "", false, true},
		{"unknown flag", []string{"https://x", "-bogus"}, "", "", false, true},
		{"two urls", []string{"https://x", "https://y"}, "", "", false, true},
	}
	for _, tc := range cases {
		url, ua, self, err := parseSubfetchArgs(tc.args)
		if tc.wantErr {
			if err == nil {
				t.Errorf("%s: expected an error", tc.name)
			}
			continue
		}
		if err != nil {
			t.Errorf("%s: %v", tc.name, err)
			continue
		}
		if url != tc.url || ua != tc.ua || self != tc.self {
			t.Errorf("%s: got (%q, %q, %v), want (%q, %q, %v)", tc.name, url, ua, self, tc.url, tc.ua, tc.self)
		}
	}
}
