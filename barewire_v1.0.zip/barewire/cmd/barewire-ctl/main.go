// Command barewire-ctl pushes levers on a running barewire-host and prints the
// facts it gets back, in JSON. It exists for scripts and for checking the host
// without a terminal interface.
package main

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/diagnose"
	"github.com/mrazowner/barewire/internal/hostsock"
	"github.com/mrazowner/barewire/internal/subscription"
	"github.com/mrazowner/barewire/internal/system"
	"github.com/mrazowner/barewire/internal/version"
)

func main() {
	if len(os.Args) >= 2 && (os.Args[1] == "-version" || os.Args[1] == "--version") {
		fmt.Println("barewire-ctl " + version.String())
		return
	}
	if len(os.Args) >= 2 && os.Args[1] == "subfetch" {
		// Needs no host: it only talks to the provider.
		subfetch(os.Args[2:])
		return
	}
	if len(os.Args) >= 2 && os.Args[1] == "subs" {
		// Needs no host: it reads the local subscription store.
		st, err := config.LoadSubscriptions(config.SubscriptionsPath())
		if err != nil {
			fmt.Fprintf(os.Stderr, "barewire-ctl: %v\n", err)
			os.Exit(1)
		}
		printJSON(st)
		return
	}
	if len(os.Args) >= 2 && os.Args[1] == "addlink" {
		// Needs no host: it writes the local store, exactly like pasting a link.
		addLink(os.Args[2:])
		return
	}
	if len(os.Args) >= 2 && os.Args[1] == "nodecheck" {
		// Needs no host: it only dials the endpoint.
		nodecheck(os.Args[2:])
		return
	}
	if len(os.Args) >= 2 && os.Args[1] == "speed" {
		// Needs no host: it measures whatever route this process takes, which is
		// the tunnel while the tunnel is up.
		speed(os.Args[2:])
		return
	}
	if len(os.Args) < 2 {
		usage()
	}
	client, err := hostsock.Dial(config.HostSocketPath())
	if err != nil {
		fmt.Fprintf(os.Stderr, "barewire-ctl: %v\n", err)
		os.Exit(1)
	}
	defer func() { _ = client.Close() }()

	command := os.Args[1]
	switch command {
	case "status":
		printJSON(client.Snapshot())
	case "connect":
		must(client.Connect())
		printJSON(client.Snapshot())
	case "disconnect":
		must(client.Disconnect())
		printJSON(client.Snapshot())
	case "flush":
		must(client.FlushKillSwitch())
	case "mtu":
		mtu, err := client.AutoMTU()
		must(err)
		printJSON(map[string]int{"mtu": mtu})
	case "brutal":
		up, down, err := client.AutoBrutal()
		must(err)
		printJSON(map[string]int{"up_mbps": up, "down_mbps": down})
	case "connections":
		printJSON(client.Connections())
	case "apply":
		if len(os.Args) != 3 {
			usage()
		}
		settings, err := config.LoadSettings(os.Args[2])
		must(err)
		must(client.Apply(settings))
		printJSON(client.Snapshot())
	case "select":
		if len(os.Args) != 3 {
			usage()
		}
		node, err := loadNode(os.Args[2])
		must(err)
		must(client.SelectNode(node))
		printJSON(client.Snapshot())
	case "shutdown":
		if err := client.Shutdown(); err != nil {
			must(err)
		}
		fmt.Println("host stopped")
	default:
		usage()
	}
}

func loadNode(path string) (config.Node, error) {
	var node config.Node
	raw, err := os.ReadFile(path)
	if err != nil {
		return node, err
	}
	if err := json.Unmarshal(raw, &node); err != nil {
		return node, fmt.Errorf("%s: %w", path, err)
	}
	return node, nil
}

func printJSON(v any) {
	raw, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		must(err)
	}
	fmt.Println(string(raw))
}

func must(err error) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "barewire-ctl: %v\n", err)
		os.Exit(1)
	}
}

func usage() {
	fmt.Fprintln(os.Stderr, "usage: barewire-ctl status|connect|disconnect|flush|mtu|brutal|connections|shutdown")
	fmt.Fprintln(os.Stderr, "       barewire-ctl apply <settings.json>")
	fmt.Fprintln(os.Stderr, "       barewire-ctl select <node.json>")
	fmt.Fprintln(os.Stderr, "       barewire-ctl subfetch <url> [-ua <agent>]   (no host needed)")
	fmt.Fprintln(os.Stderr, "       barewire-ctl subs                          (no host needed)")
	fmt.Fprintln(os.Stderr, "       barewire-ctl nodecheck <name|address|index> (no host needed)")
	fmt.Fprintln(os.Stderr, "       barewire-ctl addlink '<vless://…>'          (no host needed)")
	fmt.Fprintln(os.Stderr, "       barewire-ctl speed                          (no host needed)")
	os.Exit(2)
}

// speed measures the link this process is using. With the tunnel up that is the
// tunnel, which is the number worth knowing: a page loads on a tenth of a
// megabit, a video needs twenty. It needs neither curl nor a shell that can run
// it — this was the measurement that could not be made before.
func speed(args []string) {
	downOnly := false
	for _, arg := range args {
		switch arg {
		case "-down", "--down":
			downOnly = true
		default:
			fmt.Fprintf(os.Stderr, "barewire-ctl: unknown speed argument %q\n", arg)
			usage()
		}
	}
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Minute)
	defer cancel()

	probe := system.NewThroughputProbe(nil)
	fmt.Printf("barewire-ctl: %s\n", version.String())
	fmt.Printf("endpoint: %s\n", probe.DownURL)

	down, err := probe.DownloadRate(ctx)
	if err != nil {
		fmt.Printf("down:     failed: %v\n", err)
	} else {
		fmt.Printf("down:     %s\n", speedText(down))
	}
	if !downOnly {
		up, err := probe.Upload(ctx)
		if err != nil {
			fmt.Printf("up:       failed: %v\n", err)
		} else {
			fmt.Printf("up:       %s\n", speedText(float64(up)))
		}
	}
	if err != nil && down <= 0 {
		os.Exit(1)
	}
}

// speedText renders a figure with the unit a person actually reads. The decimal
// matters: a third of a megabit is a link that cannot carry video, and it is not
// the same answer as nothing arriving at all.
func speedText(mbps float64) string {
	if mbps <= 0 {
		return "0 Mbit/s (nothing arrived)"
	}
	return fmt.Sprintf("%.1f Mbit/s (%.1f MiB/s)", mbps, mbps/8)
}

// subfetch shows what a provider answers, so a refusal can be read instead of
// guessed at. With -self-test it proves the parser works without any provider.
func subfetch(args []string) {
	rawURL, ua, selfTest, err := parseSubfetchArgs(args)
	if err != nil {
		fmt.Fprintf(os.Stderr, "barewire-ctl: %v\n", err)
		usage()
	}
	if selfTest {
		runSelfTest()
		return
	}
	if rawURL == "" {
		usage()
	}
	probe := subscription.RunProbe(context.Background(), rawURL, ua)

	fmt.Printf("barewire-ctl: %s\n", version.String())
	fmt.Printf("url:          %s\n", probe.URL)
	fmt.Printf("user-agent:   %s\n", probe.UserAgent)
	fmt.Printf("status:       %d\n", probe.Status)
	fmt.Printf("bytes:        %d\n", probe.Bytes)
	fmt.Printf("took:         %dms\n", probe.Took.Milliseconds())
	if probe.Format != "" {
		fmt.Printf("format:       %s\n", probe.Format)
		fmt.Printf("nodes:        %d\n", probe.Nodes)
	} else {
		fmt.Printf("format:       (not detected)\n")
	}
	if probe.Headers != nil {
		for _, key := range []string{"Server", "Content-Type", "Cf-Ray", "Location"} {
			if value := probe.Headers.Get(key); value != "" {
				fmt.Printf("%-13s %s\n", strings.ToLower(key)+":", value)
			}
		}
	}
	if probe.Preview != "" {
		fmt.Printf("body:         %s\n", probe.Preview)
	}
	if probe.Err != nil {
		fmt.Printf("error:        %v\n", probe.Err)
		os.Exit(1)
	}
}

// parseSubfetchArgs accepts flags before or after the URL, because both orders
// are natural and Go's flag package stops at the first positional argument.
func parseSubfetchArgs(args []string) (rawURL, userAgent string, selfTest bool, err error) {
	for i := 0; i < len(args); i++ {
		switch arg := args[i]; {
		case arg == "-ua" || arg == "--ua":
			if i+1 >= len(args) {
				return "", "", false, fmt.Errorf("%s needs a value", arg)
			}
			userAgent = args[i+1]
			i++
		case strings.HasPrefix(arg, "-ua=") || strings.HasPrefix(arg, "--ua="):
			_, value, _ := strings.Cut(arg, "=")
			userAgent = value
		case arg == "-self-test" || arg == "--self-test":
			selfTest = true
		case strings.HasPrefix(arg, "-"):
			return "", "", false, fmt.Errorf("unknown flag %q", arg)
		default:
			if rawURL != "" {
				return "", "", false, fmt.Errorf("unexpected argument %q", arg)
			}
			rawURL = arg
		}
	}
	return rawURL, userAgent, selfTest, nil
}

// addLink stores share links in the local store, in the same "pasted links"
// subscription the interface uses, so both paths stay in sync.
func addLink(args []string) {
	raw := strings.Join(args, " ")
	if strings.TrimSpace(raw) == "" {
		usage()
	}
	nodes := subscription.ParseLinks(raw)
	if len(nodes) == 0 {
		fmt.Fprintf(os.Stderr, "barewire-ctl: nothing usable in %q\n", raw)
		os.Exit(1)
	}
	path := config.SubscriptionsPath()
	st, err := config.LoadSubscriptions(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "barewire-ctl: %v\n", err)
		os.Exit(1)
	}
	idx := -1
	for i := range st.Items {
		if st.Items[i].Name == "pasted links" {
			idx = i
			break
		}
	}
	if idx < 0 {
		st.Items = append(st.Items, config.Subscription{Name: "pasted links", Format: "links", UpdatedAt: time.Now()})
		idx = len(st.Items) - 1
	}
	st.Items[idx].Nodes = append(st.Items[idx].Nodes, nodes...)
	st.Items[idx].UpdatedAt = time.Now()
	if err := config.SaveSubscriptions(path, st); err != nil {
		fmt.Fprintf(os.Stderr, "barewire-ctl: %v\n", err)
		os.Exit(1)
	}
	for _, node := range nodes {
		fmt.Printf("added: %s (%s) %s\n", node.Name, node.Kind, node.Endpoint())
	}
	fmt.Printf("store: %s\n", path)
}

// nodecheck walks resolve → TCP → TLS for one node of the local store and stops
// at the first failing step. That step is the answer to "why is nothing loading".
func nodecheck(args []string) {
	if len(args) < 1 {
		usage()
	}
	st, err := config.LoadSubscriptions(config.SubscriptionsPath())
	if err != nil {
		fmt.Fprintf(os.Stderr, "barewire-ctl: %v\n", err)
		os.Exit(1)
	}
	node, ok := findNode(st, args[0])
	if !ok {
		fmt.Fprintf(os.Stderr, "barewire-ctl: no node matching %q (try: barewire-ctl subs)\n", args[0])
		os.Exit(2)
	}

	fmt.Printf("barewire-ctl: %s\n", version.String())
	report := diagnose.Node(context.Background(), node.Name, node.Outbound, 5*time.Second)
	fmt.Printf("node:         %s\n", report.Name)
	fmt.Printf("endpoint:     %s\n", report.Endpoint)
	if len(report.Addresses) > 0 {
		fmt.Printf("addresses:    %s\n", strings.Join(report.Addresses, ", "))
	}
	if report.ResolveErr != nil {
		fmt.Printf("resolve:      FAILED %v\n", report.ResolveErr)
		fmt.Printf("result:       the host name does not resolve\n")
		os.Exit(1)
	}
	if report.TCPErr != nil {
		fmt.Printf("tcp:          FAILED after %dms: %v\n", report.TCP.Milliseconds(), report.TCPErr)
		fmt.Printf("result:       the server is unreachable from this network (blocked, dead or wrong port)\n")
		os.Exit(1)
	}
	fmt.Printf("tcp:          ok in %dms\n", report.TCP.Milliseconds())
	if report.TLSErr != nil {
		fmt.Printf("tls:          FAILED (sni %s): %v\n", report.SNI, report.TLSErr)
		fmt.Printf("result:       TCP works, TLS does not: wrong port, or the server rejects this handshake\n")
		os.Exit(1)
	}
	if report.TLSVersion != "" {
		fmt.Printf("tls:          ok, %s (sni %s)\n", report.TLSVersion, report.SNI)
	}
	fmt.Printf("result:       reachable\n")
}

// findNode matches an index ("3"), a name or an address fragment.
func findNode(st config.SubscriptionStore, query string) (config.Node, bool) {
	if index, err := strconv.Atoi(query); err == nil {
		flat := make([]config.Node, 0)
		for _, sub := range st.Items {
			flat = append(flat, sub.Nodes...)
		}
		if index >= 0 && index < len(flat) {
			return flat[index], true
		}
		return config.Node{}, false
	}
	needle := strings.ToLower(query)
	for _, sub := range st.Items {
		for _, node := range sub.Nodes {
			if strings.Contains(strings.ToLower(node.Name), needle) ||
				strings.Contains(strings.ToLower(node.Address), needle) {
				return node, true
			}
		}
	}
	return config.Node{}, false
}

// runSelfTest parses built-in fixtures: a deterministic answer to "is the client
// itself broken?" that does not involve any provider.
func runSelfTest() {
	const clashDoc = `proxies:
  - name: a
    type: vless
    server: a.example
    port: 443
    uuid: 11111111-2222-3333-4444-555555555555
  - name: b
    type: ss
    server: b.example
    port: 8388
    cipher: aes-256-gcm
    password: p
`
	const v2rayList = "vless://11111111-2222-3333-4444-555555555555@x.example:443?sni=x.example#x\n" +
		"trojan://pw@y.example:443#y\n"

	ok := true
	check := func(name, body string, want int) {
		nodes, err := subscription.Parse(name, []byte(body))
		if err != nil {
			fmt.Printf("%-6s parse error: %v\n", name, err)
			ok = false
			return
		}
		fmt.Printf("%-6s %d nodes (want %d)\n", name, len(nodes), want)
		if len(nodes) != want {
			ok = false
		}
	}
	check(subscription.FormatClash, clashDoc, 2)
	check(subscription.FormatV2Ray, base64.StdEncoding.EncodeToString([]byte(v2rayList)), 2)
	if !ok {
		fmt.Println("parser self-test FAILED")
		os.Exit(1)
	}
	fmt.Println("parser self-test passed: the client can read both formats")
}
