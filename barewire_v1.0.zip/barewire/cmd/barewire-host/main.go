// Command barewire-host is the privileged half of Barewire. It owns the TUN
// device, the firewall and the kernel levers, speaks to the interface over a
// unix socket, and exits when the interface tells it to: nothing stays behind.
package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"
	"time"

	"github.com/mrazowner/barewire/internal/config"
	"github.com/mrazowner/barewire/internal/host"
	"github.com/mrazowner/barewire/internal/hostlog"
	"github.com/mrazowner/barewire/internal/hostsock"
	"github.com/mrazowner/barewire/internal/proto"
	"github.com/mrazowner/barewire/internal/version"
)

func main() {
	settingsPath := flag.String("settings", "", "path to settings.json (default: the session user's)")
	socketPath := flag.String("socket", "", "unix socket to listen on (default: the session user's runtime dir)")
	tunName := flag.String("tun", "barewire0", "TUN interface name")
	stateDir := flag.String("state", "", "state directory (default: the session user's config dir)")
	showVersion := flag.Bool("version", false, "print the build identity and exit")
	cleanup := flag.Bool("cleanup", false, "remove firewall rules, the tun link and the fakeip cache, then exit")
	flag.Parse()
	if *showVersion {
		fmt.Println("barewire-host " + version.String() + " · " + version.Core())
		return
	}

	// Under sudo the process runs as root but serves the invoking user: the
	// socket, the settings and the state must belong to that user, or the
	// interface neither reaches the socket nor sees the same files.
	session := config.CurrentSession()
	if *stateDir == "" {
		*stateDir = config.ConfigDirFor(session)
	}
	if err := config.EnsureDir(*stateDir); err != nil {
		fail(err)
	}
	// Everything the elevated host writes here belongs to the user who will edit
	// it: a root-owned settings.json or cache.db turns the next save into a
	// failure that looks like a broken interface.
	if err := config.HandOver(*stateDir, session); err != nil {
		fmt.Fprintf(os.Stderr, "barewire-host: %v\n", err)
	}
	if *settingsPath == "" {
		*settingsPath = config.SettingsPathFor(session)
	}
	if *socketPath == "" {
		*socketPath = config.HostSocketPathFor(session)
	}
	settings, err := config.LoadSettings(*settingsPath)
	if err != nil {
		fail(err)
	}

	if *cleanup {
		// Recovery after a host that died without cleaning up: leftover routes
		// or firewall rules are why the network can look broken afterwards.
		ctl := host.New(settings, host.Paths{StateDir: *stateDir, TUNName: *tunName})
		failed := false
		for _, step := range ctl.Cleanup(context.Background()) {
			if step.Err != nil {
				fmt.Fprintf(os.Stderr, "cleanup: %s: %v\n", step.What, step.Err)
				failed = true
				continue
			}
			fmt.Printf("cleanup: %s: ok\n", step.What)
		}
		if failed {
			os.Exit(1)
		}
		return
	}

	ctl := host.New(settings, host.Paths{StateDir: *stateDir, TUNName: *tunName})
	server, err := hostsock.ListenAs(*socketPath, ctl, session.UID, session.GID)
	if err != nil {
		fail(err)
	}
	// The interface shows the events of the moment; the file is what is left when
	// the host is gone, which is exactly when someone needs to know why. It sits
	// next to the socket, and the host hands it to the user it serves.
	logPath := filepath.Join(filepath.Dir(*socketPath), "host.log")
	record, err := hostlog.Open(logPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "barewire-host: %v\n", err)
	}
	defer func() { _ = record.Close() }()
	if err := config.HandOver(filepath.Dir(*socketPath), session); err != nil {
		fmt.Fprintf(os.Stderr, "barewire-host: %v\n", err)
	}
	// A host that was killed leaves its kill-switch ruleset behind, and that
	// ruleset blocks the machine with no tunnel to carry the traffic. Nothing is
	// served yet, so clearing it is safe.
	for _, step := range ctl.Reset(context.Background()) {
		if step.Err != nil {
			fmt.Fprintf(os.Stderr, "reset: %s: %v\n", step.What, step.Err)
		}
	}
	ctl.SetPublisher(func(ev proto.Event) {
		server.Publish(ev)
		record.Write(ev)
	})
	record.Write(proto.Event{Type: proto.EventLog, Log: &proto.LogEntry{
		Time:   time.Now(),
		Level:  proto.LevelInfo,
		Source: "host",
		Text: fmt.Sprintf("barewire-host %s listening on %s, serving uid %d, settings %s",
			host.Version, *socketPath, session.UID, *settingsPath),
	}})

	shutdown := make(chan struct{}, 1)
	server.OnShutdown(func() {
		select {
		case shutdown <- struct{}{}:
		default:
		}
	})

	signals := make(chan os.Signal, 1)
	signal.Notify(signals, os.Interrupt, syscall.SIGTERM, syscall.SIGHUP)
	defer signal.Stop(signals)

	go func() {
		if err := server.Serve(); err != nil {
			fail(err)
		}
		select {
		case shutdown <- struct{}{}:
		default:
		}
	}()

	fmt.Fprintf(os.Stderr, "barewire-host %s listening on %s (serving uid %d, settings %s)\n",
		host.Version, *socketPath, session.UID, *settingsPath)

	for {
		select {
		case sig := <-signals:
			if sig != syscall.SIGHUP {
				goto stop
			}
			// SIGHUP is the terminal going away or the file being edited, not a
			// request to drop the tunnel: reload the levers and keep serving.
			reload(ctl, *settingsPath)
		case <-shutdown:
			goto stop
		}
	}

stop:
	record.Write(proto.Event{Type: proto.EventLog, Log: &proto.LogEntry{
		Time: time.Now(), Level: proto.LevelInfo, Source: "host", Text: "host stopping",
	}})
	_ = server.Close()
	if err := ctl.Close(context.Background()); err != nil {
		fmt.Fprintf(os.Stderr, "barewire-host: %v\n", err)
	}
}

// reload re-reads the settings file and applies it. A file that cannot be read
// leaves the running levers alone: the tunnel is more important than the edit.
func reload(ctl *host.Host, path string) {
	settings, err := config.LoadSettings(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "reload: %v\n", err)
		return
	}
	if err := ctl.Apply(context.Background(), settings); err != nil {
		fmt.Fprintf(os.Stderr, "reload: %v\n", err)
		return
	}
	fmt.Fprintln(os.Stderr, "reload: settings applied")
}

func fail(err error) {
	fmt.Fprintf(os.Stderr, "barewire-host: %v\n", err)
	os.Exit(1)
}
